

--ScriptV26_15_Fix6_Added1
--������ �� ����� ���� ���� ����� 
-- ��� ����� ��� ���� �� �� ������ ����
-- �� ���� ���� ������ ��� � ���� ����� ��� ����
--91/12/20
--����� ���� ����� ������ �� ��� ���� �� �� ���� ����

ALTER  PROCEDURE [dbo].[EditFactorMasterDetails]  (  


	@No       INT,  
	@Status  INT ,  
	@Owner  INT ,  
	@Customer  INT ,  
	@DiscountTotal Float ,  
	@CarryFeeTotal Float ,  
	@Recursive  INT ,  
	@InCharge  INT ,  
	@FacPayment  BIT ,  
	@OrderType  INT ,  
	@StationId  INT ,  
	@ServiceTotal  Float ,  
	@PackingTotal  Float ,  
	@TableNo  INT ,  
	@User INT ,  
	@Date   Nvarchar(50) =NULL,  
	@DetailsString  nText,  
	@ds nText = '',  
	@Balance Bit,  
	@AccountYear Smallint = Null ,  
	@NvcDescription Nvarchar(150) = Null ,  
	@TempAddress Nvarchar(255) = '', 
	@GuestNo INT,     
	@LastFacMNo  INT OUT  
  )  


AS  
DECLARE @SumPrice BIGINT  
DECLARE @SumPrice2 BIGINT  
DECLARE @intSerialNo BIGINT  
DECLARE @intSerialNo2 BIGINT  
--DECLARE @intSerialNo3 BIGINT  
DECLARE @OldRegDate Nvarchar(50)  
DECLARE  @FactorSerial BIGINT  
Declare @Result int  

SET @Sumprice = 0  
SET @Sumprice2= 0  
SET @intSerialNo = 0  
SET @intSerialNo2 = 0  
--SET @intserialNo3 = 0  


 Declare @intBranch  int  
 Declare @ShiftNo int  

 Declare @DestBranch INT  
 SET @DestBranch = 0

IF @AccountYear IS  Null
    Set @AccountYear = dbo.get_AccountYear() 

 select @intBranch = branch from tInventory where inventoryNo=(SELECT TOP 1  IntInventoryNo FROM Split(@DetailsString))  
 SET @ShiftNo= dbo.Get_Shift(GETDATE())  

SET @intSerialNo = (SELECT tFacM.intSerialNo FROM tFacM WHERE [No] = @No AND Status = @Status and Branch =  @intBranch AND AccountYear = @AccountYear)  
IF @Status = 6
	SET @intSerialNo2 = @intSerialNo + 1


if @status=10   
set @OldRegDate = (SELECT tFacM.regdate FROM tFacM WHERE [No] = @No AND Status = @Status and Branch =  @intBranch AND AccountYear = @AccountYear)  
else set @OldRegDate=dbo.Shamsi(GETDATE())  
-------------No Change StationId , If this Fich Is For Pocket Pc---------------------------------------  
DECLARE @OldStationId INT  
 SET @OldStationId = (Select StationId From tFacm Where intserialNo = @intSerialNo and Branch =  dbo.Get_Current_Branch())  

DECLARE @StationType INT  
 SET @StationType = (Select StationType From tStations Where StationId = @OldStationId and Branch =  dbo.Get_Current_Branch())  
If  @StationType = 8  
 SET @StationId = @OldStationId  
----------------------------------------------------------------------------------------------------------  
IF  @Owner = 0  
    SET @Owner = NULL  

IF  @TableNo < 1  
    SET @TableNo = NULL  

Declare @OldTableNo   int  

SET  @OldTableNo =  IsNull((SELECT tFacM.TableNo FROM tFacM WHERE intSerialNo = @intSerialNo and Branch = dbo.Get_Current_Branch()) , 0)  

IF  @Incharge < 1  
    SET @Incharge = NULL  

IF  @Customer=0  
    SET @Customer = NULL  
IF @Date IS NULL  
 SET @Date=dbo.Shamsi(GETDATE())  

BEGIN TRANSACTION  

If IsNull(@TableNo , 0) <> @OldTableNo  
BEGIN  
 IF @OldTableNo > 0   
 Update ttable SET Empty = 1 where No = @OldTableNo  
END  

    DECLARE @MasterServePlace INT  

 SELECT @MasterServePlace = SUM(tmpTable.SServePlace)  
 FROM   
 (  SELECT DISTINCT ServePlace As SServePlace  FROM Split(@DetailsString)) tmpTable  


 if @Status = 2  
 begin  
       INSERT INTO tRepFacEditM (Branch , intSerialNo, [No], Status, Owner, Customer, DiscountTotal, CarryFeeTotal, SumPrice, Recursive, InCharge, FacPayment, Balance , OrderType,  
                        ServePlace, StationId, ServiceTotal, PackingTotal, ShiftNo, TableNo, [Date], [Time], [User], RegDate, AccountYear , TaxTotal , DutyTotal  )  
          SELECT Branch , intSerialNo, [No], Status, Owner, Customer, DiscountTotal, CarryFeeTotal, SumPrice, Recursive, InCharge, FacPayment, Balance, OrderType,  
                        ServePlace, StationId, ServiceTotal, PackingTotal, ShiftNo, TableNo, [Date], [Time], [User], RegDate , AccountYear , TaxTotal , DutyTotal    
   FROM tFacM WHERE tFacM.intSerialNo = @intSerialNo and Branch = @intBranch  

      IF @@ERROR <>0  
          GoTo EventHandler  

      INSERT INTO tFacD2(Code , Branch ,intRow, Amount, GoodCode, FeeUnit, intSerialNo, ServePlace,ChairName , DifferencesCodes , DifferencesDescription ,Discount ,[ExpireDate], intInventoryNo )   
    SELECT @@identity , Branch ,intRow, Amount, GoodCode, FeeUnit, intSerialNo, ServePlace,ChairName , DifferencesCodes , DifferencesDescription ,Discount ,[ExpireDate],intInventoryNo  
                 From tFacD  
                 WHERE intSerialNo = @intSerialNo  And Branch = @intBranch

      IF @@ERROR <>0  
          GoTo EventHandler  

 end  



If @status = 6 --And (@destbranch = dbo.Get_Current_Branch()  )--or dbo.AutoResid() = 1   
 select @destbranch=branch from tInventory where inventoryNo=(SELECT TOP 1 DestInventoryNo FROM Split(@DetailsString))  

---------------------------------------Mojodi Control Online---------------------------------------------------------  
Exec DeleteMojodiCalculate @Status , @intserialNo  ,  1 , @AccountYear , @intBranch  
IF @@ERROR <>0  
 GoTo EventHandler  
If @status = 6 --And (@destbranch = @intBranch )  --or dbo.AutoResid() = 1 
 Exec DeleteMojodiCalculate 7 , @intserialNo2  , 1 , @AccountYear , @DestBranch  
----------------------------------------Delete Old Details -----------------------------------------------------------  
    DELETE FROM tFacD  
    WHERE tFacD.intSerialNo = @intSerialNo AND Branch =  @intBranch  
    IF @@ERROR <>0  
        GoTo EventHandler  
If @status = 6 --And (@destbranch = @intBranch or dbo.AutoResid() = 1 )   
    DELETE FROM tFacD  
    WHERE tFacD.intSerialNo = @intSerialNo2 AND Branch =  @DestBranch  
    IF @@ERROR <>0  
        GoTo EventHandler  
------------------------------------------------------------    
  Exec DeleteFactorChildren @intSerialNo , @intBranch  
  IF @@ERROR <>0  
         GoTo EventHandler  
 If @status = 6 --And (@destbranch = dbo.Get_Current_Branch() or dbo.AutoResid() = 1 )  
  Exec DeleteFactorChildren @intSerialNo2 , @DestBranch  
  IF @@ERROR <>0  
         GoTo EventHandler  
----------------------------------------Date From Server-----------------------------------------------------------------  
If @Status = 2 And dbo.Get_DateFromServer() = 1  
 SET @Date = dbo.Get_ShamsiDate_For_Current_Shift(GETDATE())  
----------------------------------------Update Master-----------------------------------------------------------------  

    Update tFacM  
        SET Owner       = @Owner,  
        Customer        = @Customer,  
        DiscountTotal   = @DiscountTotal,  
        CarryFeeTotal   = @CarryFeeTotal,  
        SumPrice        = @SumPrice,  
        Recursive       = @Recursive,   
        InCharge        = @InCharge,  
        FacPayment      = @FacPayment,  
        Balance         = @Balance,  
        OrderType       = @OrderType,  
        ServePlace      = @MasterServePlace,  
        StationId       = @StationId,  
        ServiceTotal    = @ServiceTotal,  
        PackingTotal    = @PackingTotal,  
--        ShiftNo         = @ShiftNo , --dbo.Get_Shift(GETDATE()),  
        TableNo         = @TableNo,  
 --       [Date]          = @Date,  
        [Time]          = dbo.SetTimeFormat(GETDATE()),  
        [User]          = @User,  
        RegDate 	= @OldRegDate,---dbo.Shamsi(GETDATE()),  
        NvcDescription  = @NvcDescription ,  
 		TempAddress     = @TempAddress,
		GuestNo		= @GuestNo    
    WHERE tFacM.intSerialNo = @intSerialNo  AND Branch =  @intBranch  

    IF @@ERROR <>0  
        GoTo EventHandler  

DECLARE @No2 INT
SET @No2 = 0

If @Status = 6 --And (@destbranch = dbo.Get_Current_Branch() or dbo.AutoResid() = 1 )  
Begin  
    SET @NO2 = (SELECT [NO] FROM tFacM WHERE intserialNo = @intSerialNo2  And Branch =  @DestBranch )      


    Update tFacM  
        SET Owner       = @Owner,  
        Customer        = @Customer,  
        DiscountTotal   = @DiscountTotal,  
        CarryFeeTotal   = @CarryFeeTotal,  
        SumPrice        = @SumPrice,  
        Recursive       = @Recursive,   
        InCharge        = @InCharge,  
        FacPayment      = @FacPayment,  
        Balance         = @Balance,  
        OrderType       = @OrderType,  
        ServePlace      = @MasterServePlace,  
        StationId       = @StationId,  
        ServiceTotal    = @ServiceTotal,  
        PackingTotal    = @PackingTotal,  
        ShiftNo         = @ShiftNo ,--dbo.Get_Shift(GETDATE()),  
        TableNo         = @TableNo,  
        [Date]          = @Date,  
        [Time]          =dbo.SetTimeFormat(GETDATE()),  
        [User]          = @User,  
        RegDate 	= dbo.Shamsi(GETDATE()),  
        NvcDescription  = @NvcDescription,  
 		TempAddress     = @TempAddress ,
		GuestNo		= @GuestNo  
    WHERE tFacM.intSerialNo = @intSerialNo2  AND Branch =  @DestBranch  

END  

----------------------------------Fill Details Factor ----------------------------------------------------------------------  
If @Status = 6  --AND (@destbranch= @intBranch Or dbo.AutoResid() = 1 )    
 exec InsertFactorDetail @DetailsString , @intserialNo , @intserialNo2, @Customer , @intBranch  
Else         
 exec InsertFactorDetail @DetailsString , @intserialNo , 0 , @Customer , @intBranch        

     IF @@ERROR <>0  
        GoTo EventHandler  
--------------------------------- Fill Havalem & HavaleD   ------------------------------------------------------------  


----------------------------------Total SumPrice Calculate  --------------------------------------------------------------  
DECLARE @DiscountD INT 
Set @DiscountD = (Select CAST(ROUND(SUM( (Amount * FeeUnit) * discount/100 ) ,0) AS INT)  From tFacd Where intSerialNo = @intserialNo And Branch = @intBranch )        
Set @SumPrice = (Select CAST(ROUND(SUM( (Amount * FeeUnit) * (1 - discount/100) ) ,0) AS INT)  From tFacd Where intSerialNo = @intserialNo And Branch = @intBranch )        

     IF @@ERROR <>0      
        GoTo EventHandler      
DECLARE @TaxTotal FLOAT  
SET @TaxTotal = 0
DECLARE @ValueGoodsTax FLOAT
SET @ValueGoodsTax = 0
IF @status = 2 OR @status = 5 OR @status = 10
	SET @ValueGoodsTax = ( SELECT    CAST(ROUND(SUM( Amount * FeeUnit) ,0) AS INT)
	              FROM      tFacd INNER JOIN dbo.tGood ON dbo.tFacD.GoodCode = dbo.tGood.Code
	              WHERE     intSerialNo = @intSerialNo
	                        AND Branch = @intBranch AND dbo.tGood.TaxSale = 1
	            )  
ELSE IF @status = 1 OR @status = 4
	SET @ValueGoodsTax = ( SELECT    CAST(ROUND(SUM( Amount * FeeUnit) ,0) AS INT)
	              FROM      tFacd INNER JOIN dbo.tGood ON dbo.tFacD.GoodCode = dbo.tGood.Code
	              WHERE     intSerialNo = @intSerialNo
	                        AND Branch = @intBranch AND dbo.tGood.TaxBuy = 1
	            )  
SET @ValueGoodsTax = ISNULL(@ValueGoodsTax , 0)
IF @@ERROR <> 0 
GOTO EventHandler

DECLARE @DutyTotal INT 
SET @DutyTotal = 0
DECLARE @ValueGoodsDuty FLOAT
SET @ValueGoodsDuty = 0
IF @status = 2 OR @status = 5 OR @status = 10
	SET @ValueGoodsDuty = ( SELECT    CAST(ROUND(SUM( Amount * FeeUnit) ,0) AS INT)
	              FROM      tFacd INNER JOIN dbo.tGood ON dbo.tFacD.GoodCode = dbo.tGood.Code
	              WHERE     intSerialNo = @intSerialNo
	                        AND Branch = @intBranch AND dbo.tGood.DutySale = 1
	            )  
ELSE IF @status = 1 OR @status = 4
	SET @ValueGoodsDuty = ( SELECT    CAST(ROUND(SUM( Amount * FeeUnit) ,0) AS INT)
	              FROM      tFacd INNER JOIN dbo.tGood ON dbo.tFacD.GoodCode = dbo.tGood.Code
	              WHERE     intSerialNo = @intSerialNo
	                        AND Branch = @intBranch AND dbo.tGood.DutyBuy = 1
	            )  
SET @ValueGoodsDuty = ISNULL(@ValueGoodsDuty , 0)
IF @@ERROR <> 0 
GOTO EventHandler

If @Status = 6 --And (@destbranch= dbo.Get_Current_Branch() Or dbo.AutoResid() = 1 )  
 Set @SumPrice2 = (Select Cast (Sum(Amount * FeeUnit) as Bigint)   From tFacd Where intSerialNo = @intSerialNo2 And Branch = @DestBranch )    
IF @@ERROR <>0  
        GoTo EventHandler  
----------------------------------ServiceRate Calculate  --------------------------------------------------------------  
Declare @ReserveServiceRate Int  
Set @ReserveServiceRate = 0  
If  @TableNo >0  
Begin  
	Declare @Reserve Bit  
	Set @Reserve = (Select Reserve From tTable Where tTable.[No] = @TableNo)  
	If @Reserve = 1  
		Set @ReserveServiceRate = (Select t.ReserveServiceRate From(Select ReserveServiceRate From tPartitions  inner join tTable    
		On tPartitions.PartitionId = tTable.PartitionId and  tTable.[No] = @TableNo)t )  


	If   @Recursive = 0  
	 Update dbo.tTable  
	    Set   dbo.tTable.Empty  = 0  
	        Where dbo.tTable.[No] = @TableNo  AND @Balance = 0
	
	if  @Recursive = 1  
         Update dbo.tTable  
            Set   dbo.tTable.Empty  = 1  
                Where dbo.tTable.[No] = @TableNo  

	If dbo.Get_TableMonitoring() = 1 AND IsNull(@TableNo , 0) <> @OldTableNo   ---Table Monitoring      
	 	Begin      
		DECLARE @intTableUsedNo INT      
		SET @intTableUsedNo = (SELECT TOP 1 intTableUsedNo FROM vwSamar_TableUsage_BusyTable      
		WHERE vwSamar_TableUsage_BusyTable.intTableNo=@OldTableNo and vwSamar_TableUsage_BusyTable.intBranch=@intBranch ORDER BY intTableUsedNo DESC   )   
		SET @intTableUsedNo = ISNULL(@intTableUsedNo , 0) 
		UPDATE tblSamar_TableUsage SET tblSamar_TableUsage.intTableNo = @TableNo      
		WHERE  tblSamar_TableUsage.intTableUsedNo = @intTableUsedNo      
		END        

End  

If @ReserveServiceRate > 0   
 Set @ServiceTotal = @ReserveServiceRate  


 If @ServiceTotal <> 0  
       Set @ServiceTotal = CAST((@SumPrice + @DiscountD) * @ServiceTotal /100 AS INT)  

     IF @@ERROR <>0  
        GoTo EventHandler   
----------------------------------Round Sumprice  --------------------------------------------------------------  
--IF @StationType = 8  --Because ppc program not calculate discountD
    --Set @DiscountTotal = @DiscountTotal + @DiscountD      
 IF @status = 1 OR @status = 2  Or @status = 4 OR @status = 5 OR @status = 10
 BEGIN 
  SELECT @DutyTotal = dbo.Get_Duty(@ValueGoodsDuty ,@DiscountTotal ,@ServiceTotal ,@CarryFeeTotal, @PackingTotal) 
  SELECT @TaxTotal = dbo.Get_Tax(@ValueGoodsTax ,@DiscountTotal ,@ServiceTotal ,@CarryFeeTotal, @PackingTotal) 
 END 
    Set @SumPrice = @SumPrice + @ServiceTotal + @CarryFeeTotal + @PackingTotal - @DiscountTotal + @DiscountD + @TaxTotal + @DutyTotal   

    Declare @Remain INT  
    SET @Remain = 0
    IF @Status = 2 OR @status = 10
    BEGIN
    Set @Remain = dbo.RoundSumPrice(@SumPrice )     
    Set @SumPrice = @SumPrice - @Remain  
    Set @DiscountTotal = @DiscountTotal + @Remain  
    END
----------------------------------Calculate Packing---------------------------------------------------------------  
IF dbo.Get_AutoPacking() = 1  
Begin  
    Declare @UserPacking INT  
    SET @UserPacking = ISNULL((Select ISNULL(Sum(Amount),0)  From tGood inner join tFacD On tFacD.GoodCode = tGood.Code   
 where intSerialNo = @intSerialNo and MainType =1 and Branch = @intBranch Group By MainType) ,0)  
    Set @UserPacking = @UserPacking * [dbo].[Get_User_Packing]()  
   Set @SumPrice = @SumPrice + @UserPacking  
   Update tFacm Set PackingTotal = @UserPacking  Where intSerialNo = @intserialNo And Branch = @intBranch   
End  
----------------------------------Net Price Update  --------------------------------------------------------------  

    Update tFacm Set SumPrice = @SumPrice Where intSerialNo = @intserialNo And Branch = @intBranch   
 IF @@ERROR <>0  
         GoTo EventHandler  
If @Status = 6 --And (@destbranch= dbo.Get_Current_Branch() Or dbo.AutoResid() = 1)   

    Update tFacm Set SumPrice = @SumPrice2 Where intSerialNo = @intserialNo2 And Branch = @DestBranch  
 IF @@ERROR <>0  
         GoTo EventHandler  

Update tFacm Set DiscountTotal = @DiscountTotal Where intSerialNo = @intserialNo  And Branch = @intBranch   
Update tFacm Set ServiceTotal = @ServiceTotal Where intSerialNo = @intserialNo And Branch = @intBranch   
Update tFacm Set RoundDiscount = @Remain  Where intSerialNo = @intserialNo And Branch = @intBranch   
Update tFacm Set TaxTotal = @TaxTotal  Where intSerialNo = @intserialNo And Branch = @intBranch       
Update tFacm Set DutyTotal = @DutyTotal  Where intSerialNo = @intserialNo And Branch = @intBranch       

-----------------------------------------Fill Detail Cash ,....---------------------------------------------------  
If (@Status = 2 OR @Status = 1)  
 exec Do_SaveInDetailsFactorReceived @intSerialNo, @ds  , @intBranch  , @Remain  
 IF @@ERROR <>0  
        GoTo EventHandler  
-----------------------------------------Monitoring  --------------------------------------------------------------  

Declare  @Monitor1 int  
Declare  @Monitor2 int  

Set @Monitor1 = (Select Count(Stationid) from  dbo.tStations Where (StationType  &  16  = 16) and  IsActive =1 And Branch =  dbo.Get_Current_Branch())  
Set @Monitor2 = (Select Count(Stationid) from  dbo.tStations Where (StationType  &  32  = 32) and  IsActive =1 And Branch =  dbo.Get_Current_Branch())  


If @Monitor1 > 0   
  exec Notify_to_Clients  
Else If @Monitor2 > 0   
  exec Notify_to_Clients  

 IF @@ERROR <>0  
        GoTo EventHandler  

-----------------------------------------History  --------------------------------------------------------------  

Exec InsertHistory  @No, @Status , @User , 2 ,@AccountYear  , @intBranch
 IF @@ERROR <>0  
        GoTo EventHandler  

-----------------------------------------Cash  --------------------------------------------------------------  

------------------------------------------Mojodi Control Online-----------------------------------------------------  

Exec InsertMojodiCalculate @Status , @intserialNo , @AccountYear , @intBranch  
IF @@ERROR <>0  
 GoTo EventHandler  
IF @STATUs = 6 --AND (@destbranch = dbo.Get_Current_Branch() or dbo.AutoResid() = 1 )  
 BEGIN  
 Exec Insert_tinventory_Good @intserialNo2 , @AccountYear , @intBranch  
 IF @@ERROR <>0  
 GoTo EventHandler  
 Exec InsertMojodiCalculate  7,  @intserialNo2 , @AccountYear , @destbranch  
 IF @@ERROR <>0  
 GoTo EventHandler  
 END   
------------------------------------------Update Balance After Recived----------------------------
Declare @SumRecieved INT
SET @SumRecieved =0

Set @SumRecieved =(Select IsNull(SUM(Bestankar),0)  From   tblAcc_Recieved 
 Where intSerialNo = @intSerialNo  and Branch = @intBranch )
Set @SumRecieved = @SumRecieved + (Select IsNull(SUM(intAmount),0)  From   dbo.tFacCash 
 Where intSerialNo = @intSerialNo  and Branch = @intBranch )
Set @SumRecieved = @SumRecieved + (Select IsNull(SUM(intAmount),0)  From   dbo.tFacCard
 Where intSerialNo = @intSerialNo  and Branch = @intBranch )
Set @SumRecieved = @SumRecieved + (Select IsNull(SUM(intChequeAmount),0)  From   dbo.tFacCheque
 Where intSerialNo = @intSerialNo  and Branch = @intBranch )
Set @SumRecieved = @SumRecieved + (Select IsNull(SUM(intAmount),0)  From   dbo.tFacCredit
 Where intSerialNo = @intSerialNo  and Branch = @intBranch )

    IF @SumRecieved >= @sumPrice AND @Status = 2 
        UPDATE  tfacm
        SET     [Balance] = 1 , FacPayment = 1
        WHERE   [intSerialNo] = @intserialNo AND Branch = @intBranch
    ELSE IF @SumRecieved < @sumPrice AND @Status = 2 
        UPDATE  tfacm
        SET     [Balance] = 0
        WHERE   [intSerialNo] = @intserialNo AND Branch = @intBranch


COMMIT TRANSACTION  

Set @LastFacMNo = @No  
Return @LastFacMNo  


EventHandler:  
    ROLLBACK TRAN  
    SET @LastFacMNo = -1   

    RETURN @LastFacMNo
GO


ALTER  PROCEDURE [dbo].[Total_ReIndex]
AS 
    DECLARE @DataFile NVARCHAR(50)
    DECLARE @LogFile NVARCHAR(50)

    SELECT  @DataFile = [name] /*fileid ,, filename, size, growth, status, maxsize */
    FROM    dbo.sysfiles
    WHERE   fileid = 1 --(status & 0x40) <> 0 AND
    SELECT  @LogFile = [name] /*fileid ,, filename, size, growth, status, maxsize*/
    FROM    dbo.sysfiles
    WHERE   fileid = 2 --(status & 0x40) <> 0 AND

--PRINT @DataFile
--PRINT @LogFile
    DECLARE @Str NVARCHAR(200)
--(N'Total_Data')
    SET @Str = N'DBCC SHRINKFILE (N''' + RTRIM(LTRIM(@DataFile)) + '''' + ')'
--PRINT @Str
    EXECUTE sp_executesql @str


    SET @Str = N'DBCC SHRINKFILE (N''' + RTRIM(LTRIM(@LogFile)) + '''' + ')'
    EXECUTE sp_executesql @str
--PRINT @Str

    DBCC DBREINDEX ('tfacd', '' , 0)
    DBCC DBREINDEX ('tfacm', '' , 0)
    DBCC DBREINDEX ('tfacd2', '' , 0)
    DBCC DBREINDEX ('tCASh', '' , 0)
    DBCC DBREINDEX ('tCust', '' , 0)
    DBCC DBREINDEX ('tFacCard', '' , 0)
    DBCC DBREINDEX ('tFacCash', '' , 0)
    DBCC DBREINDEX ('tFacCheque', '' , 0)
    DBCC DBREINDEX ('tFacCredit', '' , 0)
    DBCC DBREINDEX ('tFacLoan', '' , 0)
    DBCC DBREINDEX ('tGood', '' , 0)
    DBCC DBREINDEX ('tGoodLevel1', '' , 0)
    DBCC DBREINDEX ('tGoodLevel2', '' , 0)
    DBCC DBREINDEX ('tInventory', '' , 0)
    DBCC DBREINDEX ('tHistory', '' , 0)
    DBCC DBREINDEX ('tInventory_Good', '' , 0)
    DBCC DBREINDEX ('tPer', '' , 0)
    DBCC DBREINDEX ('tRepFacEditM', '' , 0)
    DBCC DBREINDEX ('tStation_Inventory_Good', '' , 0)
    DBCC DBREINDEX ('tStations', '' , 0)
    DBCC DBREINDEX ('tSupplier', '' , 0)
    DBCC DBREINDEX ('tUser', '' , 0)
    DBCC DBREINDEX ('tHavaleM', '' , 0)
    DBCC DBREINDEX ('tHavaleD', '' , 0)

--    SET @Str = N'DBCC SHRINKFILE (N''' + RTRIM(LTRIM(@DataFile)) + '''' + ')'
----PRINT @Str
--    EXECUTE sp_executesql @str
--
--
--    SET @Str = N'DBCC SHRINKFILE (N''' + RTRIM(LTRIM(@LogFile)) + '''' + ')'
--    EXECUTE sp_executesql @str
--===============================================


DELETE FROM dbo.tblSamar_TableUsage


GO


ALTER   PROCEDURE [dbo].[Insert_AutoHavale]
    (
      @Branch INT,
      @InventoryNo INT,
      @AccountYear SMALLINT,
      @Status INT,
      @FromDate NVARCHAR(8),
      @ToDate NVARCHAR(8),
      @Date NVARCHAR(8),
      @User INT,
      @NvcDescription NVARCHAR(150),
      @Result INT OUT
		
    )
AS 
    BEGIN
        BEGIN TRAN
	DECLARE @LossStatus INT 
	IF @Status = 2 SET @LossStatus = 3
	ELSE IF @Status <> 2 SET @LossStatus = 0

        DECLARE @intSerialNo INT
        DECLARE @No INT 

        IF @Status = 2 
            SELECT  @NO = ISNULL(MAX([NO]), 0) + 1
            FROM    tFacM
            WHERE   Status = 6
                    AND Branch = @Branch
                    AND AccountYear = @AccountYear



        DECLARE @ReturnTable TABLE
            (
              Row INT IDENTITY(1, 1)
                      NOT NULL,
              Amount FLOAT NOT NULL,
              GoodCode INT NOT NULL,
              BuyPrice FLOAT NOT NULL
            )
 
        INSERT  INTO @ReturnTable
                (
                  Amount,
                  GoodCode,
                  BuyPrice
                )
                SELECT  CAST(SUM(T.Amount) AS DECIMAL(19,3)) ,
                        T.GoodCode,
                        T.BuyPrice
                FROM    ( SELECT    dbo.tUsePercent.GoodFirstCode AS GoodCode,
                                    ( dbo.tFacD.Amount
                                      * ( dbo.tUsePercent.fltUsedValue
                                          + ISNULL(dbo.tUsePercent.Pert, 0) ) ) AS Amount,
                                    ( SELECT    BuyPrice
                                      FROM      dbo.tGood
                                      WHERE     dbo.tGood.Code = dbo.tUsePercent.GoodFirstCode
                                    ) AS BuyPrice
                          FROM      dbo.tFacM
                                    JOIN dbo.tFacD ON dbo.tFacM.Branch = dbo.tFacD.Branch
                                                      AND dbo.tFacM.intSerialNo = dbo.tFacD.intSerialNo
                                    JOIN dbo.tUsePercent ON dbo.tFacD.GoodCode = dbo.tUsePercent.GoodCode
                                                            AND dbo.tFacD.ServePlace = dbo.tUsePercent.intServePlace
                                    JOIN dbo.tGood ON dbo.tFacD.GoodCode = dbo.tGood.Code
                          WHERE     tfacm.Branch = @Branch
                                    AND tfacm.Recursive = 0
                                    AND (tfacm.status = @Status OR dbo.tFacM.Status = @LossStatus)
                                    AND tfacm.Date >= @FromDate
                                    AND tfacm.Date <= @ToDate
                                    AND tfacm.bitHavaleResid = 0
                                    AND tfacd.intInventoryNo = @InventoryNo
                                    AND ( SELECT    dbo.tGood.GoodType
                                          FROM      dbo.tGood
                                          WHERE     dbo.tGood.Code = dbo.tUsePercent.GoodFirstCode
                                        ) <> 4
                          UNION ALL
                          SELECT    dbo.tFacD.GoodCode,
                                    dbo.tFacD.Amount,
                                    dbo.tGood.BuyPrice
                          FROM      dbo.tFacM
                                    JOIN dbo.tFacD ON dbo.tFacM.Branch = dbo.tFacD.Branch
                                                      AND dbo.tFacM.intSerialNo = dbo.tFacD.intSerialNo
                                    JOIN dbo.tGood ON dbo.tFacD.GoodCode = dbo.tGood.Code
                          WHERE     dbo.tFacM.Branch = @Branch
                                    AND tfacm.Recursive = 0
                                    AND tfacm.status = @Status
                                    AND tfacm.Date >= @FromDate
                                    AND tfacm.Date <= @ToDate
                                    AND tfacm.bitHavaleResid = 0
                                    AND tfacd.intInventoryNo = @InventoryNo
                                    AND dbo.tFacD.GoodCode NOT IN (
                                    SELECT  dbo.tUsePercent.GoodCode
                                    FROM    dbo.tUsePercent
                                    WHERE   dbo.tUsePercent.intServePlace = dbo.tFacD.ServePlace )
                                    AND dbo.tGood.GoodType = 3
                        ) T
                GROUP BY T.GoodCode,
                        T.BuyPrice


		
        DECLARE @SumTotal INT 
        SELECT  @SumTotal = SUM(BuyPrice * Amount )
        FROM    @ReturnTable

		DECLARE @ShiftNo INT 
		DECLARE @TempNo INT 

		SET @ShiftNo= dbo.Get_Shift(GETDATE())      
		SET @TempNo = (SELECT ISNULL(MAX([TempNo]),0)+1 FROM tFacM WHERE Status=@Status  And Branch =  @Branch AND Date = @Date AND ShiftNo = @ShiftNo)      


        INSERT  INTO tFacM
                (
                  --intSerialNo ,
                  [No],
                  [Date],
                  RegDate,
                  Status,
                  Customer,
                  SumPrice,
                  StationId,
                  Recursive,
                  CarryFeeTotal,
                  PackingTotal,
                  DiscountTotal,
                  [Time],
                  [User],
                  shiftNo,
                  incharge,
                  FacPayment,
                  Balance,
                  Branch,
                  AccountYear,
                  NvcDescription,
                  OrderType ,
                  TempNo
			  
                )
        VALUES  (
                  --@IdentityNo ,
                  @NO,
                  @Date,
                  dbo.Shamsi(GETDATE()),
                  6,
                  -1,
                  @SumTotal,
                  1,
                  0,
                  0,
                  0,
                  0,
                  dbo.SetTimeFormat(GETDATE()),
                  @User,
                  @ShiftNo ,--dbo.Get_Shift(GETDATE()) ,
                  NULL,
                  0,
                  0,
                  @Branch, --dbo.Get_Current_Branch(),
                  @AccountYear,
                  @NvcDescription,
                  2 ,
                  @TempNo
                )
        IF @@ERROR <> 0 
            GOTO EventHandler

        SET @intserialNo = SCOPE_IDENTITY()  

 
        INSERT  INTO tFacD
                (
                  intRow,
                  Amount,
                  GoodCode,
                  FeeUnit,
                  Discount,
                  Rate,
                  [ExpireDate],
                  intInventoryNo,
                  DestInventoryNo, --Because Has a Relation and Can not insert for  Another Branch
                  DifferencesCodes,
                  DifferencesDescription,
                  intSerialNo,
                  Branch,
                  ServePlace
                )
                SELECT  tmpTable.Row,
                        tmpTable.Amount,
                        tmpTable.GoodCode,
                        BuyPrice, --FeeUnit ,
                        0, --Discount ,
                        1, --tmpTable.Rate ,
                        '', --tmpTable.[ExpireDate] ,
                        @InventoryNo,
                        NULL,
                        '', --DifferencesCode ,
                        '', --.DifferencesDescription ,
                        @intSerialNo,
                        @Branch, --dbo.Get_Current_Branch(),
                        1
                FROM    @ReturnTable tmpTable

	--DROP TABLE @ReturnTable
		Exec InsertMojodiCalculate @Status ,  @intserialNo , @AccountYear , @Branch      
		IF @@ERROR <>0      
		GoTo EventHandler      

        EXEC Update_BitHavaleResid @Branch, @InventoryNo, @AccountYear,
            @Status, @FromDate, @ToDate

        COMMIT TRAN
        SET @Result = 1

        RETURN @Result

        EventHandler:
        ROLLBACK TRAN
        SET @Result = -1
        RETURN @Result
    END

GO

