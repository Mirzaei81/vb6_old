

--���� ���� ������ ���� �������� 
--Version  V26_15_Fix5   &  V26_15
--Reports name  :  A5\BuyFactor_A5   & A4\BuyFactor_A4
--��� ��� ����� ���� ������� ���

--��� ���������� ����� ���� ������ ��� ����� ���  
--92/04/23


-----------------------------------
------------------------------����� ���� �� ���� ��� ����--- Step 3

ALTER  PROCEDURE [dbo].[GetServePlaceSellDetail]

    @SystemDate NVARCHAR(50),
    @SystemDay NVARCHAR(50),
    @SystemTime NVARCHAR(50),
    @Date1 VARCHAR(10),
    @Date2 VARCHAR(10),
    @User1 INT,
    @User2 INT,
    @Station1 INT,
    @Station2 INT ,
    @Time1 NVARCHAR(5),
    @Time2 NVARCHAR(5),
    @Status1 INT ,
    @Branch1 INT ,
    @Branch2 INT 
AS 
    DECLARE @tmp1 INT
    DECLARE @tmp2 NVARCHAR(50)
    DECLARE @Time3 NVARCHAR(50)
    DECLARE @Time4 NVARCHAR(50)
    SET @Time3 = @Time1
    SET @Time4 = @time2

    IF @User2 < @User1 
        BEGIN 
            SET @tmp1 = @User2
            SET @User2 = @User1
            SET @User1 = @tmp1	
        END	

    IF @Time2 < @Time1 
        BEGIN
		/*SET @tmp2 = @Time2
		SET @Time2 = @Time1
		SET @Time1 = @tmp2*/
            SET @Time3 = '00:00'
            SET @Time4 = '24:00'
        END
DECLARE @BranchName1 NVARCHAR(20)
DECLARE @BranchName2 NVARCHAR(20)
SELECT @BranchName1 = nvcBranchName FROM dbo.tBranch WHERE dbo.tBranch.Branch = @Branch1
SELECT @BranchName2 = nvcBranchName FROM dbo.tBranch WHERE dbo.tBranch.Branch = @Branch2
	
    SELECT  @SystemDate AS SystemDate,
            @SystemDay AS SystemDay,
            @SystemDay + ' ' + @SystemDate + '    ' + @SystemTime AS Sysdate,
            @Date1 AS DateBefore,
            @Date2 AS DateAfter,
            @Station1 AS FromStation,
            @Station2 AS ToStationID,
            @User1 AS FromUser,
            @User2 AS ToUser,
            dbo.ViewServePlaceSellDetail.* , dbo.tBranch.nvcBranchName
            , @BranchName1 AS BranchName1 , @BranchName2 AS BranchName2
    FROM    dbo.ViewServePlaceSellDetail
            INNER JOIN tServePlace ON tServePlace.intServePlace = ViewServePlaceSellDetail.intServePlace
            INNER JOIN dbo.tBranch ON ViewServePlaceSellDetail.Branch = tBranch.Branch
    WHERE   dbo.ViewServePlaceSellDetail.Status = @status1
            AND [date] >= @Date1
            AND [date] <= @Date2
            AND ViewServePlaceSellDetail.[pPno] >= @User1 
            AND ViewServePlaceSellDetail.[pPno] <= @User2
			AND ( ( ViewServePlaceSellDetail.[Time] >= @Time1
            AND ViewServePlaceSellDetail.[Time] <= @Time4
			)
			OR ( ViewServePlaceSellDetail.[Time] <= @Time2
               AND ViewServePlaceSellDetail.[Time] >= @Time3
             )
			)
            AND dbo.ViewServePlaceSellDetail.status = @status1
            AND ViewServePlaceSellDetail.StationId >= @Station1
            AND ViewServePlaceSellDetail.StationId <= @Station2
            AND ViewServePlaceSellDetail.Branch >= @Branch1
            AND ViewServePlaceSellDetail.Branch <= @Branch2
            
    ORDER BY dbo.ViewServePlaceSellDetail.[No]





GO

ALTER   VIEW dbo.VwBuy_new
AS
SELECT DISTINCT 
                      dbo.tFacM.Branch , dbo.tFacM.[No], dbo.tFacM.[Date], dbo.tFacM.SumPrice, dbo.tFacM.[Time], dbo.tFacM.[User], dbo.tFacM.Recursive, dbo.tFacM.StationId, 
                      dbo.tFacM.ServePlace AS masterserveplace, dbo.tFacD.ServePlace, dbo.tFacM.OrderType, dbo.tFacM.Status, dbo.tFacD.GoodCode, dbo.tGood.Weight, 
                      dbo.tFacD.FeeUnit, dbo.tFacM.ShiftNo, dbo.tFacD.Amount * dbo.tFacD.FeeUnit AS FeeTotal, dbo.tFacM.intSerialNo, dbo.tFacM.FacPayment, 
                      dbo.tFacM.InCharge, dbo.tServePlace.[Description] AS FactorServePlace, 
                      dbo.tServePlace.LatinDescription AS FactorLatinServePlace, dbo.tFacM.Customer, dbo.tFacM.Owner, dbo.tFacM.RegDate, dbo.tGood.NamePrn, 
                      dbo.tGood.LatinNamePrn, ISNULL(dbo.tSupplier.Address, '' ) AS Address,

-- 	        CASE ISNULL(dbo.tSupplier.Unit,0) WHEN 0 THEN ''
-- 					      ELSE  	  N' :  ���� '+CAST(dbo.tSupplier.Unit AS NVARCHAR(50)) 
-- 	        END AS Unit,
-- 
-- 	        CASE ISNULL(dbo.tSupplier.InternalNo,0) WHEN 0 THEN ''
-- 						   ELSE  N' : �����  '+ CAST(dbo.tSupplier.InternalNo AS NVARCHAR(50)) 
-- 	         END AS InternalNo,
-- 
-- 	        CASE ISNULL(dbo.tSupplier.Flour,0) WHEN 0 THEN ''
-- 					       ELSE N' : ���� '+CAST(dbo.tSupplier.Flour AS NVARCHAR(50)) 
-- 	         END AS Flour,

	       -- CASE ISNULL((dbo.tPer.nvcFirstName + dbo.tPer.nvcSurName), N'0') 
                --      WHEN N'0' THEN N' ' ELSE dbo.tPer.nvcFirstName + ' ' + dbo.tPer.nvcSurName END AS GarsonName, 
                 --     CASE dbo.tPer.Gender WHEN 0 THEN N'����' WHEN 1 THEN N'����' END AS GarsonGender, 
                  --    CASE ISNULL(LTRIM(RTRIM(dbo.tFacD.DifferencesDescription)), '') 
                  --    WHEN '' THEN '-' ELSE dbo.tFacD.DifferencesDescription END AS DifferencesDescription,  dbo.tFacM.TableNo As TableCode,dbo.tTable.[Name] As TableDesc,
                     CASE CAST(dbo.tFacM.BascoleNo AS NVARCHAR(50)) 
                      WHEN NULL THEN '' WHEN '0' THEN '' ELSE CAST(dbo.tFacM.BascoleNo AS NVARCHAR(50)) + SPACE(3) + N'   :�����' END AS BascoleNo, 
                      CASE dbo.tSupplier.Tel1 WHEN NULL THEN '' WHEN '' THEN '' ELSE dbo.tSupplier.Tel1 + SPACE(5) + N'   : ����' END AS Tel1, CASE dbo.tSupplier.Tel2 WHEN NULL
                       THEN '' WHEN '' THEN '' ELSE dbo.tSupplier.Tel2 + SPACE(5) + N'   : ���� ' END AS Tel2,
 	          CASE dbo.tSupplier.[Name] + SPACE(3) + dbo.tSupplier.family WHEN NULL      THEN dbo.tSupplier.WorkName WHEN '' THEN dbo.tSupplier.WorkName 
                       ELSE    CASE dbo.tSupplier.Sex WHEN 0 THEN N' ����  ' + dbo.tSupplier.[Name] + '  ' + dbo.tSupplier.family 
		          ELSE  N' ���� '  + dbo.tSupplier.[Name] + '  ' + dbo.tSupplier.family
                                     End 
                       END AS family, 
                      dbo.tFacM.DiscountTotal , dbo.tFacM.CarryFeeTotal, 
                      dbo.tFacM.ServiceTotal,  dbo.tFacM.PackingTotal, 
                      CASE dbo.tFacD.Amount WHEN 0.0 THEN NULL ELSE CAST(dbo.tFacD.Amount AS DECIMAL(10, 3)) END AS WeightTotal, 
                      CASE dbo.tFacD.Amount WHEN 0.0 THEN NULL ELSE CAST(dbo.tFacD.Amount AS DECIMAL(10, 3)) END AS Amount, dbo.tSupplier.membershipid , tFacm.Balance ,
	        dbo.tGood.Unit As UnitType ,dbo.tFacM.AccountYear , dbo.tUnitGood.[Description] As UnitDesc , dbo.tStatusType.NvcDescription AS StatusName
	       -- ,CASE dbo.tSupplier.Sex WHEN 0 THEN N'����' WHEN 1 THEN N'����' END AS CustGender
	       , tfacm.TaxTotal , tfacm.DutyTotal
FROM           dbo.tFacM INNER JOIN
                      dbo.tFacD ON dbo.tFacM.intSerialNo = dbo.tFacD.intSerialNo AND dbo.tFacM.Branch = dbo.tFacD.Branch  INNER JOIN
                      dbo.tGood ON dbo.tFacD.GoodCode = dbo.tGood.Code INNER JOIN
                      dbo.tUnitGood ON dbo.tGood.Unit = dbo.tUnitGood.Code INNER JOIN
                      dbo.tServePlace ON dbo.tFacM.ServePlace = dbo.tServePlace.intServePlace INNER JOIN
					dbo.tStatusType ON dbo.tFacM.Status = dbo.tStatusType.intStatusNo INNER JOIN 
                      dbo.tPrinting ON dbo.tServePlace.intServePlace = dbo.tPrinting.ServePlace LEFT OUTER JOIN
                      tSupplier ON tfacM.Owner = tSupplier.code and  tfacM.Branch = tSupplier.Branch  --LEFT OUTER JOIN
--                      tPer ON dbo.tFacM.Incharge = dbo.tPer.PPNO and dbo.tFacM.Branch = dbo.tPer.Branch   LEFT OUTER JOIN
--                      tTable ON dbo.tFacM.TableNo = dbo.tTable.[No] and  dbo.tFacM.Branch = dbo.tTable.[Branch]
Where 		dbo.tFacM.Branch = dbo.Get_Current_Branch()





GO



ALTER  VIEW VwBuy_Multipart
AS
SELECT DISTINCT 
                	dbo.VwBuy_new.*, tprinting.PrinterNo, 	
		CASE dbo.tPrinting.Arm 
			WHEN 1 THEN dbo.tprinters.Arm 
			ELSE NULL 
		END AS Arm, 
                      	CASE 
			WHEN dbo.tPrinting.Linefeed >= 1 THEN dbo.Repeater(dbo.tprinters.LineFeed, dbo.tPrinting.Linefeed) 
			ELSE NULL 
		END AS Linefeed, 
                      	CASE dbo.tPrinting.Cutter 
			WHEN 1 THEN dbo.tprinters.Cut 
			ELSE NULL 
		END AS Cutter, 
		tprinting.barcode, tprinting.DirectRpt,dbo.tServePlace.[Description] AS ItemServePlace, t2.[Description], tprinting.printformat, noticedescription AS NoticeDescription1, 
                      	NoticeLatinDescription, t2.LatinDescription, dbo.tServePlace.LatinDescription AS ItemLatinServePlace
FROM         dbo.VwBuy_new 
		INNER JOIN
                      	tPrinting ON (dbo.VwBuy_new.Status = dbo.tPrinting.Status AND dbo.VwBuy_new.ServePlace = tprinting.ServePlace AND dbo.VwBuy_new.StationId = tprinting.StationId) 
		INNER JOIN
                      	tprinters ON tprinting.PrinterNo = tprinters.printerNo 
		INNER JOIN
                      	tServePlace ON dbo.VwBuy_new.ServePlace = tServePlace.intServePlace 
		INNER JOIN
                      	tServePlace t2 ON VwBuy_new.masterServePlace = t2.intServePlace 
		INNER JOIN
                      	tprintformat ON tprinting.printformat = tprintformat.printformat 
		LEFT OUTER JOIN
                      	tnoticedescription ON tprintformat.noticeno = tnoticedescription.noticeno
Where 		tPrinting.Branch = dbo.Get_Current_Branch() And 	tprinters.Branch = dbo.Get_Current_Branch()





GO



ALTER    PROCEDURE dbo.Get_BuyInfo(

	@intLanguage	INT = 0,
	@intFacNo 	INT,
	@PrintFormat 	INT,
	@StationId 	INT,
	@Status		INT,
	@intPrinterNo   INT,
	@Mode	 	INT = 2,
	@AccountYear	Smallint = NULL ,
	@PartitionId INT = NULL 
)
AS
If @AccountYear Is Null 
	Set @AccountYear = dbo.get_AccountYear() 

	    	SELECT  dbo.[VwBuy_Multipart].[No], dbo.[VwBuy_Multipart].[Date], 
			dbo.[VwBuy_Multipart].[SumPrice], dbo.[VwBuy_Multipart].[Time], 
			dbo.[VwBuy_Multipart].[User], dbo.[VwBuy_Multipart].[Recursive], 
			dbo.[VwBuy_Multipart].[StationId], dbo.[VwBuy_Multipart].[masterserveplace], 
			dbo.[VwBuy_Multipart].[ServePlace], dbo.[VwBuy_Multipart].[OrderType], 
			dbo.[VwBuy_Multipart].[Status], dbo.[VwBuy_Multipart].[GoodCode], 
			dbo.[VwBuy_Multipart].[Weight], dbo.[VwBuy_Multipart].[FeeUnit], 
			dbo.[VwBuy_Multipart].[ShiftNo], dbo.[VwBuy_Multipart].[FeeTotal], 
			dbo.[VwBuy_Multipart].[intSerialNo], dbo.[VwBuy_Multipart].[FacPayment], 
			--dbo.[VwBuy_Multipart].[InCharge], 

			dbo.[VwBuy_Multipart].[Customer], dbo.[VwBuy_Multipart].[Owner], 
			dbo.[VwBuy_Multipart].[RegDate], 

			--dbo.[VwBuy_Multipart].[GarsonName], [VwBuy_Multipart].[GarsonGender], 
			--dbo.[VwBuy_Multipart].[DifferencesDescription], [VwBuy_Multipart].[TableDesc], 
			dbo.[VwBuy_Multipart].[BascoleNo], [VwBuy_Multipart].[Tel1], 
			dbo.[VwBuy_Multipart].[Tel2], [VwBuy_Multipart].[family], 
			dbo.[VwBuy_Multipart].[DiscountTotal], [VwBuy_Multipart].[CarryFeeTotal], 
			dbo.[VwBuy_Multipart].[ServiceTotal], [VwBuy_Multipart].[PackingTotal], 
			dbo.[VwBuy_Multipart].[WeightTotal], [VwBuy_Multipart].[Amount], 
			dbo.[VwBuy_Multipart].[membershipid], [VwBuy_Multipart].[PrinterNo], 
			dbo.[VwBuy_Multipart].[Arm], [VwBuy_Multipart].[Linefeed], 
			dbo.[VwBuy_Multipart].[Cutter], 

			dbo.[VwBuy_Multipart].[printformat],
       		             dbo.[VwBuy_Multipart].[DirectRpt] , dbo.[VwBuy_Multipart].[Balance] ,
			VwBuy_Multipart.Address /*+ ' '+ VwBuy_Multipart.Flour + ' ' + VwBuy_Multipart.Unit 
			+ ' '+VwBuy_Multipart.InternalNo*/ AS CustomerAddress,



			CASE @intLanguage 
				WHEN 0 THEN
					CASE @Mode 
						WHEN 1 THEN N'�ǁ ����'
						WHEN 4 THEN N'������'
						ELSE ''
					END
				WHEN 1 THEN 
					CASE @Mode 
						WHEN 1 THEN N'Repeated Print'
						WHEN 4 THEN N'Edited'
                           			ELSE ''
					END
			END AS ReportHeder,

			CASE @intLanguage 
				WHEN 0 THEN
					CASE dbo.VwBuy_Multipart.Recursive 	
						WHEN  0 THEN ''
						WHEN 1 THEN N'������'
					END
				WHEN 1 THEN 
					CASE dbo.VwBuy_Multipart.Recursive 	
						WHEN  0 THEN ''
						WHEN 1 THEN N'Reffered'
					END
			END AS RecursievAlert,

		    	CASE @intLanguage 	
				WHEN 0 THEN dbo.VwBuy_Multipart.NamePrn
				WHEN 1 THEN dbo.VwBuy_Multipart.LatinNamePrn
			END AS GoodName,


			CASE @intLanguage 	
				WHEN 0 THEN VwBuy_Multipart.ItemServePlace
				WHEN 1 THEN VwBuy_Multipart.ItemLatinServePlace
			END AS ItemServePlaceDesc,

			CASE @intLanguage 	
				WHEN 0 THEN VwBuy_Multipart.NoticeDescription1
				WHEN 1 THEN VwBuy_Multipart.NoticeLatinDescription
			END AS NoticeDescription,

			CASE @intLanguage 	
				WHEN 0 THEN VwBuy_Multipart.FactorServePlace
				WHEN 1 THEN VwBuy_Multipart.FactorLatinServePlace
			END AS FactorServeDescription,

	      	          CASE VwBuy_Multipart.barcode 
				WHEN 1 THEN  (SELECT TOP 1  dbo.BarcodeGenerator(dbo.VwBuy_Multipart.ServePlace,@intFacNo) where [No]= @intFacNo and Status = 2 )
				ELSE '' END AS Barcode ,

			dbo.[VwBuy_Multipart].[UnitType] , dbo.[VwBuy_Multipart].[UnitDesc] ,dbo.[VwBuy_Multipart].StatusName

			, VwBuy_Multipart.Taxtotal , VwBuy_Multipart.DutyTotal
		FROM dbo.VwBuy_Multipart

		WHERE 	No=@intFacNo 	
			--AND (PrintFormat  = @PrintFormat OR @PrintFormat =0 )
			--AND GoodCode NOT IN (SELECT GoodCode  FROM tPrinterGood WHERE intPrinterFormat = @PrintFormat )
			--AND ( dbo.VwBuy_Multipart.StationId = @StationId OR @Mode  =  0 )
			AND dbo.VwBuy_Multipart.status =@Status 
			And VwBuy_Multipart.AccountYear = @AccountYear
			--AND   VwBuy_Multipart.PrinterNo=@intPrinterNo
			AND   VwBuy_Multipart.Branch = dbo.Get_Current_Branch()


GO

