

--ScriptV26_15_Fix1_Added1
--910407

ALTER   PROCEDURE [dbo].[PayFactors_CustCredit_Account] (
@No BIGINT, 
@Uid int ,
@Customer Bigint ,
@SumPrice Bigint ,
@AccountYear SmallInt ,
@intSerialNo BIGINT ,
@Branch INT 
 ) 

AS

If @intSerialNo = 0 SET @intSerialNo = Null

DECLARE @newtime nvarchar(5)
select @newtime=dbo.setTimeFormat(getdate())
DECLARE @RegDate nvarchar(20)
Select @RegDate = dbo.Get_ShamsiDate_For_Current_Shift(getdate())



Declare @Description Nvarchar(50)
Set @Description = N' ������ ���� ��� ������' + CAST(@No as Nvarchar(10))
Declare @NoRecieved Bigint
set @NoRecieved = (Select isnull(max([No]),0)+ 1 as [No]  From tblAcc_Recieved  Where  AccountYear = @AccountYear  And Branch =  @Branch)
Exec Insert_tblAcc_Recieved  @NoRecieved , 1 , @RegDate , @Uid ,  @Description , @SumPrice , 3 , @Customer ,@Uid , @AccountYear , @intSerialNo , @Branch

	insert into 	dbo.tHistory
	(intSerialNo , RegDate , RegTime , UID , ActionCode , Branch )
	select @intSerialNo , dbo.Shamsi(GetDate()) , dbo.setTimeFormat(getdate()) , @UID , 5 ,  @Branch





GO
