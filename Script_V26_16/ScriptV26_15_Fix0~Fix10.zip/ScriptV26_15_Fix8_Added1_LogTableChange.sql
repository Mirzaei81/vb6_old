

--����� ��� �ǐ ����� ��� �� ���� �� �� 
--�� ����΍� �������� ��� �ǐ �� ���� �����
--92/07/06

--V26_15 & V26_14 & V26_12


INSERT INTO dbo.tAction (
	ActionCode,
	ActionDescription,
	ActionLatinDescription,
	isLog
) VALUES ( 
	/* ActionCode - int */ 20,
	/* ActionDescription - nvarchar(50) */ N'����� ��� �� ���� �� ��',
	/* ActionLatinDescription - nvarchar(50) */ N'TableChangeInPpc',
	/* isLog - bit */ 1 ) 

GO 


ALTER   PROCEDURE Update_InvoiceTable_ForPPC
@intTableNo int,
@intSerialNo int

 
 AS

Declare @OldTableNo   int  
SET  @OldTableNo =  IsNull((SELECT tFacM.TableNo FROM tFacM WHERE intSerialNo = @intSerialNo and Branch = dbo.Get_Current_Branch()) , 0)  
PRINT  @OldTableNo

update tTable set Empty=1  where
[no] in (select  TableNo FROM tfacM WHERE intSerialNo=@intSerialNo and Branch = dbo.Get_Current_Branch())

update tFacM set TableNo=@intTableNo WHERE intSerialNo=@intSerialNo and Branch = dbo.Get_Current_Branch()
update  tTable set Empty=0 where [No]=@intTableNo

---------------------------------------------------------------------------------
--����� ��� �ǐ �� ����΍�
DECLARE @LogTableChange AS INT 
DECLARE @UID INT 
select  @UID = [User] FROM tfacM WHERE intSerialNo=@intSerialNo and Branch = dbo.Get_Current_Branch()

SELECT  @LogTableChange = COUNT(*) FROM dbo.tAction WHERE ActionCode = 20
IF @LogTableChange > 0
	insert into 
	dbo.tHistory
	(intSerialNo , RegDate , RegTime , UID , ActionCode , Branch )
	values 
	(@intSerialNo , dbo.Shamsi(GetDate()) , dbo.setTimeFormat(getdate()) , @UID , 20 ,  dbo.Get_Current_Branch() )

-----------------------------------------------------

	If dbo.Get_TableMonitoring() = 1 AND IsNull(@intTableNo , 0) <> @OldTableNo   ---Table Monitoring      
	 	Begin      
		DECLARE @intTableUsedNo INT      
		SET @intTableUsedNo = (SELECT TOP 1 intTableUsedNo FROM vwSamar_TableUsage_BusyTable      
		WHERE vwSamar_TableUsage_BusyTable.intTableNo=@OldTableNo and vwSamar_TableUsage_BusyTable.intBranch=dbo.Get_Current_Branch() ORDER BY intTableUsedNo DESC   )   
		SET @intTableUsedNo = ISNULL(@intTableUsedNo , 0) 
		UPDATE tblSamar_TableUsage SET tblSamar_TableUsage.intTableNo = @intTableNo      
		WHERE  tblSamar_TableUsage.intTableUsedNo = @intTableUsedNo and intBranch = dbo.Get_Current_Branch()     
		END        



GO



