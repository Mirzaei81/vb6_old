
--V26_15_Fix2

--����� ���� ����
--����� ������� 
--����� 3 ���� �� ������� ���� ����� 
--91/04/22

INSERT  INTO dbo.tblPub_Script2
        ( Version ,
          Script ,
          LastScriptNo ,
          [Date] ,
          FixNumber
        )
VALUES  ( 26 ,
          15 ,
          0 ,
          dbo.shamsi(GETDATE()) ,
          2
        )
GO


ALTER   PROCEDURE [dbo].[Get_Good_Levels_Supported] 
(
	@intLanguage int , 
	@SupportedGoodType int  
) 
AS

SELECT     Code, Level1, Level2,
	case @intLanguage when 0 Then Name
			when 1 then  LatinName 
			end as Name, 
	
	case @intLanguage when 0 Then DesLevel1
			when 1 then  LatinDesLevel1 
			end as DesLevel1, 
	
	case @intLanguage when 0 Then DesLevel2
			when 1 then  LatinDesLevel2 
			end as DesLevel2 ,

	case @intLanguage when 0 Then Description
			when 1 then  LatinDescription 
			end as UnitDescription 
         , FinalPrice
	,dbo.tblTotal_ChargeGood.ChargeCooking,dbo.tblTotal_ChargeGood.ChargeServe,dbo.tblTotal_ChargeGood.PercentOverFlow

FROM         dbo.vw_Good_Levels
		LEFT OUTER JOIN
		dbo.tblTotal_ChargeGood ON dbo.tblTotal_ChargeGood.GoodCode=dbo.vw_Good_Levels.Code
where GoodType = @SupportedGoodType OR  GoodType = 3



GO

--SELECT * FROM dbo.tObjects WHERE ObjectParent = 126


UPDATE dbo.tObjects SET ObjectName = N'����� ������ ����� ����' WHERE ObjectId = 'frmGoodDiscount'
GO 

UPDATE dbo.tObjects SET ObjectParent = 103 WHERE ObjectId = 'frmGood'
GO 

UPDATE dbo.tObjects SET ObjectParent = 103 WHERE ObjectId = 'frmCodingGood'
GO 

UPDATE dbo.tObjects SET intObjectCode = 120 WHERE ObjectId = 'frmPer'
GO 


ALTER  Procedure [dbo].[Get_Good_Level_Difference](@intLanguage int ,@DifferenceCode int )
AS

IF @DifferenceCode <> -1 
	SELECT    	dbo.tGood.Code, dbo.tGood.Level1, dbo.tGood.Level2,
			case @intLanguage
				when 0 then dbo.tGood.[Name]
				when 1 then dbo.tGood.LatinName
			end as [Name] , 
			
			case @intLanguage
				when 0 then dbo.tGood.NamePrn
				when 1 then dbo.tGood.LatinNamePrn
			end as NamePrn , 

			case @intLanguage
				when 0 then dbo.tGoodLevel1.[Description]
				when 1 then dbo.tGoodLevel1.LatinDescription
			end AS Deslevel1 , 

			case @intLanguage
				when 0 then dbo.tGoodLevel2.[Description]
				when 1 then dbo.tGoodLevel2.LatinDescription
			end AS Deslevel2 , 

			dbo.tGood.TechnicalNo, dbo.tGood.BarCode, dbo.tGood.Unit, dbo.tGood.Model, dbo.tGood.Weight, 
			dbo.tGood.NumberOfUnit, 
					dbo.tGood.ProductCompany, dbo.tGood.SellPrice, dbo.tGood.BuyPrice,  
			dbo.tGood.BtnAscDefault, dbo.tGood.BtnTz1No, dbo.tGood.GoodType, 

			case @intLanguage
				when 0 then dbo.tDifferences.[Difference]
				when 1 then dbo.tDifferences.LatinDifference
			end AS [Difference] , 

			dbo.tDifferences.Code AS DifferenceCode, 
			case  
				when DifferenceCode is not null then 1
				else 0
			end  as Selected
	                      
	FROM         	dbo.tGood 
						  INNER JOIN dbo.tGoodLevel1 ON dbo.tGood.Level1 = dbo.tGoodLevel1.Code 
						  INNER JOIN dbo.tGoodLevel2 ON dbo.tGood.Level2 = dbo.tGoodLevel2.Code 
						  INNER JOIN (Select * from dbo.TGood_Difference where DifferenceCode = @DifferenceCode )t ON dbo.tGood.Code = t.GoodCode  
						  LEFT outer JOIN dbo.tDifferences ON t.DifferenceCode = dbo.tDifferences.Code
ELSE
	SELECT    	dbo.tGood.Code, dbo.tGood.Level1, dbo.tGood.Level2,
			case @intLanguage
				when 0 then dbo.tGood.[Name]
				when 1 then dbo.tGood.LatinName
			end as [Name] , 
			
			case @intLanguage
				when 0 then dbo.tGood.NamePrn
				when 1 then dbo.tGood.LatinNamePrn
			end as NamePrn , 

			case @intLanguage
				when 0 then dbo.tGoodLevel1.[Description]
				when 1 then dbo.tGoodLevel1.LatinDescription
			end AS Deslevel1 , 

			case @intLanguage
				when 0 then dbo.tGoodLevel2.[Description]
				when 1 then dbo.tGoodLevel2.LatinDescription
			end AS Deslevel2 , 

			dbo.tGood.BarCode, dbo.tGood.Unit, dbo.tGood.Model, dbo.tGood.Weight, 
			dbo.tGood.NumberOfUnit, 
			dbo.tGood.ProductCompany, dbo.tGood.SellPrice, dbo.tGood.BuyPrice,  
			dbo.tGood.GoodType, 

			'' AS [Difference] , 

			'' AS DifferenceCode, 
			0 as Selected
	                      
	FROM         	dbo.tGood 
						  INNER JOIN dbo.tGoodLevel1 ON dbo.tGood.Level1 = dbo.tGoodLevel1.Code 
						  INNER JOIN dbo.tGoodLevel2 ON dbo.tGood.Level2 = dbo.tGoodLevel2.Code 


GO




ALTER   PROCEDURE [dbo].[Get_tblAcc_Recieved]
    (
      @No Bigint,
      @Direction int,
      @AccountYear SMALLINT,
      @Branch INT  
											
    )
AS 
    BEGIN
        If @Direction = 0 
            Begin
                SELECT  @No = ISNULL(MIN([No]), 0)
                FROM    dbo.Vw_tblAcc_Recieved_User
                WHERE   dbo.Vw_tblAcc_Recieved_User.AccountYear = @AccountYear AND Vw_tblAcc_Recieved_User.Branch = @Branch
                SELECT  Vw_tblAcc_Recieved_User.Bestankar,
                        Vw_tblAcc_Recieved_User.[Uid],
                        Vw_tblAcc_Recieved_User.[User_Name],
                        Vw_tblAcc_Recieved_User.Tafsili,
                        Vw_tblAcc_Recieved_User.[Date],
                        Vw_tblAcc_Recieved_User.[List],
                        Vw_tblAcc_Recieved_User.[RegTime],
                        Vw_tblAcc_Recieved_User.[Description],
                        Vw_tblAcc_Recieved_User.[No],
                        Vw_tblAcc_Recieved_User.[RecieveType],
                        Vw_tblAcc_Recieved_User.[Code_Bes],
                        Vw_tblAcc_Recieved_User.[Person_Name],
                        Vw_tblAcc_Recieved_User.AddUser,
                        dbo.Vw_tblAcc_Recieved_User.AccountYear
                FROM    Vw_tblAcc_Recieved_User
                WHERE   Vw_tblAcc_Recieved_User.[no] = @No AND Vw_tblAcc_Recieved_User.Branch = @Branch
                        AND dbo.Vw_tblAcc_Recieved_User.AccountYear = @AccountYear
                ORDER BY Vw_tblAcc_Recieved_User.list 
            End		

        Else 
            if @Direction = 1 
                Begin
					SELECT  @No = ISNULL(Max([No]), 0)
					FROM    dbo.Vw_tblAcc_Recieved_User
					WHERE   dbo.Vw_tblAcc_Recieved_User.AccountYear = @AccountYear AND Vw_tblAcc_Recieved_User.Branch = @Branch AND dbo.Vw_tblAcc_Recieved_User.[No]< @No 
                    SELECT  Vw_tblAcc_Recieved_User.Bestankar,
                            Vw_tblAcc_Recieved_User.[Uid],
                            Vw_tblAcc_Recieved_User.[User_Name],
                            Vw_tblAcc_Recieved_User.Tafsili,
                            Vw_tblAcc_Recieved_User.[Date],
                            Vw_tblAcc_Recieved_User.[List],
                            Vw_tblAcc_Recieved_User.[RegTime],
                            Vw_tblAcc_Recieved_User.[Description],
                            Vw_tblAcc_Recieved_User.[No],
                            Vw_tblAcc_Recieved_User.[RecieveType],
                            Vw_tblAcc_Recieved_User.[Code_Bes],
                            Vw_tblAcc_Recieved_User.[Person_Name],
                            Vw_tblAcc_Recieved_User.AddUser,
                            Vw_tblAcc_Recieved_User.AccountYear
                    FROM    Vw_tblAcc_Recieved_User
                    WHERE   Vw_tblAcc_Recieved_User.[no] = @No AND Vw_tblAcc_Recieved_User.Branch = @Branch
                            AND dbo.Vw_tblAcc_Recieved_User.AccountYear = @AccountYear
                    ORDER BY Vw_tblAcc_Recieved_User.list 
                End
			
            Else 
                if @Direction = 2 
                    BEGIN
						SELECT  @No = ISNULL(Min([No]), 0)
						FROM    dbo.Vw_tblAcc_Recieved_User
						WHERE   dbo.Vw_tblAcc_Recieved_User.AccountYear = @AccountYear AND Vw_tblAcc_Recieved_User.Branch = @Branch AND dbo.Vw_tblAcc_Recieved_User.[No]> @No 
                        SELECT  Vw_tblAcc_Recieved_User.Bestankar,
                                Vw_tblAcc_Recieved_User.[Uid],
                                Vw_tblAcc_Recieved_User.[User_Name],
                                Vw_tblAcc_Recieved_User.Tafsili,
                                Vw_tblAcc_Recieved_User.[Date],
                                Vw_tblAcc_Recieved_User.[List],
                                Vw_tblAcc_Recieved_User.[RegTime],
                                Vw_tblAcc_Recieved_User.[Description],
                                Vw_tblAcc_Recieved_User.[No],
                                Vw_tblAcc_Recieved_User.[RecieveType],
                                Vw_tblAcc_Recieved_User.[Code_Bes],
                                Vw_tblAcc_Recieved_User.[Person_Name],
                                Vw_tblAcc_Recieved_User.AddUser,
                                Vw_tblAcc_Recieved_User.AccountYear
                        FROM    Vw_tblAcc_Recieved_User
                        WHERE   Vw_tblAcc_Recieved_User.[no] = @No AND Vw_tblAcc_Recieved_User.Branch = @Branch
                                AND dbo.Vw_tblAcc_Recieved_User.AccountYear = @AccountYear
                        ORDER BY Vw_tblAcc_Recieved_User.list 
                    END	
			
                Else 
                    if @Direction = 3 
                        BEGIN

                            SELECT  @No = ISNULL(MAX([No]), 0)
                            FROM    dbo.Vw_tblAcc_Recieved_User
                            WHERE   dbo.Vw_tblAcc_Recieved_User.AccountYear = @AccountYear AND Vw_tblAcc_Recieved_User.Branch = @Branch
                            SELECT  Vw_tblAcc_Recieved_User.Bestankar,
                                    Vw_tblAcc_Recieved_User.[Uid],
                                    Vw_tblAcc_Recieved_User.[User_Name],
                                    Vw_tblAcc_Recieved_User.Tafsili,
                                    Vw_tblAcc_Recieved_User.[Date],
                                    Vw_tblAcc_Recieved_User.[List],
                                    Vw_tblAcc_Recieved_User.[RegTime],
                                    Vw_tblAcc_Recieved_User.[Description],
                                    Vw_tblAcc_Recieved_User.[No],
                                    Vw_tblAcc_Recieved_User.[RecieveType],
                                    Vw_tblAcc_Recieved_User.[Code_Bes],
                                    Vw_tblAcc_Recieved_User.[Person_Name],
                                    Vw_tblAcc_Recieved_User.AddUser,
                                    Vw_tblAcc_Recieved_User.AccountYear
                            FROM    Vw_tblAcc_Recieved_User
                            WHERE   Vw_tblAcc_Recieved_User.[no] = @No AND Vw_tblAcc_Recieved_User.Branch = @Branch
                                    AND dbo.Vw_tblAcc_Recieved_User.AccountYear = @AccountYear
                            ORDER BY Vw_tblAcc_Recieved_User.list 
                        END
    END


GO



ALTER  PROCEDURE [dbo].[Get_tblAcc_Cash]
    (
      @No Bigint,
      @Direction int,
      @AccountYear SMALLINT,
      @Branch INT 
    )
AS 
    If @Direction = 0 
        Begin
            SELECT  @No = ISNULL(MIN([No]), 0)
            From    dbo.Vw_tblAcc_Cash_User
            WHERE   dbo.Vw_tblAcc_Cash_User.AccountYear = @AccountYear AND Vw_tblAcc_Cash_User.Branch = @Branch
            SELECT  Vw_tblAcc_Cash_User.Bestankar,
                    Vw_tblAcc_Cash_User.[Uid],
                    Vw_tblAcc_Cash_User.[User_Name],
                    Vw_tblAcc_Cash_User.Tafsili,
                    Vw_tblAcc_Cash_User.[Date],
                    Vw_tblAcc_Cash_User.[List],
                    Vw_tblAcc_Cash_User.[RegTime],
                    Vw_tblAcc_Cash_User.[Description],
                    Vw_tblAcc_Cash_User.[No],
                    Vw_tblAcc_Cash_User.[PaymentType],
                    Vw_tblAcc_Cash_User.[Uid_Bede],
                    Vw_tblAcc_Cash_User.[Person_Name],
                    Vw_tblAcc_Cash_User.AddUser,
                    Vw_tblAcc_Cash_User.AccountYear
            FROM    Vw_tblAcc_Cash_User
            WHERE   Vw_tblAcc_Cash_User.[no] = @No AND dbo.Vw_tblAcc_Cash_User.Branch = @Branch
                    AND Vw_tblAcc_Cash_User.AccountYear = @AccountYear
            ORDER BY Vw_tblAcc_Cash_User.list 
        End		

    ELSE 
        IF @Direction = 1 
            Begin
				SELECT  @No = ISNULL(Max([No]), 0)
				From    dbo.Vw_tblAcc_Cash_User
				WHERE   dbo.Vw_tblAcc_Cash_User.AccountYear = @AccountYear  AND Vw_tblAcc_Cash_User.Branch = @Branch AND Vw_tblAcc_Cash_User.[No] < @No
                SELECT  Vw_tblAcc_Cash_User.Bestankar,
                        Vw_tblAcc_Cash_User.[Uid],
                        Vw_tblAcc_Cash_User.[User_Name],
                        Vw_tblAcc_Cash_User.Tafsili,
                        Vw_tblAcc_Cash_User.[Date],
                        Vw_tblAcc_Cash_User.[List],
                        Vw_tblAcc_Cash_User.[RegTime],
                        Vw_tblAcc_Cash_User.[Description],
                        Vw_tblAcc_Cash_User.[No],
                        Vw_tblAcc_Cash_User.[PaymentType],
                        Vw_tblAcc_Cash_User.[Uid_Bede],
                        Vw_tblAcc_Cash_User.[Person_Name],
                        Vw_tblAcc_Cash_User.AddUser,
                        Vw_tblAcc_Cash_User.AccountYear
                FROM    Vw_tblAcc_Cash_User
                WHERE   Vw_tblAcc_Cash_User.[no] = @No AND dbo.Vw_tblAcc_Cash_User.Branch = @Branch
                        And Vw_tblAcc_Cash_User.AccountYear = @AccountYear
                ORDER BY Vw_tblAcc_Cash_User.list 
            End
		
        ELSE 
            IF @Direction = 2 
                BEGIN
					SELECT  @No = ISNULL(MIN([No]), 0)
					From    dbo.Vw_tblAcc_Cash_User
					WHERE   dbo.Vw_tblAcc_Cash_User.AccountYear = @AccountYear  AND Vw_tblAcc_Cash_User.Branch = @Branch AND Vw_tblAcc_Cash_User.[No] > @No
                    SELECT  Vw_tblAcc_Cash_User.Bestankar,
                            Vw_tblAcc_Cash_User.[Uid],
                            Vw_tblAcc_Cash_User.[User_Name],
                            Vw_tblAcc_Cash_User.Tafsili,
                            Vw_tblAcc_Cash_User.[Date],
                            Vw_tblAcc_Cash_User.[List],
                            Vw_tblAcc_Cash_User.[RegTime],
                            Vw_tblAcc_Cash_User.[Description],
                            Vw_tblAcc_Cash_User.[No],
                            Vw_tblAcc_Cash_User.[PaymentType],
                            Vw_tblAcc_Cash_User.[Uid_Bede],
                            Vw_tblAcc_Cash_User.[Person_Name],
                            Vw_tblAcc_Cash_User.AddUser,
                            Vw_tblAcc_Cash_User.AccountYear
                    FROM    Vw_tblAcc_Cash_User
                    WHERE   Vw_tblAcc_Cash_User.[no] = @No AND dbo.Vw_tblAcc_Cash_User.Branch = @Branch
                            AND Vw_tblAcc_Cash_User.AccountYear = @AccountYear
                    ORDER BY Vw_tblAcc_Cash_User.list 
                End
		
            ELSE 
                IF @Direction = 3 
                    BEGIN	
                        SELECT  @No = ISNULL(MAX([No]), 0)
                        FROM    dbo.Vw_tblAcc_Cash_User
                        WHERE   dbo.Vw_tblAcc_Cash_User.AccountYear = @AccountYear  AND Vw_tblAcc_Cash_User.Branch = @Branch
                        SELECT  Vw_tblAcc_Cash_User.Bestankar,
                                Vw_tblAcc_Cash_User.[Uid],
                                Vw_tblAcc_Cash_User.[User_Name],
                                Vw_tblAcc_Cash_User.Tafsili,
                                Vw_tblAcc_Cash_User.[Date],
                                Vw_tblAcc_Cash_User.[List],
                                Vw_tblAcc_Cash_User.[RegTime],
                                Vw_tblAcc_Cash_User.[Description],
                                Vw_tblAcc_Cash_User.[No],
                                Vw_tblAcc_Cash_User.[PaymentType],
                                Vw_tblAcc_Cash_User.[Uid_Bede],
                                Vw_tblAcc_Cash_User.[Person_Name],
                                Vw_tblAcc_Cash_User.AddUser,
                                Vw_tblAcc_Cash_User.AccountYear
                        FROM    Vw_tblAcc_Cash_User
                        WHERE   Vw_tblAcc_Cash_User.[no] = @No AND dbo.Vw_tblAcc_Cash_User.Branch = @Branch
                                AND Vw_tblAcc_Cash_User.AccountYear = @AccountYear
                        ORDER BY Vw_tblAcc_Cash_User.list 
                    End



GO








