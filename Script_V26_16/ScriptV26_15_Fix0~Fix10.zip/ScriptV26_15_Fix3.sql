


--V26_15_Fix3
--��� ��� ���� �� ������ �������
--������ ���� ������ ���� �� ������ �������
--���� �� ���� ����� ������� ����� �����
-- ����� ����� ������ ��������� ������ �� ��� ������ ��
--91/08/30


INSERT  INTO dbo.tblPub_Script2
        ( Version ,
          Script ,
          LastScriptNo ,
          [Date] ,
          FixNumber
        )
VALUES  ( 26 ,
          15 ,
          0 ,
          dbo.shamsi(GETDATE()) ,
          3
        )
GO




-- V26_15_Fix2_Added1
--����� ����� ���� ����� ��� ��� �� ��� �������
-- ������ �� ��� ����� ���� ������ ������ �� ���� ����� ������� ������ �� ���
--91/04/31

ALTER   PROCEDURE [dbo].[PayFactors_TabletoCustCredit]
    (
      @strSelectedFactors NVARCHAR(4000),
      @strSelectedTables NVARCHAR(4000) ,
      @Branch INT 
    )
AS 
    IF RTRIM(LTRIM(@strSelectedFactors)) <> N'' 
        BEGIN
            UPDATE  tFacM
            SET     FacPayment = 1
            WHERE   intSerialNo IN (
                    SELECT  CAST(word AS BIGINT)
                    FROM    dbo.SplitWithDelimiterNVarChar(@strSelectedFactors,
                                                           N',') )
                    AND dbo.tFacM.Branch = @Branch


            IF @strSelectedTables <> N'' 
				BEGIN 
                UPDATE  tTable
                SET     Empty = 1
                WHERE   [No] IN (
                        SELECT  CAST(word AS BIGINT)
                        FROM    dbo.SplitWithDelimiterNVarChar(@strSelectedTables, N',') )
                        AND dbo.tTable.Branch = @Branch	

				If dbo.Get_TableMonitoring() = 1 		---Table Monitoring
					UPDATE tblSamar_TableUsage SET tblSamar_TableUsage.nvcEndTime=  dbo.SetTimeFormat(getdate())      
					WHERE  tblSamar_TableUsage.intTableNo IN (
							SELECT  CAST(word AS BIGINT)
							FROM    dbo.SplitWithDelimiterNVarChar(@strSelectedTables, N',') )
							AND dbo.tblSamar_TableUsage.intBranch = @Branch               
							AND tblSamar_TableUsage.nvcEndTime IS NULL 
				END 
        END
--===============================================


GO


ALTER  PROCEDURE dbo.FillPrintFormatList
(
	@intLanguage	INT
)
AS
	SELECT	dbo.tPrintFormat.PrintFormat,
		CASE @intLanguage WHEN 0 THEN dbo.tPrintFormat.PrintFormatName
				  WHEN 1 THEN dbo.tPrintFormat.PrintFormatLatinName
		END AS PrintFormatName
	FROM dbo.tPrintFormat
	where Active = 1
GO

-- V26_15_Fix2_Added3
--����� ����� �������� �� ���ʐ����� ����� �� ����� �����
--����� ���� ���� �� ���ʐ�� �� ��� ������� ������ ����
--91/06/30

ALTER   PROCEDURE [dbo].[NavigateFacM]
    (
      @No INT ,
      @Direction INT ,
      @User INT ,
      @Status INT ,
      @Date NVARCHAR(10) ,
      @AccountYear SMALLINT ,
      @Branch INT
    )
AS 
    BEGIN
        SET NOCOUNT ON

        DECLARE @ShiftNo INT
        SET @ShiftNo = dbo.Get_Shift(dbo.SetTimeFormat(GETDATE()))

        DECLARE @AccessLevel INT

        SET @AccessLevel = ISNULL(( SELECT MIN(AccessLevel)
                                    FROM    ( SELECT TOP 100 PERCENT
                                                        CASE WHEN [ObjectId] LIKE N'viewallstationsfactors'
                                                             THEN 1
                                                             WHEN [ObjectId] LIKE N'ViewAllCurrentDayInvoices'
                                                             THEN 2
                                                             WHEN [ObjectId] LIKE N'ViewAllCurrentShiftInvoices'
                                                             THEN 3
                                                             ELSE 4
                                                        END AS AccessLevel
                                              FROM      dbo.tUser
                                                        INNER JOIN dbo.tAccess_Object ON dbo.tUser.intAccessLevel = dbo.tAccess_Object.intAccessLevel
                                                        INNER JOIN dbo.tObjects ON dbo.tAccess_Object.intObjectCode = dbo.tObjects.intObjectCode
                                              WHERE UID = @User
                                                       -- AND dbo.tUser.Branch = @Branch
                                                        AND ( [dbo].[tObjects].[ObjectId] LIKE N'viewallstationsfactors'
                                                              OR [dbo].[tObjects].[ObjectId] LIKE N'ViewAllCurrentDayInvoices'
                                                              OR [dbo].[tObjects].[ObjectId] LIKE N'ViewAllCurrentShiftInvoices'
                                                            )
                                              ORDER BY  [dbo].[tObjects].[intObjectCode] DESC
                                            ) T1
                                  ), 4)
                                     
        DECLARE @intAccessLevel INT
        SELECT  @intAccessLevel = intAccessLevel
        FROM    [dbo].[tUser]
        WHERE   uid = @User
                --AND [Branch] = @Branch

        IF @intAccessLevel = 1 
            SET @AccessLevel = @intAccessLevel

    DECLARE @LastfacmNo INT
    SET @LastfacmNo = ( SELECT  ISNULL(MAX([NO]), 0)
		FROM    tFacM
		WHERE     ( @AccessLevel = 1
		      OR ( @AccessLevel = 2
		           AND [Date] = @Date
		         )
		      OR ( @AccessLevel = 3
		           AND [ShiftNo] = @ShiftNo
		           AND [Date] = @Date
		         )
		      OR ( @AccessLevel = 4
		           AND dbo.tFacM.[ShiftNo] = @ShiftNo
		           AND dbo.tFacM.[Date] = @Date
		           AND tFacm.[User] = @User
		         )
		    )
		    AND [dbo].[tFacM].[Status] = @Status
		    AND [dbo].[tFacM].[AccountYear] = @AccountYear
		    AND [Branch] = @Branch
                      )   

    DECLARE @FirstfacmNo INT
    SET @FirstfacmNo = ( SELECT  ISNULL(MIN([NO]), 0)
		FROM    tFacM
		WHERE     ( @AccessLevel = 1
		      OR ( @AccessLevel = 2
		           AND [Date] = @Date
		         )
		      OR ( @AccessLevel = 3
		           AND [ShiftNo] = @ShiftNo
		           AND [Date] = @Date
		         )
		      OR ( @AccessLevel = 4
		           AND dbo.tFacM.[ShiftNo] = @ShiftNo
		           AND dbo.tFacM.[Date] = @Date
		           AND tFacm.[User] = @User
		         )
		    )
		    AND [dbo].[tFacM].[Status] = @Status
		    AND [dbo].[tFacM].[AccountYear] = @AccountYear
		    AND [Branch] = @Branch
                      )   


--Direction = 0 => First Key
        IF @Direction = 0 OR ( @Direction=1 AND @No = @FirstfacmNo ) 
            BEGIN
                SELECT  *
                FROM    ( SELECT TOP 5
                                    @AccessLevel AS [AccessLevel] ,
                                    [No] ,
                                    [SumPrice] ,
                                    [BascoleNo] ,
                                    [User] ,
                                    [Status] ,
                                    [Date] ,
                                    [ServePlace] ,
                                    [OrderType] , ISNULL(TempNo , No) AS TempNo 
                          FROM      [dbo].[tFacM]
                          WHERE     ( @AccessLevel = 1
                                      OR ( @AccessLevel = 2
                                           AND [Date] = @Date
                                         )
                                      OR ( @AccessLevel = 3
                                           AND [ShiftNo] = @ShiftNo
                                           AND [Date] = @Date
                                         )
	                              OR ( @AccessLevel = 4
	                                   AND dbo.tFacM.[ShiftNo] = @ShiftNo
	                                   AND dbo.tFacM.[Date] = @Date
	                                   AND tFacm.[User] = @User
	                                 )
                                    )
                                    AND [dbo].[tFacM].[Status] = @Status
                                    AND [dbo].[tFacM].[AccountYear] = @AccountYear
                                    AND [Branch] = @Branch
                          ORDER BY  [No] ASC
                        ) T1
                ORDER BY [T1].[No] DESC
                RETURN
            END

--======================= Direction = 1 => Previous Key
        ELSE IF @Direction = 1 
            BEGIN
	            SELECT TOP 5
	                    @AccessLevel AS [AccessLevel] ,
	                    [No] ,
	                    [SumPrice] ,
	                    [BascoleNo] ,
	                    [User] ,
	                    [Status] ,
	                    [Date] ,
	                    [ServePlace] ,
	                    [OrderType] , ISNULL(TempNo , No) AS TempNo
	            FROM    [dbo].[tFacM]
	            WHERE   ( @AccessLevel = 1
	                      OR ( @AccessLevel = 2
	                           AND [Date] = @Date
	                         )
	                      OR ( @AccessLevel = 3
	                           AND [ShiftNo] = @ShiftNo
	                           AND [Date] = @Date
	                         )
	                      OR ( @AccessLevel = 4
	                           AND dbo.tFacM.[ShiftNo] = @ShiftNo
	                           AND dbo.tFacM.[Date] = @Date
	                           AND tFacm.[User] = @User
	                         )
	                    )
	                    AND [dbo].[tFacM].[Status] = @Status
	                    AND [dbo].[tFacM].[AccountYear] = @AccountYear
	                    AND [Branch] = @Branch
	                    AND [No] < @No
	            ORDER BY [No] DESC
                RETURN
            END
--========== Direction = 3 => Last Key or NextKey and LastFacmNo
        ELSE IF @Direction = 3 OR ( @Direction=2 AND @No = @LastfacmNo )
            BEGIN
                SELECT  *
                FROM    ( SELECT TOP 5
                                    @AccessLevel AS [AccessLevel] ,
                                    [No] ,
                                    [SumPrice] ,
                                    [BascoleNo] ,
                                    [User] ,
                                    [Status] ,
                                    [Date] ,
                                    [ServePlace] ,
                                    [OrderType] , ISNULL(TempNo , No) AS TempNo
                          FROM      [dbo].[tFacM]
                          WHERE     ( @AccessLevel = 1
                                      OR ( @AccessLevel = 2
                                           AND [Date] = @Date
                                         )
                                      OR ( @AccessLevel = 3
                                           AND [ShiftNo] = @ShiftNo
                                           AND [Date] = @Date
                                         )
	                              OR ( @AccessLevel = 4
	                                   AND dbo.tFacM.[ShiftNo] = @ShiftNo
	                                   AND dbo.tFacM.[Date] = @Date
	                                   AND tFacm.[User] = @User
	                                 )
                                    )
                                    AND [dbo].[tFacM].Status = @Status
                                    AND [dbo].[tFacM].AccountYear = @AccountYear
                                    AND [Branch] = @Branch
                          ORDER BY  [No] DESC
                        ) T1
                ORDER BY [T1].[No] DESC
                RETURN
            END 
--====================================== Direction = 2 => Next Key
        ELSE IF @Direction = 2 
            BEGIN
                    SELECT  *
                    FROM    ( SELECT TOP 5
                                        @AccessLevel AS [AccessLevel] ,
                                        [No] ,
                                        [SumPrice] ,
                                        [BascoleNo] ,
                                        [User] ,
                                        [Status] ,
                                        [Date] ,
                                        [ServePlace] ,
                                        [OrderType] , ISNULL(TempNo , No) AS TempNo
                              FROM      [dbo].[tFacM]
                              WHERE     ( @AccessLevel = 1
                                          OR ( @AccessLevel = 2
                                               AND [Date] = @Date
                                             )
                                          OR ( @AccessLevel = 3
                                               AND [ShiftNo] = @ShiftNo
                                               AND [Date] = @Date
                                             )
	                              OR ( @AccessLevel = 4
	                                   AND dbo.tFacM.[ShiftNo] = @ShiftNo
	                                   AND dbo.tFacM.[Date] = @Date
	                                   AND tFacm.[User] = @User
	                                 )
                                        )
                                        AND [dbo].[tFacM].Status = @Status
                                        AND [dbo].[tFacM].AccountYear = @AccountYear
                                        AND [Branch] = @Branch
                                        AND [No] <= (@No + 1)
                              ORDER BY  [No] Desc
                            ) T1
                    ORDER BY [T1].[No] DESC
                RETURN
            END
    END
--===============================================


GO


--exec Get_All_Factors 2, 1, 1391, 3, N'91/06/27', N'91/06/30'
--GO 



ALTER       PROCEDURE [dbo].[Get_All_Factors]
    (
      @Status INT ,
      @User INT ,
      @AccountYear SMALLINT ,
      @Branch INT,
	  @DateAfter Nvarchar(8) , 
      @DateBefore Nvarchar(8)
    )
AS 
    DECLARE @AccessLevel INT
    DECLARE @LastfacmNo INT
    DECLARE @Date NVARCHAR(50)
    SET @Date = dbo.[Get_ShamsiDate_For_Current_Shift](GETDATE())
    DECLARE @ShiftNo INT
    SET @ShiftNo = dbo.Get_Shift(dbo.SetTimeFormat(GETDATE()))
--    PRINT @ShiftNo

    SET @AccessLevel = ISNULL(( SELECT MIN(AccessLevel)
                                FROM    ( SELECT TOP 100 PERCENT
                                                    CASE WHEN [ObjectId] LIKE N'viewallstationsfactors'
                                                         THEN 1
                                                         WHEN [ObjectId] LIKE N'ViewAllCurrentDayInvoices'
                                                         THEN 2
                                                         WHEN [ObjectId] LIKE N'ViewAllCurrentShiftInvoices'
                                                         THEN 3
                                                         ELSE 4
                                                    END AS AccessLevel
                                          FROM      dbo.tUser
                                                    INNER JOIN dbo.tAccess_Object ON dbo.tUser.intAccessLevel = dbo.tAccess_Object.intAccessLevel
                                                    INNER JOIN dbo.tObjects ON dbo.tAccess_Object.intObjectCode = dbo.tObjects.intObjectCode
                                          WHERE     --tObjects.ObjectId LIKE 'viewallstationsfactors' AND
                                                    UID = @User
                                                    --AND dbo.tUser.Branch = @Branch
                                                    AND ( [dbo].[tObjects].[ObjectId] LIKE N'viewallstationsfactors'
                                                    OR [dbo].[tObjects].[ObjectId] LIKE N'ViewAllCurrentDayInvoices'
                                                    OR [dbo].[tObjects].[ObjectId] LIKE N'ViewAllCurrentShiftInvoices'
                                                        )
                                          ORDER BY  [dbo].[tObjects].[intObjectCode] DESC
                                        ) T1
                              ), 4)

    DECLARE @intAccessLevel INT
    SELECT  @intAccessLevel = intAccessLevel
    FROM    [dbo].[tUser]
    WHERE   uid = @User
            --AND [Branch] = @Branch
    IF @intAccessLevel = 1 
        SET @AccessLevel = @intAccessLevel


    SET @LastfacmNo = ( SELECT  ISNULL(MAX([NO]), 0) + 1
                        FROM    tFacM
                        WHERE   Status = @Status
                                AND Branch = @Branch
                                AND dbo.tFacM.AccountYear = @AccountYear
                      )   
--    IF @LastfacmNo < 1000 
--        SET @LastfacmNo = 0 
--    ELSE 
--        IF @LastfacmNo > 1000 
--            SET @LastfacmNo = @LastfacmNo - 1000

    SELECT  dbo.tFacM.intSerialNo, [No],tfacm.[Date],tfacm.[Time], SumPrice, Balance, Recursive, ServiceTotal, CarryFeeTotal, DiscountTotal,isnull( NvcDescription ,N'') as NvcDescription ,
            dbo.tPer.nvcFirstName ,
            dbo.tPer.nvcSurName ,
            ISNULL(tcust.WorkName + dbo.tCust.Family , '') + ISNULL(tSupplier.WorkName + dbo.tSupplier.Family , '') AS CustomerName
            , ISNULL(tfacm.GuestNo ,'') AS GuestNo , ISNULL(tfacm.TempNo , tfacm.[No]) AS TempNo
            , tshift.Description AS ShiftDescription
    FROM    dbo.tFacM
            INNER JOIN dbo.tUser ON dbo.tFacM.[User] = dbo.tUser.UID
            INNER JOIN dbo.tPer ON dbo.tUser.pPno = dbo.tPer.pPno
            INNER JOIN dbo.tShift ON dbo.tfacm.ShiftNo = dbo.tShift.Code
            LEFT OUTER JOIN dbo.tCust ON dbo.tFacM.Customer = dbo.tCust.Code 
            LEFT OUTER JOIN dbo.tSupplier ON dbo.tFacM.Owner = dbo.tSupplier.Code 
    WHERE   ( @AccessLevel = 1
              OR ( @AccessLevel = 2
                   AND [dbo].[tFacM].[Date] = @Date
                 )
              OR ( @AccessLevel = 3
                   AND [ShiftNo] = @ShiftNo
                   AND [dbo].[tFacM].[Date] = @Date
                 )
	      OR ( @AccessLevel = 4
	           AND dbo.tFacM.[ShiftNo] = @ShiftNo
	           AND dbo.tFacM.[Date] = @Date
	           AND dbo.tFacM.[User] = @User
	         )
            )
            AND dbo.tFacM.Status = @Status
           -- AND dbo.tFacM.[No] > @LastfacmNo
            AND dbo.tFacM.AccountYear = @AccountYear
			AND  dbo.tFacm.[Date] >= @DateAfter 
			And dbo.tFacm.[Date] <= @DateBefore
			AND dbo.tFacM.Branch = @Branch
    ORDER BY No DESC



GO



ALTER  PROCEDURE [dbo].[Get_StationId_info] (@StationId INT , @Branch INT ) AS

select * from tStations where StationId =@StationId AND Branch =   @Branch


GO



UPDATE tblTotal_ItemReports_Details
SET ComboQuery = 'SELECT * FROM tPer INNER JOIN tUser ON dbo.tPer.pPno = dbo.tUser.pPno where ActDeAct=1 Order By Uid' 
WHERE ParameterName = N'User'

GO 


--Total_V26_15_Fix2_Added4
--RepsalesByBranch ����� ���� �� ���� -- ����� ����
--91/07/19


INSERT INTO dbo.tbltotal_ItemReports (
	intReportId,
	intGroupReportId,
	ReportName,
	LatinReportName,
	Refrence_Sp
) VALUES ( 
	/* intReportId - int */ 93,
	/* intGroupReportId - int */ 1,
	/* ReportName - nvarchar(100) */ N'����� ���� �� ����',
	/* LatinReportName - varchar(50) */ 'RepsalesByBranch',
	/* Refrence_Sp - varchar(50) */ 'RepsalesByBranch' ) 


GO 


INSERT INTO dbo.tblTotal_ItemReports_Details (
	intReportId,
	Row,
	FromText,
	toText,
	ParameterName,
	ParameterType,
	parameterLengh,
	ObjectType,
	Quantity,
	MinValue,
	MaxValue,
	ComboQuery,
	ComboFieldCode,
	ComboFieldDescr,
	RighttoLeft
) 
SELECT 
	93,
	Row,
	FromText,
	toText,
	ParameterName,
	ParameterType,
	parameterLengh,
	ObjectType,
	Quantity,
	MinValue,
	MaxValue,
	ComboQuery,
	ComboFieldCode,
	ComboFieldDescr,
	RighttoLeft
	FROM dbo.tblTotal_ItemReports_Details  WHERE intReportId = 1 AND (Row = 1 OR Row = 2)

GO 



INSERT INTO dbo.tblTotal_ItemReports_Details (
	intReportId,
	Row,
	FromText,
	toText,
	ParameterName,
	ParameterType,
	parameterLengh,
	ObjectType,
	Quantity,
	MinValue,
	MaxValue,
	ComboQuery,
	ComboFieldCode,
	ComboFieldDescr,
	RighttoLeft
) 
SELECT 
	93,
	3,
	FromText,
	toText,
	ParameterName,
	ParameterType,
	parameterLengh,
	ObjectType,
	Quantity,
	MinValue,
	MaxValue,
	ComboQuery,
	ComboFieldCode,
	ComboFieldDescr,
	RighttoLeft
	FROM dbo.tblTotal_ItemReports_Details  WHERE intReportId = 1 AND  Row = 5

GO 


------------------------------------����� ���� ���� ��-------------------------------------

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[RepsalesByBranch]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[RepsalesByBranch]
GO


CREATE PROC [dbo].[RepsalesByBranch]


(
	@SystemDate NVARCHAR(50) ,
	@SystemDay NVARCHAR(50) ,
	@SystemTime NVARCHAR(50) ,
	@Date1 VARCHAR(10) ,
	@Date2 VARCHAR(10) ,
	@User1 INT ,
	@User2 INT ,
	@Branch1 INT ,
	@Branch2 INT 

)
AS

		SELECT  [tFacM].branch ,tfacm.date,
				sumprice  ,	
				DiscountTotal  ,
				ServiceTotal  ,
				TaxTotal ,
				[DutyTotal] ,
				[PackingTotal]
				,[CarryFeeTotal]  
		,tfacm.[User]
		,(SELECT nvcbranchname FROM [tBranch]  WHERE tbranch.[Branch]=tfacm.[Branch]) AS BranchName
		, [nvcFirstName]+' ' +[nvcSurName]  AS FullName,uid,tper.ppno,[tFacM].[Branch]

		FROM tfacm INNER JOIN tuser ON tuser.[UID]=tfacm.[User] 
			INNER JOIN tper ON [tUser].[pPno] = [tPer].[pPno]
			WHERE [Status]=2 AND [Recursive]<>1	
				AND tfacm.[Date]>=@Date1 AND tfacm.[Date]<=@Date2
				AND tfacm.[User]>=@user1 AND tfacm.[user]<=@User2
				AND tfacm.[Branch]>=@Branch1 AND tfacm.[Branch]<=@Branch2


GO 



ALTER Proc Get_Customer_Code    
@ActDeact int ,    
@Code Bigint 
    
as    

Select * from dbo.vw_Get_Cust 
where MemberShipId = @Code and actdeact <> @ActDeact-- AND branch = @Branch  
AND vw_Get_Cust.Code <> -1


GO


ALTER Proc Get_Customer_Tel
@ActDeact int ,
@Tel Nvarchar(20)    
as    


Select * from dbo.vw_Get_Cust 
	where (CHARINDEX ( @Tel , [Tel1] ) > 0 Or CHARINDEX ( @Tel , [Tel2] ) > 0
        Or CHARINDEX ( @Tel , [Tel3] ) > 0 Or CHARINDEX ( @Tel , [Tel4] ) > 0
        Or CHARINDEX ( @Tel , [Mobile] ) > 0 ) 
        and actdeact <> @ActDeact 
AND vw_Get_Cust.Code <> -1 



GO



ALTER Proc Get_Customer_Name
@ActDeact int ,
@Name Nvarchar(50)     
as    


Select * from dbo.vw_Get_Cust 
where  CHARINDEX ( @Name , [Name] ) > 0 and actdeact <> @ActDeact  -- AND Branch = @Branch
AND vw_Get_Cust.Code <> -1
Order By [Name]



GO


SET QUOTED_IDENTIFIER OFF
GO


ALTER Proc Get_Customer_Address
@ActDeact int ,
@Address Nvarchar(200) 
as    


Select * from dbo.vw_Get_Cust 
where  CHARINDEX ( @Address , [Address] ) > 0 and actdeact <> @ActDeact
AND vw_Get_Cust.Code <> -1 --AND Branch = @Branch


GO




ALTER Proc Get_Customer_Prefix  
@ActDeact int ,    
@Code INT  

as    


Select * from dbo.vw_Get_Cust 
where Prefix = @Code and actdeact <> @ActDeact-- AND branch = dbo.[Get_Current_Branch]()  
AND vw_Get_Cust.Code <> -1 --AND Branch = @Branch


GO



ALTER Proc Get_BuyCustomer
    
@Code BIGINT      
    
as    
    
Declare @LastNo Bigint    
Declare @LastPrice Bigint    
Declare @BuyCount int    
Declare @BuyAverage Bigint    
Declare @LastDate Nvarchar(20)    
Declare @AddedDate Nvarchar(20)    
Declare @MinPrice Bigint    
Declare @MaxPrice Bigint    
Declare @CreditBuy Bigint    
Declare @RecievedAmount Bigint    
declare @SellPrice SMALLINT    
declare @CountCurrentDayBuy Smallint    
declare @CountCurrentShifBuy Smallint    
DECLARE @Description AS NVARCHAR(50)
declare @AccountYear Smallint
set @Accountyear=dbo.Get_AccountYear()
Declare @Date nvarchar(10)
set @Date = dbo.Shamsi(GETDATE())
DECLARE @ShiftNo INT 
SET @ShiftNo = dbo.Get_Shift(GETDATE())
  
Set @LastNo = (Select IsNull(Max([No]),0)  from dbo.tfacm where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear   )  
Set @LastPrice = (Select Top 1 SumPrice  from dbo.tfacm where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear  Order By intserialno Desc )    
Set @BuyCount =  (Select Count(*) From tFacm Where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear )    
Set @BuyAverage = (Select Isnull(Avg(Sumprice),0)   from dbo.tfacm where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear  )    
Set @LastDate = (Select Top 1 [Date] from dbo.tfacm where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear Order By intserialno Desc )    
Set @AddedDate = (Select IsNull([Date],'') from dbo.tCust where Code = @Code  )    
Set @MinPrice = (Select IsNull(Min(SumPrice),0)  from dbo.tfacm where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear  )    
Set @MaxPrice = (Select IsNull(Max(SumPrice),0)   from dbo.tfacm where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear  )    
SET @Description = (SELECT ISNULL([Description],' ') FROM [dbo].[tCust] WHERE dbo.tCust.[Code] = @Code ) --AND [tCust].[Branch] = @Branch)
SELECT    @CreditBuy= isnull(sum(sumPrice),0 )    FROM         dbo.tFacM  WHERE     dbo.tFacm.Balance = 0 And dbo.tFacm.FacPayment = 1  and 
         Customer = @Code And AccountYear = @accountyear     
SELECT    @RecievedAmount= isnull(sum(Bestankar),0 )    FROM         dbo.tblAcc_Recieved  WHERE     RecieveType = 3 And Code_Bes = @Code    
         And AccountYear = @accountyear     
select @sellPrice=sellprice from tcust where code=@code --And Branch  = @Branch     
Set @CountCurrentDayBuy =  (Select Count(*) From tFacm Where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear AND [Date]= @Date  )    
Set @CountCurrentShifBuy =  (Select Count(*) From tFacm Where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear AND [ShiftNo]= @ShiftNo AND [Date]= @Date  )    

Select @LastNo  As LastNo, IsNull(@LastPrice,0)  as LastPrice ,@BuyCount As BuyCount, @BuyAverage as BuyAverage,IsNull(@LastDate,'')  as        LastDate ,@AddedDate  As AddedDate ,@MinPrice  As MinPrice,@MaxPrice As MaxPrice,@CreditBuy as CreditBuy , @RecievedAmount As        RecievedAmount,IsNull(@sellPrice ,1) as sellprice,IsNull(@CountCurrentDayBuy,0) AS CountCurrentDayBuy ,ISNULL(@CountCurrentShifBuy,0) AS CountCurrentShifBuy  ,        IsNull(@Description  , N'') AS [Description]




GO


ALTER  VIEW dbo.vw_PreviousFactors
AS
SELECT     dbo.tRepFacEditM.*, dbo.tShift.Description, dbo.tShift.LatinDescription, dbo.tPer.nvcFirstName, dbo.tPer.nvcSurName
FROM         dbo.tShift RIGHT OUTER JOIN
                      dbo.tRepFacEditM INNER JOIN
                      dbo.tPer INNER JOIN
                      dbo.tUser 
		ON dbo.tPer.pPno = dbo.tUser.pPno --and dbo.tPer.Branch = dbo.tUser.Branch 
		ON dbo.tRepFacEditM.[User] = dbo.tUser.UID --and  dbo.tRepFacEditM.Branch = dbo.tUser.Branch
		ON dbo.tShift.Code = dbo.tRepFacEditM.ShiftNo --and dbo.tShift.Branch = dbo.tRepFacEditM.Branch
--Where		dbo.tRepFacEditM.Branch = dbo.Get_Current_Branch()



GO



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Delete_tPocketPCGroup]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Delete_tPocketPCGroup]
GO

CREATE proc dbo.Delete_tPocketPCGroup (@Code int ,@Branch INT , @Result INT OUT  )
as
Begin TRAN


Delete from dbo.tPocketPCGroup where PocketPCGroupCode = @Code And Branch = @Branch

if @@Error <> 0 
	GOTO ErrHandler

Commit TRAN
SET @Result = 1
RETURN @Result

ErrHandler:
RollBack Tran 
SET @Result = 0
RETURN @Result


GO



ALTER PROCEDURE [dbo].[Total_ReIndex]
AS 
    DECLARE @DataFile NVARCHAR(50)
    DECLARE @LogFile NVARCHAR(50)

    SELECT  @DataFile = [name] /*fileid ,, filename, size, growth, status, maxsize */
    FROM    dbo.sysfiles
    WHERE   fileid = 1 --(status & 0x40) <> 0 AND
    SELECT  @LogFile = [name] /*fileid ,, filename, size, growth, status, maxsize*/
    FROM    dbo.sysfiles
    WHERE   fileid = 2 --(status & 0x40) <> 0 AND

--PRINT @DataFile
--PRINT @LogFile
    DECLARE @Str NVARCHAR(200)
--(N'Total_Data')
    SET @Str = N'DBCC SHRINKFILE (N''' + RTRIM(LTRIM(@DataFile)) + '''' + ')'
--PRINT @Str
    EXECUTE sp_executesql @str


    SET @Str = N'DBCC SHRINKFILE (N''' + RTRIM(LTRIM(@LogFile)) + '''' + ')'
    EXECUTE sp_executesql @str
--PRINT @Str

    DBCC DBREINDEX ('tfacd', '' , 0)
    DBCC DBREINDEX ('tfacm', '' , 0)
    DBCC DBREINDEX ('tfacd2', '' , 0)
    DBCC DBREINDEX ('tCASh', '' , 0)
    DBCC DBREINDEX ('tCust', '' , 0)
    DBCC DBREINDEX ('tFacCard', '' , 0)
    DBCC DBREINDEX ('tFacCash', '' , 0)
    DBCC DBREINDEX ('tFacCheque', '' , 0)
    DBCC DBREINDEX ('tFacCredit', '' , 0)
    DBCC DBREINDEX ('tFacLoan', '' , 0)
    DBCC DBREINDEX ('tGood', '' , 0)
    DBCC DBREINDEX ('tGoodLevel1', '' , 0)
    DBCC DBREINDEX ('tGoodLevel2', '' , 0)
    DBCC DBREINDEX ('tInventory', '' , 0)
    DBCC DBREINDEX ('tHistory', '' , 0)
    DBCC DBREINDEX ('tInventory_Good', '' , 0)
    DBCC DBREINDEX ('tPer', '' , 0)
    DBCC DBREINDEX ('tRepFacEditM', '' , 0)
    DBCC DBREINDEX ('tStation_Inventory_Good', '' , 0)
    DBCC DBREINDEX ('tStations', '' , 0)
    DBCC DBREINDEX ('tSupplier', '' , 0)
    DBCC DBREINDEX ('tUser', '' , 0)
    DBCC DBREINDEX ('tHavaleM', '' , 0)
    DBCC DBREINDEX ('tHavaleD', '' , 0)

--    SET @Str = N'DBCC SHRINKFILE (N''' + RTRIM(LTRIM(@DataFile)) + '''' + ')'
----PRINT @Str
--    EXECUTE sp_executesql @str
--
--
--    SET @Str = N'DBCC SHRINKFILE (N''' + RTRIM(LTRIM(@LogFile)) + '''' + ')'
--    EXECUTE sp_executesql @str
--===============================================

GO



