

--Script V26_15_Fix0
--91/03/09

--����� ���� �������
-- ����� ��� ������
--���� ��� ��� ��



INSERT  INTO dbo.tblPub_Script2
        ( Version ,
          Script ,
          LastScriptNo ,
          [Date] ,
          FixNumber
        )
VALUES  ( 26 ,
          15 ,
          0 ,
          dbo.shamsi(GETDATE()) ,
          0
        )
GO




ALTER PROCEDURE dbo.InserttGood
(
	@intLanguage	INT,
	@Code		INT,
	@GoodName	NVARCHAR(50),
	@GoodNamePrn	NVARCHAR(50),
	@SellPrice	FLOAT,
	@BuyPrice	FLOAT,
	@Barcode	NVARCHAR(50),
	@Level1		INT,
	@Level2		INT,
	@Model		INT,
	@Supplier	INT,
	@Unit		INT,
	@GoodType	INT,
	@Weight	Float,
	@NumberOfUnit 	INT,
	@SellPrice2 Float,
	@SellPrice3 Float ,
	@MainType Bit ,
	@SellPrice4 Float,
	@SellPrice5 Float,
	@SellPrice6 FLOAT ,
	@CategoryShow INT ,
	@PicturePath NVARCHAR(100) ,
	@nvcDescription NVARCHAR(100) ,
	@Result INT OUT 
	


)

AS
Begin tran

	IF @intLanguage = 0 

		INSERT INTO dbo.tGood (Code,Name,NamePrn,SellPrice,BuyPrice,Barcode,Level1,Level2,Model,ProductCompany,Unit,GoodType,Weight,NumberOfUnit,SellPrice2 ,SellPrice3 , MainType , SellPrice4 ,SellPrice5 ,SellPrice6 , CategoryShow , PicturePath , nvcDescription)
		VALUES (@Code,@GoodName,@GoodNamePrn,@SellPrice,@BuyPrice,@Barcode,@Level1,@Level2,@Model,@Supplier,@Unit,@GoodType,@Weight,@NumberOfUnit, @SellPrice2 , @SellPrice3 , @MainType , @SellPrice4, @SellPrice5, @SellPrice6 , @CategoryShow , @PicturePath , @nvcDescription)

	ELSE IF @intLanguage = 1 

		INSERT INTO dbo.tGood (Code,LatinName,LatinNamePrn,SellPrice,BuyPrice,Barcode,Level1,Level2,Model,ProductCompany,Unit,GoodType,Weight,NumberOfUnit, SellPrice2, SellPrice3 , MainType , SellPrice4 ,SellPrice5 ,SellPrice6 , CategoryShow ,PicturePath ,nvcDescription)
		VALUES (@Code,@GoodName,@GoodNamePrn,@SellPrice,@BuyPrice,@Barcode,@Level1,@Level2,@Model,@Supplier,@Unit,@GoodType,@Weight,@NumberOfUnit , @SellPrice2 , @SellPrice3 , @MainType , @SellPrice4, @SellPrice5, @SellPrice6 ,@CategoryShow ,@PicturePath ,@nvcDescription)

     IF @@ERROR <>0
        GoTo EventHandler

 --         if  @GoodType = 3 
   --          Begin
     --               INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
	--	VALUES (@Code,@Code,1,1)
               --     INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
		--VALUES (@Code,@Code,2,1)
                  --  INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
--	--	VALUES (@Code,@Code,4,1)
              --      INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
	--	VALUES (@Code,@Code,8,1)
             --      INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
	--	VALUES (@Code,@Code,16,1)
         --   End

 update  [dbo].[tGood]  set [name] = latinname where ([Name] is null or [Name] = '' ) And Code = @Code

 update  [dbo].[tGood] set latinname = [name] where ([latinName] is null or latinname = '') And Code = @Code

 update  [dbo].[tGood] set [nameprn]=[latinnameprn] where ([Nameprn] is null or [Nameprn] = '' ) And Code = @Code

 update  [dbo].[tGood] set [latinnameprn] = [nameprn] where ([latinNameprn] is null or latinnameprn = '') And Code = @Code

insert into .dbo.[tInventory_Good](GoodCode,InventoryNo,Branch , AccountYear )
  select @Code,tInventory.InventoryNo,tInventory.Branch , dbo.Get_AccountYear()  from dbo.tInventory 
		inner join tInventory_Level1 On tInventory_Level1.Branch = tInventory.Branch  and tInventory_Level1.InventoryNo  = tInventory.InventoryNo 
	        Where tInventory_Level1.Level1 = @Level1 

     IF @@ERROR <>0
        GoTo EventHandler

Insert into dbo.tStation_Inventory_Good ( branch ,InventoryNo, StationID,  AccountYear , GoodCode , Active)
select tInventory.Branch , tInventory.InventoryNo,  t.stationid , dbo.Get_AccountYear() , @Code, 1 as active  from dbo.tInventory -- t.stationid
		inner join tInventory_Level1 On tInventory_Level1.Branch = tInventory.Branch  and tInventory_Level1.InventoryNo  = tInventory.InventoryNo 
         	Inner join (select  Distinct(StationId), InventoryNo , Branch , AccountYear from tStation_Inventory_Good )t On  t.InventoryNo = tInventory_Level1.InventoryNo AND t.Branch =  tInventory_Level1.Branch and t.AccountYear = dbo.Get_AccountYear()

	        Where tInventory_Level1.Level1 = @Level1 

     IF @@ERROR <>0
        GoTo EventHandler
	UPDATE dbo.tGood SET nvcDate = dbo.shamsi(GETDATE()) WHERE Code = @Code
	Update tGood SET btnAscDefault = ASCII(left(ltrim([Name] COLLATE Arabic_CI_AI),1)) where code =  @Code


Commit Tran

SET @Result = 1 
RETURN @Result

EventHandler:
	RollBack Tran
SET @Result = -1 
RETURN @Result


GO


UPDATE dbo.tObjects SET ObjectName = N'��� ����� ��� �����' WHERE ObjectId = 'frmPrizeType'
GO 

UPDATE dbo.tObjects SET ObjectName = N' ������ �� �����' WHERE ObjectId = 'frmPayment'
GO 

UPDATE dbo.tObjects SET ObjectName = N' ������ �� �����' WHERE ObjectId = 'frmRecieved'
GO 

UPDATE dbo.tObjects SET ObjectParent = 102 WHERE intObjectCode = 290 OR intObjectCode = 291
GO 


UPDATE dbo.tObjects SET ObjectParent = 109 WHERE intObjectCode = 289 
GO 
 
UPDATE dbo.tObjects SET ObjectParent = 126 WHERE intObjectCode = 111 
GO 

UPDATE dbo.tObjects SET ObjectName = N'���� ���� �����' WHERE ObjectId = 'frmGroupStore'
GO 

UPDATE dbo.tObjects SET ObjectName = N' ����� � ������' WHERE ObjectId = 'frmGroupPer'
GO 

UPDATE dbo.tObjects SET ObjectParent = 104 WHERE intObjectCode = 123 
GO 

UPDATE dbo.tObjects SET ObjectName = N'���� ���� ��' WHERE ObjectId = 'frmGroupBoxTo'
GO 

DELETE FROM dbo.tObjects WHERE ObjectId = 'frmDrawerModel'
GO 

UPDATE dbo.tObjects SET ObjectName = N'��� ��ρ���� �����' WHERE ObjectId = 'frmTestPos'
GO 

UPDATE dbo.tObjects SET ObjectParent = 105 WHERE ObjectId = 'frmBranch'
GO 

UPDATE dbo.tObjects SET ObjectName = N' ��� ������ ���' WHERE ObjectId = 'frmNotice'
GO 



ALTER   Procedure dbo.Get_Customer 
	@MainCust Bit,
	@MembershipId BIGINT=-999,
	@SwitchName NVARCHAR(50)=N'-999',
	@Tel1 NVARCHAR(50)=N'-999',
	@Status int=0,
	@SwitchValue int=-999 ,
	@Branch INT = NULL 

 as
IF @Branch IS NULL SET @Branch = dbo.Get_Current_Branch()

if @MainCust = 1
	Select 	
	code,
	CASE  dbo.tCust.Family + dbo.tCust.[Name] 
		WHEN ''  THEN tCust.WorkName
		ELSE  dbo.tCust.Family+ ' ' + dbo.tCust.[Name]
			END AS [Full Name],
	MembershipId,
	Tel1,
	CASE WHEN LEN(WorkName) > 0 THEN 1 ELSE 0 END AS WorkType ,
	Address,
	Discount,
	Credit,
	CarryFee,
	PaykFee,
	Distance,
	FamilyNo,
	Member,
	Branch,
	MasterCode,
	Owner,
	[Name],
	Family,
	Sex,
	WorkName,
	City,
	ActKind,
	ActDeAct,
	Prefix,
	Assansor,
	PostalCode,
	Tel2,
	Tel3,
	Tel4,
	Mobile,
	Fax,
	Email,
	BuyState,
	Description,
	Date,
	[Time],
	[User],
	Unit,
	InternalNo,
	Flour,
	Tafsili,
	State,
	Central,
	nvcRFID,
	SellPrice,
	EconomicCode,
	nvcBirthDate
	
	From dbo.tCust
	where MasterCode is  Null and code > 0 
	AND( RTRIM(LTRIM(CASE @SwitchValue WHEN 0 THEN Family WHEN 1 THEN WorkName END))=RTRIM(LTRIM(@SwitchName)) OR MembershipId=@MembershipId OR RTRIM(LTRIM(Tel1))=RTRIM(LTRIM(@Tel1)) OR @Status=0)
	AND (Branch = @Branch or Branch is Null)
           Order By Membershipid Asc
ELSE
	SELECT 
	code,
	CASE  dbo.tCust.Family + dbo.tCust.[Name] 
		WHEN ''  THEN tCust.WorkName
		ELSE  dbo.tCust.Family+ ' ' + dbo.tCust.[Name]
			END AS [Full Name],
	MembershipId,
	Tel1,
	CASE WHEN LEN(WorkName) > 0 THEN 1 ELSE 0 END AS WorkType ,
	Address,
	Discount,
	Credit,
	CarryFee,
	PaykFee,
	Distance,
	FamilyNo,
	Member,
	Branch,
	MasterCode,
	Owner,
	[Name],
	Family,
	Sex,
	WorkName,
	City,
	ActKind,
	ActDeAct,
	Prefix,
	Assansor,
	PostalCode,
	Tel2,
	Tel3,
	Tel4,
	Mobile,
	Fax,
	Email,
	BuyState,
	Description,
	Date,
	[Time],
	[User],
	Unit,
	InternalNo,
	Flour,
	Tafsili,
	State,
	Central,
	nvcRFID,
	SellPrice,
	EconomicCode,
	nvcBirthDate
	From dbo.tCust
	where MasterCode is Not Null and code > 0 
	AND ( RTRIM(LTRIM(CASE @SwitchValue WHEN 0 THEN Family WHEN 1 THEN WorkName END))=RTRIM(LTRIM(@SwitchName)) OR MembershipId=@MembershipId OR RTRIM(LTRIM(Tel1))=RTRIM(LTRIM(@Tel1)) OR @Status=0)
	AND (Branch =  @Branch or Branch is Null)


GO
--exec Get_Customer 1, 0, N'', N'', 0, 0


ALTER view [dbo].[vw_Get_Cust]  

as  

SELECT  
tcust.[Code], 
cast(tcust.MembershipId as bigint) as MembershipId,   
  CASE WHEN (tcust.workname IS NOT NULL AND tcust.workname <> '')   
  THEN (tcust.workname)   
 WHEN ((tcust.workname IS  NULL OR tcust.workname = '')  and MasterWorkName IS NOT NULL )  
  THEN (tcust.MasterWorkName  + '_' + tcust.family + ' ' + tcust.Name)  
         ELSE (tcust.family + ' ' + tcust.Name)   
 END AS [Name],
  tcust.[Tel1] +' '+ tcust.[Tel2] + ' ' + tcust.[Tel3] +' '  + tcust.[Tel4] + ' ' + tcust.[Mobile] AS Telephone, 
  ISNULL(tcust.[Address] , N'') AS Address,
  	tcust.[MasterCode],
	 tcust.[Prefix],
	 tcust.[Owner],   
 --tcust.[Sex], tcust.[City],  
 tcust.[ActKind],tcust.[ActDeAct],   
 tcust.[Assansor],   
 tcust.[PostalCode], tcust.[Tel1] ,  
 tcust.[Tel2] , tcust.[Tel3] , tcust.[Tel4], tcust.[Mobile],  
 --tcust.[Fax], tcust.[Email], tcust.[CarryFee],   
 --tcust.[PaykFee],tcust.[Distance], tcust.[Credit],   
 --tcust.[Discount], tcust.[BuyState], tcust.[Description],   
 --tcust.[Date],tcust.[Time], tcust.[User], tcust.[Unit],   
 --tcust.[InternalNo], tcust.[Flour] ,  
         isnull(SUM(T .sumPrice), 0) AS Price , tcust.Central , tcust.FamilyNo, [tCust].[Branch]  

FROM   ( SELECT     dbo.tCust.*, tCust_1.WorkName AS MasterWorkName  
FROM         dbo.tCust LEFT OUTER JOIN  
                      dbo.tCust tCust_1 ON dbo.tCust.Branch = tCust_1.Branch AND dbo.tCust.MasterCode = tCust_1.Code  ) tcust LEFT OUTER JOIN   --Where dbo. tcust.Branch = dbo.Get_Current_Branch()  
                       (SELECT     sumPrice , Customer  
                        FROM         dbo.tFacM  
                        WHERE     dbo.tFacm.Facpayment = 0 and dbo.tFacm.Branch = dbo.Get_Current_Branch()) T ON tcust.code = T.Customer  
WHERE tcust.[Branch] = dbo.[Get_Current_Branch]()

GROUP BY   
 tcust.[Code], tcust.[MasterCode], tcust.[Owner],   
 --tcust.[City],tcust.[Sex],  
 tcust.[ActKind],tcust.[ActDeAct],   
 tcust.[Prefix], tcust.[Assansor],   
 tcust.[Address], tcust.[PostalCode], tcust.[Tel1],  
 tcust.[Tel2], tcust.[Tel3], tcust.[Tel4], tcust.[Mobile],   
 --tcust.[Fax], tcust.[Email], tcust.[CarryFee],   
 --tcust.[PaykFee],tcust.[Distance], tcust.[Credit],   
 --tcust.[Discount], tcust.[BuyState], tcust.[Description],   
 --tcust.[Date],tcust.[Time], tcust.[User], tcust.[Unit],   
 --tcust.[InternalNo], tcust.[Flour] ,  
 tcust.[workname],  
 tcust.[Name],tcust.[family],tcust.[MembershipId] ,  
 tcust.MasterWorkName , tcust.Central , tcust.FamilyNo  , [tCust].[Branch]




GO


--
--���� ���� �� ������ ������� �� ��� ������ ����� �� ���� �ю� ��� ������� ���� ������� ���


Alter Proc Get_LastBuy

@Code Bigint ,
@Result Bigint Out

as

declare @AccountYear smallint
set @AccountYear = dbo.Get_AccountYear()

Set @Result = (Select IsNull(Max([No]),0) As MaxNo  from dbo.tfacm where Customer = @Code And   AccountYear = @AccountYear  ) --


Return @Result

GO


ALTER Proc Get_BuyCustomer
    
@Code Bigint     
    
as    
    
Declare @LastNo Bigint    
Declare @LastPrice Bigint    
Declare @BuyCount int    
Declare @BuyAverage Bigint    
Declare @LastDate Nvarchar(20)    
Declare @AddedDate Nvarchar(20)    
Declare @MinPrice Bigint    
Declare @MaxPrice Bigint    
Declare @CreditBuy Bigint    
Declare @RecievedAmount Bigint    
declare @SellPrice SMALLINT    
declare @CountCurrentDayBuy Smallint    
declare @CountCurrentShifBuy Smallint    
DECLARE @Description AS NVARCHAR(50)
declare @AccountYear Smallint
declare @Branch Int
Set @Branch=dbo.Get_current_Branch()
set @Accountyear=dbo.Get_AccountYear()
Declare @Date nvarchar(10)
set @Date = dbo.Shamsi(GETDATE())
DECLARE @ShiftNo INT 
SET @ShiftNo = dbo.Get_Shift(GETDATE())
  
Set @LastNo = (Select IsNull(Max([No]),0)  from dbo.tfacm where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear   )  Set @LastPrice = (Select Top 1 SumPrice  from dbo.tfacm where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear  Order By intserialno Desc )    
Set @BuyCount =  (Select Count(*) From tFacm Where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear )    
Set @BuyAverage = (Select Isnull(Avg(Sumprice),0)   from dbo.tfacm where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear  )    
Set @LastDate = (Select Top 1 [Date] from dbo.tfacm where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear Order By intserialno Desc )    
Set @AddedDate = (Select IsNull([Date],'') from dbo.tCust where Code = @Code  )    
Set @MinPrice = (Select IsNull(Min(SumPrice),0)  from dbo.tfacm where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear  )    
Set @MaxPrice = (Select IsNull(Max(SumPrice),0)   from dbo.tfacm where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear  )    
SET @Description = (SELECT ISNULL([Description],' ') FROM [dbo].[tCust] WHERE dbo.tCust.[Code] = @Code AND [tCust].[Branch] = @Branch)
SELECT    @CreditBuy= isnull(sum(sumPrice),0 )    FROM         dbo.tFacM  WHERE     dbo.tFacm.Balance = 0 And dbo.tFacm.FacPayment = 1  and          Customer = @Code and dbo.tFacm.Branch = @Branch And AccountYear = @accountyear     
SELECT    @RecievedAmount= isnull(sum(Bestankar),0 )    FROM         dbo.tblAcc_Recieved  WHERE     RecieveType = 3 And Code_Bes = @Code             And AccountYear = @accountyear     
select @sellPrice=sellprice from tcust where code=@code And Branch  = @Branch     
Set @CountCurrentDayBuy =  (Select Count(*) From tFacm Where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear AND [Date]= @Date  )    
Set @CountCurrentShifBuy =  (Select Count(*) From tFacm Where Customer = @Code And Recursive <> 1  And AccountYear = @accountyear AND [ShiftNo]= @ShiftNo AND [Date]= @Date  )    

Select @LastNo  As LastNo, IsNull(@LastPrice,0)  as LastPrice ,@BuyCount As BuyCount, @BuyAverage as BuyAverage,IsNull(@LastDate,'')  as        LastDate ,@AddedDate  As AddedDate ,@MinPrice  As MinPrice,@MaxPrice As MaxPrice,@CreditBuy as CreditBuy , @RecievedAmount As        RecievedAmount,IsNull(@sellPrice ,1) as sellprice,IsNull(@CountCurrentDayBuy,0) AS CountCurrentDayBuy ,ISNULL(@CountCurrentShifBuy,0) AS CountCurrentShifBuy  ,        IsNull(@Description  , N'') AS [Description]




GO



ALTER  Proc Get_BuyDailyCustomer(  
    @Code Bigint,   
    @Date Nvarchar(50)  
    )  
as  
  
Declare @BuyDailyCount int  
Declare @BuyShiftCount int  
DECLARE @ShiftNo INT 
SET @ShiftNo = dbo.Get_Shift(GETDATE())

Set @BuyDailyCount =  (Select Count(*) From tFacm Where Customer = @Code And Recursive <> 1  and [date]=@Date )  --And AccountYear = dbo.get_AccountYear() 
Set @BuyShiftCount =  (Select Count(*) From tFacm Where Customer = @Code And Recursive <> 1  AND [Date]= @Date AND [ShiftNo]= @ShiftNo )  -- -- And AccountYear = dbo.get_AccountYear() 

select ISNULL(@BuyDailyCount,0) as CountDailyBuy ,ISNULL(@BuyShiftCount,0) AS CountShiftBuy



GO



ALTER TABLE dbo.tblTotal_CallerId
ALTER COLUMN membershipId BIGINT 
GO 


ALTER  PROCEDURE [dbo].[Update_tblTotal_CallerId] 
@AutoId INT  ,
@intCustomer INT ,
@MembershipId BIGINT ,
@nvcname NVARCHAR(50)

 AS

UPDATE  dbo.tblTotal_CallerId
SET intCustomer = @intCustomer ,
    membershipId = @MembershipId ,
    nvcName = @nvcname
WHERE AutoId = @AutoId



GO


ALTER  PROCEDURE [dbo].[Update_tblTotal_CallerId_Number] 
@nvcCallerId NVARCHAR(20)  ,
@intCustomer INT ,
@MembershipId BIGINT  ,
@nvcname NVARCHAR(50)

 AS

UPDATE  dbo.tblTotal_CallerId
SET intCustomer = @intCustomer ,
    membershipId = @MembershipId ,
    nvcName = @nvcname
WHERE nvcCallerId = @nvcCallerId



GO




ALTER VIEW  ViewfacctorsellDetail  
AS  

SELECT  tFacM.[No], tFacM.[Date], tFacM.[User], LTRIM(tFacM.[Time]) AS Time, tFacM.SumPrice, tFacM.StationId,tFacM.ServePlace  
    ,tFacM.Status  ,tServePlace.intServePlace,tServePlace.[Description] AS ServePlaceDescription,ISNULL([tSupplier].[Name]+[tSupplier].[Family]+[tSupplier].[WorkName] , '') AS SupName  
    ,TaxTotal , DutyTotal , [ServiceTotal],[PackingTotal],[CarryFeeTotal], [DiscountTotal],[tFacD].[Amount],tfacd.[FeeUnit],[tFacD].[GoodCode],[tGood].[Name]
 ,[tCust].[Address],([tCust].[Name]+' '+[tCust].[Family]) AS CustomerName ,[tCust].[Owner]
 , tFacM.Branch , tper.pPno
FROM tFacM INNER JOIN tServePlace ON tfacm.ServePlace=tServePlace.intServePlace  
  	LEFT OUTER JOIN tsupplier ON [tFacM].[Owner]=[tSupplier].[Code]  
 	INNER JOIN [tFacD] ON [tFacM].[intSerialNo]=tfacd.[intSerialNo]
	INNER JOIN [tGood] ON [tFacD].[GoodCode] = [tGood].[Code]
	INNER JOIN [tCust] ON [tFacM].[Customer]=[tCust].[Code] AND (tfacm.Branch = dbo.tCust.Branch OR dbo.tCust.Branch IS NULL)
	INNER JOIN dbo.tuser ON dbo.tFacM.[User] = dbo.tUser.UID AND dbo.tFacM.Branch = dbo.tUser.Branch
	INNER JOIN dbo.tPer ON dbo.tUser.Branch = dbo.tPer.Branch AND dbo.tUser.pPno = dbo.tPer.pPno 

	Where Recursive = 0 --and dbo.tFacM.Branch = dbo.Get_Current_Branch()  



GO



ALTER   Proc Get_All_Customers
@ActDeact INT , @Branch INT = NULL 
as

IF @Branch IS NULL SET @Branch = dbo.Get_Current_Branch()

Select [Code] ,MembershipId ,[Name] ,Telephone , Address , MasterCode , Prefix 
 from dbo.vw_Get_Cust where code > 0 and actdeact <> @ActDeact AND Branch = @Branch


GO

ALTER proc Get_vw_Customers (@Code INT , @Branch INT )
as
select * from dbo.vw_Customers where Code = @Code AND Branch = @Branch



GO


ALTER proc Get_vw_Customers_ByMembership (@Membershipid BIGINT , @Branch INT )
as
select * from dbo.vw_Customers where Membershipid = @Membershipid and mastercode is NULL
	AND Branch = @Branch




GO



ALTER  Proc Get_All_Customers_Count  @Branch INT

as
Select (Select Count(Code) from dbo.tCust where code > 0 AND (Branch = @Branch OR @Branch IS NULL) ) As MaxCustomerNo , 
	(Select Count(Code) from dbo.tCust where code > 0 AND (Branch = @Branch OR @Branch IS NULL) and actdeact = 1) As MaxCustomerActive ,
	(Select Count(Code) from dbo.tCust where code > 0 AND (Branch = @Branch OR @Branch IS NULL) and actdeact = 0) As MaxCustomerInActive



GO




ALTER Proc Get_DeliveryFactor_By_No( @No bigint , @AccountYear SMALLINT , @Branch INT)
as
select * from tfacm where [No] = @No  and Status =2  And AccountYear = @AccountYear And Branch = @Branch  ---and (( incharge is not null and incharge <>'') or facpayment =1)


GO



-- ����� ��� �� �� ���� ���� ��� �� �����  �� ���

ALTER     Proc Get_Factors_Tables ( @intLanguage int , @nvcDate NVARCHAR(8))

as

SELECT distinct   Vw_Invoice_Table.TableNo ,  Vw_Invoice_Table.[Date] ,  Vw_Invoice_Table.TableName ,  Vw_Invoice_Table.FullName ,  
                   Vw_Invoice_Table.SumPrice ,  Vw_Invoice_Table.[Time] ,  Vw_Invoice_Table.[No] ,  Vw_Invoice_Table.intSerialNo
		, Vw_Invoice_Table.GuestNo , Vw_Invoice_Table.TempNo , Vw_Invoice_Table.ShiftDescription
FROM         Vw_Invoice_Table

Where  Vw_Invoice_Table.[TableNo] >0  and Vw_Invoice_Table.[Date] = @nvcDate  And Vw_Invoice_Table.Facpayment = 0 And Vw_Invoice_Table.Recursive = 0
ORDER BY Vw_Invoice_Table.TableNo --Vw_Invoice_Table.[No] , Vw_Invoice_Table.[Date] ,Vw_Invoice_Table.[Time]



GO



ALTER  PROCEDURE Update_tfacm_Balance  
(
@No Bigint,
@Status int,
@Uid  int,
@AccountYear Smallint = NULL ,
@ds NVARCHAR(4000) = NULL ,-- For Ppc
@Branch INT  
)
AS
IF @AccountYear IS NULL
	SET @AccountYear = dbo.Get_AccountYear()
--DECLARE @Branch INT
--	SET @Branch = dbo.Get_Current_Branch()


Declare @TableNo int
Declare @SumPrice BigInt
DECLARE @CountTableInUse int
SET @SumPrice = (SELECT tFacM.SumPrice FROM tFacM WHERE [No] = @No AND Status = @Status and Branch =  @Branch and AccountYear = @AccountYear)

DECLARE @IntSerialNo Bigint

SET @IntSerialNo = (Select IntSerialNo From tfacm Where [No] = @No  And Status = @Status and Branch =  @Branch and AccountYear = @AccountYear)

set @TableNo = (select dbo.tfacm.TableNo  from tfacm   Where [No] = @No And Status = @Status  And Branch = @Branch and AccountYear = @AccountYear ) 
SET @CountTableInUse=(SELECT COUNT(*)FROM tfacm WHERE dbo.tfacm.TableNo=@TableNo AND Status = @Status  And Branch = @Branch and AccountYear = @AccountYear AND tfacm.[Recursive]=0 AND tfacm.[Balance]=0)
If  @TableNo >0 
begin
	IF @CountTableInUse >= 1
		begin
		UPDATE tTable

		SET Empty=1 
		WHERE dbo.tTable.[No]=@TableNo   AND Branch = @Branch
		END 
		If dbo.Get_TableMonitoring() = 1 AND @CountTableInUse >= 1		---Table Monitoring
		Begin

--	  	 UPDATE dbo.tblSamar_TableReserves SET dbo.tblSamar_TableReserves.intStatusNo=  2
--			FROM    ( SELECT     dbo.tblSamar_TableReserveDetails.intBranch , dbo.tblSamar_TableReserveDetails.intTableReserveNo
--					FROM         dbo.vwSamar_TableUsage_BusyTable INNER JOIN
--					                      dbo.tblSamar_TableReserveDetails ON dbo.vwSamar_TableUsage_BusyTable.intBranch = dbo.tblSamar_TableReserveDetails.intBranch AND 
--					                      dbo.vwSamar_TableUsage_BusyTable.intReseveDetailNo = dbo.tblSamar_TableReserveDetails.intNo
--						WHERE dbo.tblSamar_TableReserveDetails.intTableNo=@TableNo)t
--		WHERE  dbo.tblSamar_TableReserves.intTableReserveNo=t.intTableReserveNo and dbo.tblSamar_TableReserves.intBranch=t.intBranch
--				and dbo.tblSamar_TableReserves.intBranch=@Branch
--
		DECLARE @intTableUsedNo INT      
		SET @intTableUsedNo = (SELECT TOP 1 intTableUsedNo FROM vwSamar_TableUsage_BusyTable      
		WHERE vwSamar_TableUsage_BusyTable.intTableNo=@TableNo and vwSamar_TableUsage_BusyTable.intBranch=@Branch ORDER BY intTableUsedNo DESC   )   
		SET @intTableUsedNo = ISNULL(@intTableUsedNo , 0) 
		UPDATE tblSamar_TableUsage SET tblSamar_TableUsage.nvcEndTime=  dbo.SetTimeFormat(getdate())      
		WHERE  tblSamar_TableUsage.intTableUsedNo = @intTableUsedNo      
 	END	
END 
   Update tfacm
     set Balance = 1 , FacPayment = 1 , [User] = @Uid , BitLock = 1
         Where [No] = @No And Status = @Status  And Branch = @Branch and AccountYear = @AccountYear


-- 	IF @ds IS NULL OR @ds = N'' 
-- 	BEGIN
-- 
-- 		SELECT @Sumprice = SumPrice FROM dbo.tFacM WHERE intSerialNo = @IntSerialNo AND Branch = @Branch  			
-- 		SET @ds =  N'1, 0, 0, 0, 0,' + ' , 0 , ' + CAST(@Sumprice AS NVARCHAR(12) )
-- 	END 

    DECLARE @Date AS NVARCHAR(10)
    SET @Date = dbo.Get_ShamsiDate_For_Current_Shift(GETDATE())
	DECLARE @FichDate AS NVARCHAR(10)
	SET @FichDate = (SELECT [Date] FROM tfacm Where [No] = @No And Status = @Status  And Branch = @Branch and AccountYear = @AccountYear)
	
	IF (@Status =  1 OR @Status = 2 )  
		BEGIN 
		IF @Date = @FichDate    
			exec Do_SaveInDetailsFactorReceived @intSerialNo, @ds ,  @Branch  , 0       
		ELSE 
			BEGIN 
			DECLARE @NewTime NVARCHAR(5)  
			SELECT  @NewTime = dbo.[SetTimeFormat](GETDATE())  
			DECLARE @RegDate NVARCHAR(20)  
			SELECT  @RegDate =   [dbo].[shamsi](GETDATE())


			INSERT  INTO dbo.[tblAcc_Recieved]
                    ( [No] ,
                      [List] ,
                      [Date] ,
                      [RegDate] ,
                      [RegTime] ,
                      [UID] ,
                      [Description] ,
                      [Bestankar] ,
                      [Branch] ,
                      [RecieveType] ,
                      [Code_Bes] ,
                      [intSerialNo] ,
                      [AccountYear]
                    )
                    SELECT  ISNULL(MAX([tblAcc_Recieved].[No]), 0) + 1 ,
                            1 ,
                            @Date ,
                            @RegDate ,
                            @NewTime ,
                            @Uid ,
                            N'������ ���� ������ ' + CAST( [tFacM].[No] AS NVARCHAR(7)) ,
                            [dbo].[tFacM].[SumPrice] ,
                            @Branch ,
                            3 , --5
                            [dbo].[tFacM].[Customer] ,
                            [dbo].[tFacM].[intSerialNo] ,
                            [dbo].[Get_AccountYear]()
                    FROM    [dbo].[tFacM]
					LEFT OUTER JOIN dbo.tblAcc_Recieved ON dbo.tFacM.Branch = dbo.tblAcc_Recieved.Branch
                    WHERE   [dbo].[tFacM].intSerialNo = @IntSerialNo
                    GROUP BY [dbo].[tFacM].[Date] ,
                            [dbo].[tFacM].[SumPrice] ,
                            [dbo].[tFacM].[intSerialNo] ,
							[dbo].[tFacM].[Customer] ,
							[dbo].[tFacM].[No]
				END 
			END 				

--      IF @@ERROR <>0      
--    GoTo EventHandler      


    Exec InsertHistory  @No , @Status , @Uid , 5  , @AccountYear , @Branch






GO

INSERT INTO dbo.tObjects (
	intObjectCode,
	ObjectId,
	ObjectName,
	objectLatinName,
	intObjectType,
	ObjectParent
) VALUES ( 
	/* intObjectCode - int */ 274,
	/* ObjectId - nvarchar(50) */ N'frmGoodTurnOver',
	/* ObjectName - nvarchar(50) */ N'���� ���� �� �����',
	/* objectLatinName - nvarchar(50) */ N'frmGoodTurnOver',
	/* intObjectType - int */ 1,
	/* ObjectParent - int */ 126 ) 
	
GO 

INSERT INTO dbo.tAccess_Object (
	intAccessLevel,
	intObjectCode
) VALUES ( 
	/* intAccessLevel - int */ 1,
	/* intObjectCode - int */ 274 ) 
	
GO 


ALTER  Proc Get_vwFactorDetails_By_intSerialNo (@intSerialNo BIGINT , @Branch INT )
as

select * from vwFactorDetails where  intserialNo =@intSerialNo AND Branch = @Branch




GO


ALTER  View [dbo].[vw_CreditFactor]   AS

SELECT      tfacm.intSerialNo, tfacm.[No], tfacm.Status, tfacm.Owner, tfacm.Customer, tfacm.DiscountTotal, tfacm.SumPrice, tfacm.CarryFeeTotal,
	 tfacm.Recursive, tfacm.FacPayment, tfacm.InCharge, tfacm.OrderType, tfacm.ServePlace, tfacm.StationID, tfacm.ServiceTotal, tfacm.PackingTotal,
 	tfacm.BascoleNo, tfacm.ShiftNo, tfacm.TableNo, tfacm.[Date], tfacm.[Time], tfacm.[User], tfacm.RegDate, tfacm.Branch, tfacm.Balance, tfacm.AccountYear, tfacm.NvcDescription, tfacm.RefFacM,
 	CASE  dbo.tCust.[Name] + ' ' + dbo.tCust.Family  WHEN ' '  THEN tCust.WorkName
			ELSE dbo.tCust.[Name] + ' ' + dbo.tCust.Family 
			END AS [Full Name],  dbo.tPer.nvcFirstName , dbo.tPer.nvcSurName ,dbo.tPer.Job, dbo.tCust.MembershipId As Code, dbo.tCust.Address ,  dbo.tCust.Credit
	FROM         dbo.tFacM left outer JOIN
	                      dbo.tPer ON dbo.tFacM.InCharge = dbo.tPer.pPno and dbo.tFacM.Branch = dbo.tPer.Branch left outer JOIN
	                      dbo.tCust ON dbo.tFacM.Customer = dbo.tCust.Code and (dbo.tFacM.Branch = dbo.tCust.Branch or dbo.tCust.Branch Is Null)
	--WHERE  	 dbo.tFacM.Branch = dbo.Get_Current_Branch()


GO

ALTER  Procedure [dbo].[Get_CreditFactor] ( @Customer Bigint , @AccountYear SMALLINT , @Branch INT )  AS

select dbo.vw_CreditFactor.* from dbo.vw_CreditFactor where dbo.vw_CreditFactor.Customer = @Customer  -- And (dbo.vw_CreditFactor.Incharge  Is  Not Null  Or dbo.vw_CreditFactor.OrderType = 2) 
                                                                                                     And dbo.vw_CreditFactor.Facpayment = 1  AND AccountYear = @AccountYear AND Branch = @Branch


GO

ALTER  View [dbo].[vw_OwedCreditCustomer]   AS
SELECT DISTINCT dbo.tCust.Code, CASE  dbo.tCust.[Name] + ' ' + dbo.tCust.Family  WHEN ' '  THEN tCust.WorkName
			ELSE dbo.tCust.[Name] + ' ' + dbo.tCust.Family 
			END AS [Full Name], dbo.tCust.Credit , tfacm.AccountYear , tfacm.Branch
FROM         dbo.tFacM INNER JOIN
                      dbo.tCust ON dbo.tFacM.Customer = dbo.tCust.Code and  (dbo.tFacM.Branch = dbo.tCust.Branch OR dbo.tCust.Branch IS NULL)
WHERE      (dbo.tCust.Credit > 0) and  (dbo.tfacm.Balance = 0) and (dbo.tfacm.Facpayment = 1) --and dbo.tFacM.Branch = dbo.Get_Current_Branch()


GO



ALTER  PROCEDURE [dbo].[Get_OwedCreditCustomer]  
@AccountYear SMALLINT , @Branch INT
 AS

Select * from dbo.vw_OwedCreditCustomer WHERE AccountYear = @AccountYear AND Branch = @Branch



GO


UPDATE dbo.tObjects SET ObjectName = N'�������� ������� �������' WHERE  ObjectId = 'frmcreditcustomer'
GO 


INSERT INTO dbo.tObjects (
	intObjectCode,
	ObjectId,
	ObjectName,
	objectLatinName,
	intObjectType,
	ObjectParent
) VALUES ( 
	/* intObjectCode - int */ 200,
	/* ObjectId - nvarchar(50) */ N'frmcreditcustomerAccount',
	/* ObjectName - nvarchar(50) */ N'�������� ���� �������',
	/* objectLatinName - nvarchar(50) */ N'frmcreditcustomerAccount',
	/* intObjectType - int */ 1,
	/* ObjectParent - int */ 101 ) 
	
GO 

INSERT INTO dbo.tAccess_Object (
	intAccessLevel,
	intObjectCode
) VALUES ( 
	/* intAccessLevel - int */ 1,
	/* intObjectCode - int */ 200 ) 
GO 

UPDATE dbo.tObjects SET intObjectCode = 199 WHERE intObjectCode = 202
GO 



ALTER  PROCEDURE [dbo].[Get_Factor_Detail_Temp] (@intLanguage int , @intserialNo BIGINT , @Branch INT ) AS
SELECT     dbo.tFacDTemp.*, case @intLanguage when  0 then dbo.tGood.Name 
when 1 then dbo.tGood.LatinName end AS Name
FROM         dbo.tFacDTemp INNER JOIN
                      dbo.tGood ON dbo.tFacDTemp.GoodCode = dbo.tGood.Code
where intserialNo=@intserialNo And Branch =  @Branch


GO



ALTER  PROCEDURE [dbo].[DeleteTempFactors] (@strSelectedFactors NVarChar(4000) , @Branch INT ) 
AS

if rtrim(ltrim(@strSelectedFactors)) <>''
Delete from tFacMTemp where intSerialNo in 
( select cast (word as bigint) from dbo.SplitWithDelimiterNVarChar(@strSelectedFactors ,',')) and Branch = @Branch



GO



UPDATE dbo.tObjects SET intObjectCode = 282 WHERE intObjectCode = 273
GO 
UPDATE dbo.tObjects SET intObjectCode = 276 WHERE intObjectCode = 274
GO 

UPDATE dbo.tObjects SET ObjectName = N'����� ������� ������ �������'  ,ObjectId = 'frmMojodiControl_1' WHERE ObjectId = 'frmMojodiControl'
GO 

UPDATE dbo.tObjects SET ObjectName = N'����� �����' WHERE ObjectId = 'frmInventory'
GO 

INSERT INTO dbo.tObjects (
	intObjectCode,
	ObjectId,
	ObjectName,
	objectLatinName,
	intObjectType,
	ObjectParent
) VALUES ( 
	/* intObjectCode - int */ 273,
	/* ObjectId - nvarchar(50) */ N'frmMojodiControl_2',
	/* ObjectName - nvarchar(50) */ N'����� ������ ���� �����',
	/* objectLatinName - nvarchar(50) */ N'frmMojodiControl_2',
	/* intObjectType - int */ 1,
	/* ObjectParent - int */ 126 ) 
	
GO 

INSERT INTO dbo.tAccess_Object (
	intAccessLevel,
	intObjectCode
) VALUES ( 
	/* intAccessLevel - int */ 1,
	/* intObjectCode - int */ 273 ) 
GO 


INSERT INTO dbo.tObjects (
	intObjectCode,
	ObjectId,
	ObjectName,
	objectLatinName,
	intObjectType,
	ObjectParent
) VALUES ( 
	/* intObjectCode - int */ 274,
	/* ObjectId - nvarchar(50) */ N'frmMojodiControl_3',
	/* ObjectName - nvarchar(50) */ N'����� ����� ������� �����',
	/* objectLatinName - nvarchar(50) */ N'frmMojodiControl_3',
	/* intObjectType - int */ 1,
	/* ObjectParent - int */ 126 ) 
	
GO 

INSERT INTO dbo.tAccess_Object (
	intAccessLevel,
	intObjectCode
) VALUES ( 
	/* intAccessLevel - int */ 1,
	/* intObjectCode - int */ 274 ) 
GO 


INSERT INTO dbo.tObjects (
	intObjectCode,
	ObjectId,
	ObjectName,
	objectLatinName,
	intObjectType,
	ObjectParent
) VALUES ( 
	/* intObjectCode - int */ 275,
	/* ObjectId - nvarchar(50) */ N'frmMojodiControl_4',
	/* ObjectName - nvarchar(50) */ N'����� ������� �������',
	/* objectLatinName - nvarchar(50) */ N'frmMojodiControl_4',
	/* intObjectType - int */ 1,
	/* ObjectParent - int */ 126 ) 
	
GO 

INSERT INTO dbo.tAccess_Object (
	intAccessLevel,
	intObjectCode
) VALUES ( 
	/* intAccessLevel - int */ 1,
	/* intObjectCode - int */ 275 ) 
GO 



ALTER VIEW dbo.vw_Invoice_Table
AS
SELECT     tFacM.intSerialNo, tFacM.[No], tFacM.Status, tFacM.Owner, tFacM.Customer, tFacM.SumPrice, tFacM.Recursive, tFacM.InCharge, tFacM.FacPayment, 
              tFacM.OrderType, tFacM.ServePlace, tFacM.StationId, tFacM.BascoleNo, tFacM.ShiftNo, tFacM.TableNo, tFacD.intInventoryNo, tFacM.[Date], 
              tFacM.[Time], tFacM.[User], tFacM.RegDate, dbo.tShift.[Description] AS ShiftDescription, dbo.tStations.[Description] AS StationDescription, 
              dbo.tOrderType.[Description] AS OrderTypeDescription, dbo.tOrderType.LatinDescription AS OrderTypeLatinDescription, 
              dbo.tServePlace.[Description] AS ServePlaceDescription, dbo.tServePlace.LatinDescription AS ServePlaceLatinDescription, 
              dbo.tTable.[Name] AS TableName, dbo.tPer.nvcFirstName + SPACE(2) + dbo.tPer.nvcSurName AS FullName, dbo.tPer.pPno, 
               tFacM.DiscountTotal   , tFacM.CarryFeeTotal 
             ,  tFacM.ServiceTotal   ,  tFacM.PackingTotal ,   tFacM.Balance , ISNULL(tfacm.GuestNo , '') AS GuestNo , ISNULL(tfacm.TempNo , tfacm.No) AS TempNo
              FROM          tFacM INNER JOIN
			 dbo.tfacD ON tFacM.intserialno = dbo.tfacD.intserialno AND tFacM.Branch = dbo.tfacD.Branch inner join
              dbo.tOrderType ON tFacM.OrderType = dbo.tOrderType.Code INNER JOIN
              dbo.tServePlace ON tFacM.ServePlace = dbo.tServePlace.intServePlace INNER JOIN
              dbo.tShift ON tFacM.ShiftNo = dbo.tShift.Code AND tFacM.Branch = dbo.tShift.Branch LEFT OUTER JOIN
              dbo.tTable ON tFacM.TableNo = dbo.tTable.[No] AND tFacM.Branch = dbo.tTable.Branch Left Outer JOIN
              dbo.tPer ON tFacM.[Incharge] = dbo.tPer.pPno  INNER JOIN
          
              dbo.tStations ON tFacM.StationId = dbo.tStations.StationId AND tFacM.Branch = dbo.tStations.Branch
	--WHERE     tfacm.Branch = dbo.Get_Current_Branch()





GO
-- ����� ��� �� �� ���� ���� ��� �� �����  �� ���

ALTER Proc Get_Factors_Tables ( @intLanguage int , @nvcDate NVARCHAR(8) , @Branch INT )

as

SELECT distinct   Vw_Invoice_Table.TableNo ,  Vw_Invoice_Table.[Date] ,  Vw_Invoice_Table.TableName ,  Vw_Invoice_Table.FullName ,  
                   Vw_Invoice_Table.SumPrice ,  Vw_Invoice_Table.[Time] ,  Vw_Invoice_Table.[No] ,  Vw_Invoice_Table.intSerialNo
		, Vw_Invoice_Table.GuestNo , Vw_Invoice_Table.TempNo , Vw_Invoice_Table.ShiftDescription , Vw_Invoice_Table.FacPayment
FROM         Vw_Invoice_Table

Where  Vw_Invoice_Table.[TableNo] >0  and Vw_Invoice_Table.[Date] = @nvcDate  And Vw_Invoice_Table.Recursive = 0 --And Vw_Invoice_Table.Facpayment = 0 
ORDER BY Vw_Invoice_Table.TableNo --Vw_Invoice_Table.[No] , Vw_Invoice_Table.[Date] ,Vw_Invoice_Table.[Time]




GO


ALTER PROCEDURE [dbo].[Get_Define_Factors]
    (
      @Status INT ,
      @User INT ,
      @No BIGINT ,
      @AccountYear SMALLINT ,
      @Branch INT 
    )
AS 
--    DECLARE @Branch INT
--    SELECT  @Branch = [dbo].[Get_Current_Branch]()
    DECLARE @AccessLevel INT
    DECLARE @ShiftNo INT
    DECLARE @Date AS NVARCHAR(10)
    SET @ShiftNo = dbo.Get_Shift(dbo.SetTimeFormat(GETDATE()))
    SET @Date = [dbo].[Get_ShamsiDate_For_Current_Shift](GETDATE())

    SET @AccessLevel = ISNULL(( SELECT MIN(AccessLevel)
                                FROM    ( SELECT TOP 100 PERCENT
                                                    CASE WHEN [ObjectId] LIKE N'viewallstationsfactors'
                                                         THEN 1
                                                         WHEN [ObjectId] LIKE N'ViewAllCurrentDayInvoices'
                                                         THEN 2
                                                         WHEN [ObjectId] LIKE N'ViewAllCurrentShiftInvoices'
                                                         THEN 3
                                                         ELSE 4
                                                    END AS AccessLevel
                                          FROM      dbo.tUser
                                                    INNER JOIN dbo.tAccess_Object ON dbo.tUser.intAccessLevel = dbo.tAccess_Object.intAccessLevel
                                                    INNER JOIN dbo.tObjects ON dbo.tAccess_Object.intObjectCode = dbo.tObjects.intObjectCode
                                          WHERE     --tObjects.ObjectId LIKE 'viewallstationsfactors' AND
                                                    UID = @User
                                                    AND dbo.tUser.Branch = @Branch
                                                    AND ( [dbo].[tObjects].[ObjectId] LIKE N'viewallstationsfactors'
                                                          OR [dbo].[tObjects].[ObjectId] LIKE N'ViewAllCurrentDayInvoices'
                                                          OR [dbo].[tObjects].[ObjectId] LIKE N'ViewAllCurrentShiftInvoices'
                                                        )
                                          ORDER BY  [dbo].[tObjects].[intObjectCode] DESC
                                        ) T1
                              ), 4)
    
    DECLARE @intAccessLevel INT
    SELECT  @intAccessLevel = intAccessLevel
    FROM    [dbo].[tUser]
    WHERE   uid = @User
            AND [Branch] = @Branch
    IF @intAccessLevel = 1 
        SET @AccessLevel = @intAccessLevel

    SELECT  dbo.tFacM.* ,
            dbo.tPer.nvcFirstName ,
            dbo.tPer.nvcSurName ,
            ISNULL(tcust.WorkName + dbo.tCust.Family , '') + ISNULL(tSupplier.WorkName + dbo.tSupplier.Family , '') AS CustomerName
            ,  ISNULL(tfacm.GuestNo ,'') AS GuestNo , ISNULL(tfacm.TempNo , tfacm.[No]) AS TempNo
            , tshift.Description AS ShiftDescription
    FROM    dbo.tFacM
            INNER JOIN dbo.tUser ON dbo.tFacM.Branch = dbo.tUser.Branch
                                    AND dbo.tFacM.[User] = dbo.tUser.UID
            INNER JOIN dbo.tPer ON dbo.tUser.Branch = dbo.tPer.Branch
                                   AND dbo.tUser.pPno = dbo.tPer.pPno
            INNER JOIN dbo.tShift ON dbo.tFacM.Branch = dbo.tShift.Branch
                                   AND dbo.tfacm.ShiftNo = dbo.tShift.Code
            LEFT OUTER JOIN dbo.tCust ON dbo.tFacM.Customer = dbo.tCust.Code AND dbo.tFacM.Branch = dbo.tCust.Branch
            LEFT OUTER JOIN dbo.tSupplier ON dbo.tFacM.Owner = dbo.tSupplier.Code AND dbo.tFacM.Branch = dbo.tSupplier.Branch
    WHERE   ( @AccessLevel = 1
              OR ( @AccessLevel = 2
                   AND [dbo].[tFacM].[Date] = @Date
                 )
              OR ( @AccessLevel = 3
                   AND [ShiftNo] = @ShiftNo
                   AND [dbo].[tFacM].[Date] = @Date
                 )
	      OR ( @AccessLevel = 4
	           AND dbo.tFacM.[ShiftNo] = @ShiftNo
	           AND dbo.tFacM.[Date] = @Date
	           AND dbo.tFacM.[User] = @User
	         )
            )
            AND dbo.tFacM.Status = @Status
            AND dbo.tFacM.[No] = @No
            AND AccountYear = @AccountYear
            AND dbo.tFacM.Branch = @Branch
--===============================================



GO


ALTER PROCEDURE [dbo].[Get_Define_Factors_Temp]
    (
      @Status INT ,
      @User INT ,
      @TempNo BIGINT ,
      @AccountYear SMALLINT ,
      @Branch INT 
    )
AS 
--    DECLARE @Branch INT
--    SELECT  @Branch = [dbo].[Get_Current_Branch]()
    DECLARE @AccessLevel INT
    DECLARE @ShiftNo INT
    DECLARE @Date AS NVARCHAR(10)
    SET @ShiftNo = dbo.Get_Shift(dbo.SetTimeFormat(GETDATE()))
    SET @Date = [dbo].[Get_ShamsiDate_For_Current_Shift](GETDATE())

    SET @AccessLevel = ISNULL(( SELECT MIN(AccessLevel)
                                FROM    ( SELECT TOP 100 PERCENT
                                                    CASE WHEN [ObjectId] LIKE N'viewallstationsfactors'
                                                         THEN 1
                                                         WHEN [ObjectId] LIKE N'ViewAllCurrentDayInvoices'
                                                         THEN 2
                                                         WHEN [ObjectId] LIKE N'ViewAllCurrentShiftInvoices'
                                                         THEN 3
                                                         ELSE 4
                                                    END AS AccessLevel
                                          FROM      dbo.tUser
                                                    INNER JOIN dbo.tAccess_Object ON dbo.tUser.intAccessLevel = dbo.tAccess_Object.intAccessLevel
                                                    INNER JOIN dbo.tObjects ON dbo.tAccess_Object.intObjectCode = dbo.tObjects.intObjectCode
                                          WHERE     --tObjects.ObjectId LIKE 'viewallstationsfactors' AND
                                                    UID = @User
                                                    AND dbo.tUser.Branch = @Branch
                                                    AND ( [dbo].[tObjects].[ObjectId] LIKE N'viewallstationsfactors'
                                                          OR [dbo].[tObjects].[ObjectId] LIKE N'ViewAllCurrentDayInvoices'
                                                          OR [dbo].[tObjects].[ObjectId] LIKE N'ViewAllCurrentShiftInvoices'
                                                        )
                                          ORDER BY  [dbo].[tObjects].[intObjectCode] DESC
                                        ) T1
                              ), 4)
    
    DECLARE @intAccessLevel INT
    SELECT  @intAccessLevel = intAccessLevel
    FROM    [dbo].[tUser]
    WHERE   uid = @User
            AND [Branch] = @Branch
    IF @intAccessLevel = 1 
        SET @AccessLevel = @intAccessLevel

    SELECT  dbo.tFacM.* ,
            dbo.tPer.nvcFirstName ,
            dbo.tPer.nvcSurName ,
            ISNULL(tcust.WorkName + dbo.tCust.Family , '') + ISNULL(tSupplier.WorkName + dbo.tSupplier.Family , '') AS CustomerName
            ,  ISNULL(tfacm.GuestNo ,'') AS GuestNo , ISNULL(tfacm.TempNo , tfacm.[No]) AS TempNo
            , tshift.Description AS ShiftDescription
    FROM    dbo.tFacM
            INNER JOIN dbo.tUser ON dbo.tFacM.Branch = dbo.tUser.Branch
                                    AND dbo.tFacM.[User] = dbo.tUser.UID
            INNER JOIN dbo.tPer ON dbo.tUser.Branch = dbo.tPer.Branch
                                   AND dbo.tUser.pPno = dbo.tPer.pPno
            INNER JOIN dbo.tShift ON dbo.tFacM.Branch = dbo.tShift.Branch
                                   AND dbo.tfacm.ShiftNo = dbo.tShift.Code
            LEFT OUTER JOIN dbo.tCust ON dbo.tFacM.Customer = dbo.tCust.Code AND dbo.tFacM.Branch = dbo.tCust.Branch
            LEFT OUTER JOIN dbo.tSupplier ON dbo.tFacM.Owner = dbo.tSupplier.Code AND dbo.tFacM.Branch = dbo.tSupplier.Branch
    WHERE   ( @AccessLevel = 1
              OR @AccessLevel = 2
              OR  (@AccessLevel = 3
                   AND [ShiftNo] = @ShiftNo)
			  OR ( @AccessLevel = 4
                   AND [ShiftNo] = @ShiftNo
	               AND dbo.tFacM.[User] = @User)
            )
            AND dbo.tFacM.Status = @Status
            AND dbo.tFacM.[TempNo] = @TempNo
            AND AccountYear = @AccountYear
            AND dbo.tFacM.Branch = @Branch
            AND dbo.tFacM.[Date] = @Date
--===============================================



GO



--����� ��� ���� ���� ��� ����� 
--����� ����� ���� ���� ����� ����� 
--91/03/01

ALTER  PROCEDURE dbo.Delete_tFacmd	
(
	@No     Bigint ,
	@Status	int ,
	@AccountYear	Smallint ,
	@Branch INT ,
	@Result INT Out
)
As
DECLARE @intSerialNo BIGINT

Begin Tran

--DECLARE @Branch INT
-- SET @Branch = dbo.Get_Current_Branch()

SET @intSerialNo = (SELECT tFacM.intSerialNo FROM tFacM WHERE [No] = @No AND Status = @Status and Branch =  @Branch AND AccountYear = @AccountYear)


	Exec DeleteMojodiCalculate @Status , @intserialNo  , 1 , @AccountYear , @Branch
	IF @@ERROR <>0
		GoTo EventHandler

	Delete From dbo.tHistory Where intSerialNo = @intSerialNo and Branch =  @Branch
	Delete From dbo.tfacd  Where intSerialNo = @intSerialNo and Branch =  @Branch
	Delete From dbo.tfacd2  Where intSerialNo = @intSerialNo and Branch =  @Branch
	Delete From dbo.tRepfaceditm  Where intSerialNo = @intSerialNo and Branch =  @Branch
	Exec DeleteFactorChildren @intSerialNo , @Branch

    IF @Status = 6
        BEGIN
			DECLARE @intserialNo2 BIGINT
			SET @intSerialNo2 = @intSerialNo + 1 
			EXEC DeleteMojodiCalculate 7, @intSerialNo2 , 1, @AccountYear , @Branch
            DELETE  FROM dbo.[tFacM]
            WHERE   intSerialNo = @intSerialNo2
                    AND Branch = @Branch 
        END
    IF @@ERROR <> 0 
        GOTO EventHandler

	Delete From dbo.tfacm  Where intSerialNo = @intSerialNo and Branch =  @Branch
    IF @@ERROR <>0
	        GoTo EventHandler


COMMIT TRANSACTION
Set @Result = 1
Return @Result


EventHandler:
    ROLLBACK TRAN
    Set @Result = 0
    RETURN @Result




GO



ALTER   PROCEDURE Update_tFacM_Recursive
(
@No  Bigint,
@Status int,
@Recursive int,
@Uid int,
@Balance Bit,
@FacPayment Bit ,
@AccountYear Smallint = NULL ,
@Branch INT 
)

AS
Declare @TableNo int
DECLARE @intTableUsedNo INT      
IF @AccountYear Is Null 
	SET @AccountYear = dbo.Get_AccounYear()

DECLARE @intSerialNo BIGINT

--DECLARE @Branch INT
--	SET @Branch = dbo.Get_Current_Branch()

SET @intSerialNo = (SELECT tFacM.intSerialNo FROM tFacM WHERE [No] = @No AND Status = @Status and Branch =  @Branch and AccountYear = @AccountYear)

UPDATE tFacM
     SET Recursive= @Recursive
         WHERE tFacM.intSerialNo = @intserialNo And  Branch = @Branch 

If @Status = 6
BEGIN 
	DECLARE @intserialNo2 BIGINT
	SET @intSerialNo2 = @intSerialNo + 1  
	UPDATE tFacM
		 SET Recursive= @Recursive
			 WHERE tFacM.intSerialNo = @intserialNo2 And  Branch = @Branch 
END 

If @Recursive = 1 
Begin

UPDATE tFacM
     SET FacPayment = 0 , Balance = 0
         WHERE tFacM.[No]=@No   AND Status = @Status And  Branch = @Branch and AccountYear = @AccountYear

SET @TableNo = ISNULL((Select TableNo From tfacm   Where  tFacM.[No]=@No   AND Status = @Status And  Branch = @Branch and AccountYear = @AccountYear) , 0)
  UPDATE tTable
       SET Empty = 1 
           WHERE dbo.tTable.[No] = @TableNo
	If dbo.Get_TableMonitoring() = 1 AND @TableNo > 0		---Table Monitoring
	Begin
		SET @intTableUsedNo = (SELECT TOP 1 intTableUsedNo FROM vwSamar_TableUsage_BusyTable      
		WHERE vwSamar_TableUsage_BusyTable.intTableNo=@TableNo and vwSamar_TableUsage_BusyTable.intBranch=@Branch ORDER BY intTableUsedNo DESC   )   
		SET @intTableUsedNo = ISNULL(@intTableUsedNo , 0) 
		UPDATE tblSamar_TableUsage SET tblSamar_TableUsage.bitIsValid = 0      
		WHERE  tblSamar_TableUsage.intTableUsedNo = @intTableUsedNo      
 	END	


Exec DeleteFactorChildren @intSerialNo , @Branch

UPDATE dbo.tblAcc_Recieved SET Bestankar = 0 WHERE intSerialNo = @intSerialNo And  Branch = @Branch  

End

If @Recursive = 0

Begin
   Update tFacm 
       SET FacPayment = @FacPayment , Balance = @Balance
         WHERE tFacM.[No]=@No   AND Status = @Status And  Branch = @Branch and AccountYear = @AccountYear

	SET @TableNo = ISNULL((Select TableNo From tfacm   Where  tFacM.[No]=@No   AND Status = @Status And  Branch = @Branch and AccountYear = @AccountYear) , 0)
    UPDATE tTable
       SET Empty = 0 
           WHERE dbo.tTable.[No] = @TableNo
	If dbo.Get_TableMonitoring() = 1 AND @TableNo > 0		---Table Monitoring
	Begin
		SET @intTableUsedNo = (SELECT TOP 1 intTableUsedNo FROM vwSamar_TableUsage_BusyTable      
		WHERE vwSamar_TableUsage_BusyTable.intTableNo=@TableNo and vwSamar_TableUsage_BusyTable.intBranch=@Branch ORDER BY intTableUsedNo DESC   )   
		SET @intTableUsedNo = ISNULL(@intTableUsedNo , 0) 
		UPDATE tblSamar_TableUsage SET tblSamar_TableUsage.bitIsValid = 1      
		WHERE  tblSamar_TableUsage.intTableUsedNo = @intTableUsedNo      
 	END	

	IF @Balance = 1
	BEGIN 
	DELETE FROM tFacCash WHERE intSerialNo = @intSerialNo AND [Branch] = @Branch
	INSERT INTO tFacCash (intSerialNo, intAmount ,branch)
		SELECT @intSerialNo AS
	 intSerialNo, Sumprice,@Branch From tFacM  WHERE tFacM.[No]=@No   AND Status = 2 And  Branch = @Branch and AccountYear = @AccountYear

	END 
End

Declare @Monitor1 Bit
Declare @Monitor2 Bit

Set @Monitor1 = (Select Count(Stationid) from  dbo.tStations Where (StationType  &  16  = 16) and  IsActive =1 And Branch =  dbo.Get_Current_Branch())
Set @Monitor2 = (Select Count(Stationid) from  dbo.tStations Where (StationType  &  32  = 32) and  IsActive =1 And Branch =  dbo.Get_Current_Branch())


If @Monitor1 > 0 
  exec Notify_to_Clients
Else If @Monitor2 > 0 
  exec Notify_to_Clients

If @Recursive = 0
   Exec InsertHistory  @No, @Status , @Uid , 8 ,@AccountYear , @Branch
Else if @Recursive = 1
   Exec InsertHistory  @No, @Status , @Uid , 3 ,@AccountYear , @Branch 

---------------------------------------Mojodi Control Online---------------------------------------------------------

Exec DeleteMojodiCalculate @Status , @intserialNo , @Recursive ,@AccountYear , @Branch
If @Status = 6
	EXEC DeleteMojodiCalculate 7, @intSerialNo2 , @Recursive, @AccountYear , @Branch

--------------------------------------------------------------------------------------------------------------------------------------





GO






ALTER   PROCEDURE Update_tfacm_Balance  
(
@No Bigint,
@Status int,
@Uid  int,
@AccountYear Smallint = NULL ,
@ds NVARCHAR(4000) = NULL ,-- For Ppc
@Branch INT  
)
AS
IF @AccountYear IS NULL
	SET @AccountYear = dbo.Get_AccountYear()
--DECLARE @Branch INT
--	SET @Branch = dbo.Get_Current_Branch()


Declare @TableNo int
Declare @SumPrice BigInt
DECLARE @CountTableInUse int
SET @SumPrice = (SELECT tFacM.SumPrice FROM tFacM WHERE [No] = @No AND Status = @Status and Branch =  @Branch and AccountYear = @AccountYear)

DECLARE @IntSerialNo Bigint

SET @IntSerialNo = (Select IntSerialNo From tfacm Where [No] = @No  And Status = @Status and Branch =  @Branch and AccountYear = @AccountYear)

set @TableNo = (select dbo.tfacm.TableNo  from tfacm   Where [No] = @No And Status = @Status  And Branch = @Branch and AccountYear = @AccountYear ) 
SET @CountTableInUse=(SELECT COUNT(*)FROM tfacm WHERE dbo.tfacm.TableNo=@TableNo AND Status = @Status  And Branch = @Branch and AccountYear = @AccountYear AND tfacm.[Recursive]=0 AND tfacm.[Balance]=0)
If  @TableNo >0 
begin
	IF @CountTableInUse >= 1
		begin
		UPDATE tTable

		SET Empty=1 
		WHERE dbo.tTable.[No]=@TableNo   AND Branch = @Branch
		END 
		If dbo.Get_TableMonitoring() = 1 AND @CountTableInUse >= 1		---Table Monitoring
		Begin

--	  	 UPDATE dbo.tblSamar_TableReserves SET dbo.tblSamar_TableReserves.intStatusNo=  2
--			FROM    ( SELECT     dbo.tblSamar_TableReserveDetails.intBranch , dbo.tblSamar_TableReserveDetails.intTableReserveNo
--					FROM         dbo.vwSamar_TableUsage_BusyTable INNER JOIN
--					                      dbo.tblSamar_TableReserveDetails ON dbo.vwSamar_TableUsage_BusyTable.intBranch = dbo.tblSamar_TableReserveDetails.intBranch AND 
--					                      dbo.vwSamar_TableUsage_BusyTable.intReseveDetailNo = dbo.tblSamar_TableReserveDetails.intNo
--						WHERE dbo.tblSamar_TableReserveDetails.intTableNo=@TableNo)t
--		WHERE  dbo.tblSamar_TableReserves.intTableReserveNo=t.intTableReserveNo and dbo.tblSamar_TableReserves.intBranch=t.intBranch
--				and dbo.tblSamar_TableReserves.intBranch=@Branch
--
		DECLARE @intTableUsedNo INT      
		SET @intTableUsedNo = (SELECT TOP 1 intTableUsedNo FROM vwSamar_TableUsage_BusyTable      
		WHERE vwSamar_TableUsage_BusyTable.intTableNo=@TableNo and vwSamar_TableUsage_BusyTable.intBranch=@Branch ORDER BY intTableUsedNo DESC   )   
		SET @intTableUsedNo = ISNULL(@intTableUsedNo , 0) 
		UPDATE tblSamar_TableUsage SET tblSamar_TableUsage.nvcEndTime=  dbo.SetTimeFormat(getdate())      
		WHERE  tblSamar_TableUsage.intTableUsedNo = @intTableUsedNo      
 	END	
END 
   Update tfacm
     set Balance = 1 , FacPayment = 1 , [User] = @Uid , BitLock = 1
         Where [No] = @No And Status = @Status  And Branch = @Branch and AccountYear = @AccountYear


-- 	IF @ds IS NULL OR @ds = N'' 
-- 	BEGIN
-- 
-- 		SELECT @Sumprice = SumPrice FROM dbo.tFacM WHERE intSerialNo = @IntSerialNo AND Branch = @Branch  			
-- 		SET @ds =  N'1, 0, 0, 0, 0,' + ' , 0 , ' + CAST(@Sumprice AS NVARCHAR(12) )
-- 	END 

    DECLARE @Date AS NVARCHAR(10)
    SET @Date = dbo.Get_ShamsiDate_For_Current_Shift(GETDATE())
	DECLARE @FichDate AS NVARCHAR(10)
	SET @FichDate = (SELECT [Date] FROM tfacm Where [No] = @No And Status = @Status  And Branch = @Branch and AccountYear = @AccountYear)
	
	IF (@Status =  1 OR @Status = 2 )  
		BEGIN 
		IF @Date = @FichDate    
			exec Do_SaveInDetailsFactorReceived @intSerialNo, @ds ,  @Branch  , 0       
		ELSE 
			BEGIN 
			DECLARE @NewTime NVARCHAR(5)  
			SELECT  @NewTime = dbo.[SetTimeFormat](GETDATE())  
			DECLARE @RegDate NVARCHAR(20)  
			SELECT  @RegDate =   [dbo].[shamsi](GETDATE())


			INSERT  INTO dbo.[tblAcc_Recieved]
                    ( [No] ,
                      [List] ,
                      [Date] ,
                      [RegDate] ,
                      [RegTime] ,
                      [UID] ,
                      [Description] ,
                      [Bestankar] ,
                      [Branch] ,
                      [RecieveType] ,
                      [Code_Bes] ,
                      [intSerialNo] ,
                      [AccountYear]
                    )
                    SELECT  ISNULL(MAX([tblAcc_Recieved].[No]), 0) + 1 ,
                            1 ,
                            @Date ,
                            @RegDate ,
                            @NewTime ,
                            @Uid ,
                            N'������ ���� ������ ' + CAST( [tFacM].[No] AS NVARCHAR(7)) ,
                            [dbo].[tFacM].[SumPrice] ,
                            @Branch ,
                            3 , --5
                            [dbo].[tFacM].[Customer] ,
                            [dbo].[tFacM].[intSerialNo] ,
                            [dbo].[Get_AccountYear]()
                    FROM    [dbo].[tFacM]
					LEFT OUTER JOIN dbo.tblAcc_Recieved ON dbo.tFacM.Branch = dbo.tblAcc_Recieved.Branch
                    WHERE   [dbo].[tFacM].intSerialNo = @IntSerialNo
                    GROUP BY [dbo].[tFacM].[Date] ,
                            [dbo].[tFacM].[SumPrice] ,
                            [dbo].[tFacM].[intSerialNo] ,
							[dbo].[tFacM].[Customer] ,
							[dbo].[tFacM].[No]
				END 
			END 				

--      IF @@ERROR <>0      
--    GoTo EventHandler      


    Exec InsertHistory  @No , @Status , @Uid , 5  , @AccountYear , @Branch


Declare @SumRecieved INT
SET @SumRecieved =0

Set @SumRecieved =(Select IsNull(SUM(Bestankar),0)  From   tblAcc_Recieved 
 Where intSerialNo = @intSerialNo  and Branch = @Branch )
Set @SumRecieved = @SumRecieved + (Select IsNull(SUM(intAmount),0)  From   dbo.tFacCash 
 Where intSerialNo = @intSerialNo  and Branch = @Branch )
Set @SumRecieved = @SumRecieved + (Select IsNull(SUM(intAmount),0)  From   dbo.tFacCard
 Where intSerialNo = @intSerialNo  and Branch = @Branch )
Set @SumRecieved = @SumRecieved + (Select IsNull(SUM(intChequeAmount),0)  From   dbo.tFacCheque
 Where intSerialNo = @intSerialNo  and Branch = @Branch )
Set @SumRecieved = @SumRecieved + (Select IsNull(SUM(intAmount),0)  From   dbo.tFacCredit
 Where intSerialNo = @intSerialNo  and Branch = @Branch )

    IF @SumRecieved >= @sumPrice AND @Status = 2 
        UPDATE  tfacm
        SET     [Balance] = 1 , FacPayment = 1
        WHERE   [intSerialNo] = @intserialNo AND Branch = @Branch
    ELSE IF @SumRecieved < @sumPrice AND @Status = 2 
        UPDATE  tfacm
        SET     [Balance] = 0
        WHERE   [intSerialNo] = @intserialNo AND Branch = @Branch




GO


ALTER  PROCEDURE [dbo].[Get_History_By_Parameters]
    (
      @FromNo BIGINT = 0 ,
      @ToNo BIGINT = 0 ,
      @FromDate NVARCHAR(50) = '' ,
      @ToDate NVARCHAR(50) = '' ,
      @FromTime NVARCHAR(50) = '' ,
      @ToTime NVARCHAR(50) = '' ,
      @ActionCode INT = 0 ,
      @Status INT = 0 ,
      @Branch1 INT ,
      @Branch2 INT 
    )
AS 
    DECLARE @FromStatus INT
    DECLARE @ToStatus INT

    DECLARE @FromActionCode INT
    DECLARE @ToActionCode INT

    DECLARE @TempInt INT
    DECLARE @TempStr NVARCHAR(50)
	
    IF @Status = 0 
        BEGIN
            SET @FromStatus = ( SELECT  ISNULL(MIN(Status), 1)
                                FROM    dbo.tFacM
                              )
            SET @ToStatus = ( SELECT    ISNULL(MAX(Status), 2)
                              FROM      dbo.tFacM
                            )
        END
    ELSE 
        BEGIN
            SET @FromStatus = @Status
            SET @ToStatus = @Status
        END

    IF @FromNo = 0 
        SET @FromNo = 1
    IF @ToNo = 0 
        SET @ToNo = 999999999
    IF @FromNo > @ToNo 
        BEGIN
            SET @TempInt = @FromNo
            SET @FromNo = @ToNo
            SET @ToNo = @TempInt
        END

    IF @FromDate = '' 
        SET @FromDate = '01/01/01'

    IF @ToDate = '' 
        SET @ToDate = '99/12/30'

    IF @FromDate > @ToDate 
        BEGIN
            SET @TempStr = @FromDate
            SET @FromDate = @ToDate
            SET @ToDate = @TempStr
        END

    IF @FromTime = '' 
        SET @FromTime = '00:00'

    IF @ToTime = '' 
        SET @ToTime = '23:59'
    IF @FromTime > @ToDate 
        BEGIN
            SET @TempStr = @FromTime
            SET @FromTime = @ToDate
            SET @ToDate = @TempStr
        END

    IF @ActionCode = 0 
        BEGIN
            SET @FromActionCode = ( SELECT  ISNULL(MIN(ActionCode), 0)
                                    FROM    dbo.tAction
                                  )
            SET @ToActionCode = ( SELECT    ISNULL(MAX(ActionCode), 0)
                                  FROM      dbo.tAction
                                )
        END
    ELSE 
        BEGIN
            SET @FromActionCode = @ActionCode
            SET @ToActionCode = @ActionCode
        END

    SELECT  t.[No] ,
            t.Status ,
            s.Code ,
            s.intSerialNo ,
            s.RegDate ,
            s.RegTime ,
            s.UID ,
            s.ActionCode ,
            dbo.tPer.nvcFirstName ,
            dbo.tPer.nvcSurName ,
            s.Branch
    FROM    ( SELECT    *
              FROM      dbo.tFacM
              WHERE     [No] >= @FromNo 
                        AND [No] <= @ToNo 
                        AND Status >= @FromStatus 
                        AND Status <= @ToStatus 
                        AND dbo.tFacM.Branch >= @Branch1
                        AND dbo.tFacM.Branch <= @Branch2
            ) t
            INNER JOIN ( SELECT *
                         FROM   dbo.tHistory
                         WHERE  dbo.tHistory.RegDate >= @FromDate
                                AND dbo.tHistory.RegDate <= @ToDate
                                AND dbo.tHistory.RegTime >= @FromTime
                                AND dbo.tHistory.RegTime <= @ToTime
                                AND dbo.tHistory.ActionCode >= @FromActionCode
                                AND dbo.tHistory.ActionCode <= @ToActionCode
								AND dbo.tHistory.Branch >= @Branch1
								AND dbo.tHistory.Branch <= @Branch2
                       ) s ON t.intSerialNo = s.intSerialNo
                              AND t.Branch = s.Branch
            INNER JOIN dbo.tUser ON s.UID = dbo.tUser.UID
                                    AND s.Branch = dbo.tUser.Branch
            INNER JOIN dbo.tPer ON dbo.tUser.pPno = dbo.tPer.pPno
                                   AND dbo.tPer.Branch = dbo.tUser.Branch
    ORDER BY t.No DESC ,
            s.Regdate ,
            RegTime ,
            ActionCode
--===============================================

GO


UPDATE dbo.tObjects SET ObjectName = N'���� �������� ����' WHERE intObjectCode = 102
GO 

UPDATE dbo.tObjects SET ObjectParent = 102 WHERE ObjectId = 'frmBank'
GO 



--����� ����� ��� 
--90/05/17



ALTER  PROCEDURE [dbo].[Get_CustSaleSummary]
    (
      @Branch INT ,
      @DateBefore NVARCHAR(8) ,
      @DateAfter NVARCHAR(8)
    )
AS 

    SELECT  [dbo].[tFacM].[Date] ,
            [dbo].[tFacM].[No] ,
            [dbo].[tFacM].[User] ,
            [dbo].[tFacM].[Balance] ,
            [dbo].[tFacM].[Branch] ,
            [dbo].[tFacM].[Status] ,
            [dbo].[tFacM].[Recursive] ,
            [dbo].[tFacM].[SumPrice] - (ISNULL(t1.Bestankar1 ,0) + ISNULL(t2.Bestankar2 ,0) 
							   + ISNULL(t3.Bestankar3 ,0) + ISNULL(t4.Bestankar4 ,0) 
							   + ISNULL(t5.Bestankar5 ,0))  	AS SumPrice,
			[dbo].[tFacM].[Customer] ,
            ( SELECT    dbo.tCust.[Name] + SPACE(3) + dbo.tCust.family + dbo.tCust.WorkName
              FROM      [dbo].[tCust]
              WHERE     [Code] = [dbo].[tFacM].[Customer]
                        AND [Branch] = [dbo].[tFacM].[Branch]
            ) AS [CustomerName] ,
            ISNULL(( SELECT [Tafsili]
                     FROM   [dbo].[tCust]
                     WHERE  [Code] = [dbo].[tFacM].[Customer]
                            AND [Branch] = [dbo].[tFacM].[Branch]
                   ), 0) AS [CustomerTafsili]
                   , ISNULL(t1.Bestankar1 ,0) AS Bestankar1 
                   , ISNULL(t2.Bestankar2 ,0) AS Bestankar2
                   , ISNULL(t3.Bestankar3 ,0) AS Bestankar3
                   , ISNULL(t4.Bestankar4 ,0) AS Bestankar4
                   , ISNULL(t5.Bestankar5 ,0) AS Bestankar5
    FROM    [dbo].[tFacM]
	LEFT OUTER JOIN 
		(Select SUM(IsNull(Bestankar,0)) AS Bestankar1 , intSerialNo , Branch From   tblAcc_Recieved GROUP BY intSerialNo , Branch )t1
			ON  t1.intSerialNo = dbo.tFacM.intSerialNo  and t1.Branch = dbo.tFacM.Branch 	
	LEFT OUTER JOIN 
		(Select SUM(IsNull(intAmount,0)) AS Bestankar2 ,intSerialNo , Branch From   tFacCash GROUP BY intSerialNo , Branch )t2
			ON  t2.intSerialNo = dbo.tFacM.intSerialNo  and t2.Branch = dbo.tFacM.Branch 	
	LEFT OUTER JOIN 
		(Select SUM(IsNull(intAmount,0)) AS Bestankar3 , intSerialNo , Branch From   tFacCard GROUP BY intSerialNo , Branch )t3
			ON  t3.intSerialNo = dbo.tFacM.intSerialNo  and t3.Branch = dbo.tFacM.Branch 	
	LEFT OUTER JOIN 
		(Select SUM(IsNull(intAmount,0)) AS Bestankar4 , intSerialNo , Branch From   dbo.tFacCredit GROUP BY intSerialNo , Branch )t4
			ON  t4.intSerialNo = dbo.tFacM.intSerialNo  and t4.Branch = dbo.tFacM.Branch 	
	LEFT OUTER JOIN 
		(Select SUM(IsNull(intchequeamount,0)) AS Bestankar5 ,intSerialNo , Branch From   tFacCheque GROUP BY intSerialNo , Branch )t5
			ON  t5.intSerialNo = dbo.tFacM.intSerialNo  and t5.Branch = dbo.tFacM.Branch 	

    WHERE   [Recursive] = 0
            AND [Status] = 2
            --AND [dbo].[tFacM].[Customer] > 0
            AND [dbo].[tFacM].[transferAccounting] = 0
            AND [dbo].[tFacM].[Branch] =@Branch
            AND [dbo].[tFacM].[Date] >= @DateBefore
            AND [dbo].[tFacM].[Date] <= @DateAfter
            --AND [dbo].[tFacM].[Balance] = 0
			--AND [dbo].[tFacM].[Facpayment] = 1
			and (Facpayment = 1 or Incharge is null)
			and tfacm.SumPrice > (ISNULL(t1.Bestankar1 ,0) + ISNULL(t2.Bestankar2 ,0) 
							   + ISNULL(t3.Bestankar3 ,0) + ISNULL(t4.Bestankar4 ,0) 
							   + ISNULL(t5.Bestankar5 ,0) )


GO 

--exec Get_CustSaleSummary 1, N'91/03/10', N'91/03/10'
--GO 


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Get_CustSaleSummary_GroupByCode]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Get_CustSaleSummary_GroupByCode]
GO

--����� ���� ����� �� ����� ����� �� ��� ������ �����
CREATE PROCEDURE [dbo].[Get_CustSaleSummary_GroupByCode]
    (
      @Branch INT ,
      @DateBefore NVARCHAR(8) ,
      @DateAfter NVARCHAR(8)
    )
AS 

SELECT Customer , CustomerName , CustomerTafsili ,Date , SUM(SumPrice) AS Bedehkar
FROM 
(    SELECT  [dbo].[tFacM].[Date] ,
            [dbo].[tFacM].[No] ,
            [dbo].[tFacM].[User] ,
            [dbo].[tFacM].[Balance] ,
            [dbo].[tFacM].[Branch] ,
            [dbo].[tFacM].[Status] ,
            [dbo].[tFacM].[Recursive] ,
            [dbo].[tFacM].[SumPrice] - (ISNULL(t1.Bestankar1 ,0) + ISNULL(t2.Bestankar2 ,0) 
							   + ISNULL(t3.Bestankar3 ,0) + ISNULL(t4.Bestankar4 ,0) 
							   + ISNULL(t5.Bestankar5 ,0))  	AS SumPrice,
			[dbo].[tFacM].[Customer] ,
            ( SELECT    dbo.tCust.[Name] + SPACE(3) + dbo.tCust.family + dbo.tCust.WorkName
              FROM      [dbo].[tCust]
              WHERE     [Code] = [dbo].[tFacM].[Customer]
                        AND [Branch] = [dbo].[tFacM].[Branch]
            ) AS [CustomerName] ,
            ISNULL(( SELECT [Tafsili]
                     FROM   [dbo].[tCust]
                     WHERE  [Code] = [dbo].[tFacM].[Customer]
                            AND [Branch] = [dbo].[tFacM].[Branch]
                   ), 0) AS [CustomerTafsili]
                   , ISNULL(t1.Bestankar1 ,0) AS Bestankar1 
                   , ISNULL(t2.Bestankar2 ,0) AS Bestankar2
                   , ISNULL(t3.Bestankar3 ,0) AS Bestankar3
                   , ISNULL(t4.Bestankar4 ,0) AS Bestankar4
                   , ISNULL(t5.Bestankar5 ,0) AS Bestankar5
    FROM    [dbo].[tFacM]
	LEFT OUTER JOIN 
		(Select SUM(IsNull(Bestankar,0)) AS Bestankar1 , intSerialNo , Branch From   tblAcc_Recieved GROUP BY intSerialNo , Branch )t1
			ON  t1.intSerialNo = dbo.tFacM.intSerialNo  and t1.Branch = dbo.tFacM.Branch 	
	LEFT OUTER JOIN 
		(Select SUM(IsNull(intAmount,0)) AS Bestankar2 ,intSerialNo , Branch From   tFacCash GROUP BY intSerialNo , Branch )t2
			ON  t2.intSerialNo = dbo.tFacM.intSerialNo  and t2.Branch = dbo.tFacM.Branch 	
	LEFT OUTER JOIN 
		(Select SUM(IsNull(intAmount,0)) AS Bestankar3 , intSerialNo , Branch From   tFacCard GROUP BY intSerialNo , Branch )t3
			ON  t3.intSerialNo = dbo.tFacM.intSerialNo  and t3.Branch = dbo.tFacM.Branch 	
	LEFT OUTER JOIN 
		(Select SUM(IsNull(intAmount,0)) AS Bestankar4 , intSerialNo , Branch From   dbo.tFacCredit GROUP BY intSerialNo , Branch )t4
			ON  t4.intSerialNo = dbo.tFacM.intSerialNo  and t4.Branch = dbo.tFacM.Branch 	
	LEFT OUTER JOIN 
		(Select SUM(IsNull(intchequeamount,0)) AS Bestankar5 ,intSerialNo , Branch From   tFacCheque GROUP BY intSerialNo , Branch )t5
			ON  t5.intSerialNo = dbo.tFacM.intSerialNo  and t5.Branch = dbo.tFacM.Branch 	

    WHERE   [Recursive] = 0
            AND [Status] = 2
            --AND [dbo].[tFacM].[Customer] > 0
            AND [dbo].[tFacM].[transferAccounting] = 0
            AND [dbo].[tFacM].[Branch] =@Branch
            AND [dbo].[tFacM].[Date] >= @DateBefore
            AND [dbo].[tFacM].[Date] <= @DateAfter
            --AND [dbo].[tFacM].[Balance] = 0
			--AND [dbo].[tFacM].[Facpayment] = 1
			and (Facpayment = 1 or Incharge is null)
			and tfacm.SumPrice > (ISNULL(t1.Bestankar1 ,0) + ISNULL(t2.Bestankar2 ,0) 
							   + ISNULL(t3.Bestankar3 ,0) + ISNULL(t4.Bestankar4 ,0) 
							   + ISNULL(t5.Bestankar5 ,0) )
)T

GROUP BY Customer , CustomerName , CustomerTafsili ,Date
GO 



--������ ���� �� ��� �� ���� ������� ��� ��� ���

ALTER VIEW [dbo].[VwStationSaleSummery]
AS 
    SELECT  dbo.tFacM.[No] ,
            dbo.tFacM.[Date] ,
            dbo.tFacM.[Time] ,
            dbo.tFacM.[User] ,
            SumPrice ,
            CarryFeeTotal ,
            DiscountTotal ,
            StationID ,
            ServiceTotal ,
            PackingTotal ,
            TaxTotal ,
            DutyTotal ,
	        dbo.tfacm.[RoundDiscount],
            FacPayment ,
            Balance ,
            dbo.tfacm.Customer ,
            CASE dbo.tCust.[Name] + SPACE(3) + dbo.tCust.family
              WHEN NULL THEN dbo.tCust.WorkName
              WHEN '' THEN dbo.tCust.WorkName
              ELSE dbo.tCust.[Name] + '  ' + dbo.tCust.family
            END AS CustomerName ,
            dbo.tCust.tafsili AS CustomerTafsili ,
            dbo.tPer.nvcFirstName + ' ' + dbo.tPer.nvcSurName AS UserFullName ,
            dbo.tPer.tafsili AS PersonTafsili ,
            CASE dbo.tPer.Gender
              WHEN 1 THEN N'����'
              WHEN 0 THEN N'����'
            END AS UserGender ,
            CASE ISNULL(Incharge, 0)
              WHEN 0 THEN 0
              ELSE CASE ISNULL(TableNo, 0)
                     WHEN 0 THEN SumPrice
                     ELSE 0
                   END
            END AS CarrierSumPrice ,
            CASE ISNULL(Incharge, 0)
              WHEN 0 THEN 0
              ELSE CASE ISNULL(TableNo, 0)
                     WHEN 0 THEN 0
                     ELSE SumPrice
                   END
            END AS GarsonSumPrice ,
            CASE FacPayment
              WHEN 0 THEN CASE Balance
                            WHEN 0 THEN CASE ISNULL(Incharge, 0)
                                          WHEN 0 THEN 0
                                          ELSE CASE ISNULL(TableNo, 0)
                                                 WHEN 0 THEN SumPrice
                                                 ELSE 0
                                               END
                                        END
                            ELSE 0
                          END
              ELSE 0
            END AS CarrierDebit ,
            CASE FacPayment
              WHEN 0 THEN CASE ISNULL(Incharge, 0)
                            WHEN 0 THEN 0
                            ELSE CASE ISNULL(TableNo, 0)
                                   WHEN 0 THEN 0
                                   ELSE SumPrice
                                 END
                          END
              ELSE 0
            END AS GarsonDebit ,
--            CASE Balance
--              WHEN 0 THEN CASE FacPayment
--                            WHEN 0 THEN 0
--                            ELSE SumPrice
--                          END
--              ELSE 0
--            END AS CustomerDebit ,
			SumPrice - (ISNULL(Resived.Received , 0) +ISNULL(ChequeReceived.ChequeReceived , 0)+ISNULL(CardReceived.CardReceived , 0)+ISNULL(BonReceived.BonReceived , 0)+ISNULL(PreReceived2.PreReceived2 , 0))
			AS CustomerDebit ,
            CASE Balance
              WHEN 0 THEN CASE FacPayment
                            WHEN 0 THEN CASE ISNULL(Incharge, 0)
                                          WHEN 0 THEN SumPrice
                                          ELSE 0
                                        END
                            ELSE 0
                          END
              ELSE 0
            END AS UnBalanceFich ,
            dbo.tFacM.Branch ,
            0 AS Payment ,
            ISNULL(Resived.Received , 0) AS Recieved ,
            tper.ppno ,
            tfacm.status ,
            tblAcc_Recieved.bestankar AS preRecieved ,
            ISNULL(ChequeReceived.ChequeReceived ,0) AS ChequeRecieved ,
            ISNULL(CardReceived.CardReceived , 0) AS CardReceived ,
            ISNULL(BonReceived.BonReceived , 0) AS BonReceived ,
            ISnull(tFactorAdditionalServices.amount , 0)  AS TipAmount ,
			0 AS ManualRecieved ,
			ISNULL(PreReceived.PreReceived , 0) AS TablePreReceived
			, 0 AS OrderPrice 
			, 0 AS OrderReceived 
    FROM    dbo.tFacM
            INNER JOIN dbo.tUser ON dbo.tFacM.[User] = dbo.tUser.UID
                                    AND dbo.tFacM.[Branch] = dbo.tUser.Branch
            INNER JOIN dbo.tPer ON tUser.ppno = tPer.ppno
                                   AND tUser.Branch = tPer.Branch
            INNER JOIN tCUst ON tfacM.Customer = tcust.code
                                AND dbo.tfacm.[Branch] = dbo.[tCust].[Branch]
            LEFT OUTER JOIN [tblAcc_Recieved] ON tfacm.[OrderRefrence] = [tblAcc_Recieved].[intSerialNo] 
            LEFT OUTER JOIN [tFactorAdditionalServices] ON [tFactorAdditionalServices].[Branch] = [tFacM].[Branch] AND [tFactorAdditionalServices].[intSerialNo] = [tFacM].[intSerialNo]
		AND tFactorAdditionalServices.intServiceNo = 3
	    LEFT outer JOIN (SELECT ISNULL(SUM(intAmount),0) AS Received,intSerialNo , Branch FROM  [dbo].[tFacCash] 
			GROUP BY intSerialNo , Branch) AS Resived ON Resived.Branch = tfacm.Branch AND  Resived.intSerialNo = dbo.tFacM.intSerialNo
	    LEFT outer JOIN (SELECT ISNULL(SUM(intAmount),0) AS CardReceived,intSerialNo , Branch FROM  [dbo].[tFacCard] 
			GROUP BY intSerialNo , Branch) AS CardReceived ON CardReceived.Branch = tfacm.Branch AND  CardReceived.intSerialNo = dbo.tFacM.intSerialNo
	    LEFT outer JOIN (SELECT ISNULL(SUM(intAmount),0) AS BonReceived,intSerialNo , Branch FROM  [dbo].[tFacCredit] 
			GROUP BY intSerialNo , Branch) AS BonReceived ON BonReceived.Branch = tfacm.Branch AND  BonReceived.intSerialNo = dbo.tFacM.intSerialNo
	    LEFT outer JOIN (SELECT ISNULL(SUM(intChequeAmount),0) AS ChequeReceived,intSerialNo , Branch FROM  [dbo].[tFacCheque] 
			GROUP BY intSerialNo , Branch) AS ChequeReceived ON ChequeReceived.Branch = tfacm.Branch AND  ChequeReceived.intSerialNo = dbo.tFacM.intSerialNo
	    LEFT outer JOIN (SELECT ISNULL(SUM(Bestankar),0) AS PreReceived ,intSerialNo , Branch FROM  [dbo].[tblAcc_Recieved] 
			GROUP BY intSerialNo , Branch) AS PreReceived ON PreReceived.Branch = tfacm.Branch AND  PreReceived.intSerialNo = dbo.tFacM.intSerialNo AND dbo.tFacM.ServePlace = 16
	    LEFT outer JOIN (SELECT ISNULL(SUM(Bestankar),0) AS PreReceived2 ,intSerialNo , Branch FROM  [dbo].[tblAcc_Recieved] 
			GROUP BY intSerialNo , Branch) AS PreReceived2 ON PreReceived.Branch = tfacm.Branch AND  PreReceived.intSerialNo = dbo.tFacM.intSerialNo

    WHERE   ( Recursive = 0  AND Status = 2 )

    UNION
    SELECT  dbo.tFacM.[No] ,
            dbo.tFacM.[Date] ,
            dbo.tFacM.[Time] ,
            dbo.tFacM.[User] ,
            0 AS SumPrice ,
            0 AS CarryFeeTotal ,
            0 AS DiscountTotal ,
            StationID ,
            0 AS ServiceTotal ,
            0 AS PackingTotal ,
            0 AS TaxTotal ,
            0 AS DutyTotal ,
	        0 AS [RoundDiscount],
            0 AS FacPayment ,
            0 AS Balance ,
            NULL AS Customer ,
            NULL AS CustomerName ,
            NULL AS CustomerTafsili ,
            NULL AS UserFullName ,
            NULL AS PersonTafsili ,
            NULL AS UserGender ,
            0 AS CarrierSumPrice ,
            0 AS GarsonSumPrice ,
            0 AS CarrierDebit ,
            0 AS GarsonDebit ,
            0 AS CustomerDebit ,
            0 AS UnbalaceFich ,
            Branch AS Branch ,
            0 AS Payment ,
            0 AS Recieved ,
            NULL AS ppno ,
            2 AS status ,
            0 AS preRecieved ,
            0 AS ChequeRecieved ,
	    0 AS CardReceived ,
	    0 AS BonReceived ,
	    0 AS TipAmount ,
	    0 AS ManualRecieved ,
	    0 AS TablePreReceived ,
	    SumPrice AS OrderPrice ,
	    0 AS OrderReceived
    FROM    dbo.tFacM WHERE Recursive = 0 AND Status = 10
    UNION
    SELECT  list AS [No] ,
            [Date] AS [Date] ,
            RegTime AS [Time] ,
            UID AS [User] ,
            0 AS SumPrice ,
            0 AS CarryFeeTotal ,
            0 AS DiscountTotal ,
            1 AS StationID ,
            0 AS ServiceTotal ,
            0 AS PackingTotal ,
            0 AS TaxTotal ,
            0 AS DutyTotal ,
            0 AS RoundDiscount ,
            0 AS FacPayment ,
            0 AS Balance ,
            NULL AS Customer ,
            NULL AS CustomerName ,
            NULL AS CustomerTafsili ,
            NULL AS UserFullName ,
            NULL AS PersonTafsili ,
            NULL AS UserGender ,
            0 AS CarrierSumPrice ,
            0 AS GarsonSumPrice ,
            0 AS CarrierDebit ,
            0 AS GarsonDebit ,
            0 AS CustomerDebit ,
            0 AS UnbalaceFich ,
            Branch AS Branch ,
            Bestankar AS Payment ,
            0 AS Recieved ,
            NULL AS ppno ,
            2 AS status ,
            0 AS preRecieved ,
            0 AS ChequeRecieved ,
	    0 AS CardReceived ,
	    0 AS BonReceived ,
	    0 AS TipAmount ,
	    0 AS ManualRecieved ,
	    0 AS TablePreReceived ,
	    0 AS OrderPrice ,
	    0 AS OrderReceived
    FROM    tblAcc_Cash
    UNION
    SELECT  list AS [No] ,
            tblAcc_Recieved.[Date] AS [Date] ,
            RegTime AS [Time] ,
            UID AS [User] ,
            0 AS SumPrice ,
            0 AS CarryFeeTotal ,
            0 AS DiscountTotal ,
            1 AS StationID ,
            0 AS ServiceTotal ,
            0 AS PackingTotal ,
            0 AS TaxTotal ,
            0 AS DutyTotal ,
            0 AS RoundDiscount ,
            0 AS FacPayment ,
            0 AS Balance ,
            NULL AS Customer ,
            NULL AS CustomerName ,
            NULL AS CustomerTafsili ,
            NULL AS UserFullName ,
            NULL AS PersonTafsili ,
            NULL AS UserGender ,
            0 AS CarrierSumPrice ,
            0 AS GarsonSumPrice ,
            0 AS CarrierDebit ,
            0 AS GarsonDebit ,
            0 AS CustomerDebit ,
            0 AS UnbalaceFich ,
            tblAcc_Recieved.Branch AS Branch ,
            0 AS Payment ,
            Bestankar AS Recieved ,
            NULL AS ppno ,
            2 AS status ,
            0 AS preRecieved ,
            0 AS ChequeRecieved ,
	    0 AS CardReceived ,
	    0 AS BonReceived ,
	    0 AS TipAmount ,
	    0 AS ManualRecieved ,
	    0 AS TablePreReceived ,
	    0 AS OrderPrice ,
  	    0 AS OrderReceived

    FROM    tblAcc_Recieved 
    INNER JOIN dbo.tFacM ON dbo.tblAcc_Recieved.Branch = dbo.tFacM.Branch AND dbo.tblAcc_Recieved.intSerialNo = dbo.tFacM.intSerialNo
    WHERE tblAcc_Recieved.intSerialNo IS NOT NULL AND Status = 2
    UNION
    SELECT  list AS [No] ,
            tblAcc_Recieved.[Date] AS [Date] ,
            RegTime AS [Time] ,
            UID AS [User] ,
            0 AS SumPrice ,
            0 AS CarryFeeTotal ,
            0 AS DiscountTotal ,
            1 AS StationID ,
            0 AS ServiceTotal ,
            0 AS PackingTotal ,
            0 AS TaxTotal ,
            0 AS DutyTotal ,
            0 AS RoundDiscount ,
            0 AS FacPayment ,
            0 AS Balance ,
            NULL AS Customer ,
            NULL AS CustomerName ,
            NULL AS CustomerTafsili ,
            NULL AS UserFullName ,
            NULL AS PersonTafsili ,
            NULL AS UserGender ,
            0 AS CarrierSumPrice ,
            0 AS GarsonSumPrice ,
            0 AS CarrierDebit ,
            0 AS GarsonDebit ,
            0 AS CustomerDebit ,
            0 AS UnbalaceFich ,
            tblAcc_Recieved.Branch AS Branch ,
            0 AS Payment ,
            0 AS Recieved ,
            NULL AS ppno ,
            2 AS status ,
            0 AS preRecieved ,
            0 AS ChequeRecieved ,
	    0 AS BonReceived ,
	    0 AS CardReceived ,
	    0 AS TipAmount ,
	    0 AS ManualRecieved ,
	    0 AS TablePreReceived ,
	    0 AS OrderPrice ,
  	    Bestankar AS OrderReceived

    FROM    tblAcc_Recieved 
    INNER JOIN dbo.tFacM ON dbo.tblAcc_Recieved.Branch = dbo.tFacM.Branch AND dbo.tblAcc_Recieved.intSerialNo = dbo.tFacM.intSerialNo
    WHERE tblAcc_Recieved.intSerialNo IS NOT NULL AND Status = 10
    UNION
    SELECT  list AS [No] ,
            [Date] AS [Date] ,
            RegTime AS [Time] ,
            UID AS [User] ,
            0 AS SumPrice ,
            0 AS CarryFeeTotal ,
            0 AS DiscountTotal ,
            1 AS StationID ,
            0 AS ServiceTotal ,
            0 AS PackingTotal ,
            0 AS TaxTotal ,
            0 AS DutyTotal ,
            0 AS RoundDiscount ,
            0 AS FacPayment ,
            0 AS Balance ,
            NULL AS Customer ,
            NULL AS CustomerName ,
            NULL AS CustomerTafsili ,
            NULL AS UserFullName ,
            NULL AS PersonTafsili ,
            NULL AS UserGender ,
            0 AS CarrierSumPrice ,
            0 AS GarsonSumPrice ,
            0 AS CarrierDebit ,
            0 AS GarsonDebit ,
            0 AS CustomerDebit ,
            0 AS UnbalaceFich ,
            Branch AS Branch ,
            0 AS Payment ,
            0 AS Recieved ,
            NULL AS ppno ,
            2 AS status ,
            0 AS preRecieved ,
            0 AS ChequeRecieved ,
	    0 AS CardReceived ,
	    0 AS BonReceived ,
	    0 AS TipAmount ,
	    Bestankar AS ManualRecieved ,
	    0 AS TablePreReceived ,
	    0 AS OrderPrice ,
	    0 AS OrderReceived
    FROM    tblAcc_Recieved WHERE intSerialNo IS NULL 
    UNION
    SELECT  [No] ,
            [RegDate] AS [Date] ,
            RegTime AS [Time] ,
            UID AS [User] ,
            0 AS SumPrice ,
            0 AS CarryFeeTotal ,
            0 AS DiscountTotal ,
            1 AS StationID ,
            0 AS ServiceTotal ,
            0 AS PackingTotal ,
            0 AS TaxTotal ,
            0 AS DutyTotal ,
            0 AS RoundDiscount ,
            0 AS FacPayment ,
            0 AS Balance ,
            NULL AS Customer ,
            NULL AS CustomerName ,
            NULL AS CustomerTafsili ,
            NULL AS UserFullName ,
            NULL AS PersonTafsili ,
            NULL AS UserGender ,
            0 AS CarrierSumPrice ,
            0 AS GarsonSumPrice ,
            0 AS CarrierDebit ,
            0 AS GarsonDebit ,
            0 AS CustomerDebit ,
            0 AS UnbalaceFich ,
            Branch AS Branch ,
            0 AS Payment ,
            0 AS Recieved ,
            NULL AS ppno ,
            2 AS status ,
            0 AS preRecieved ,
            intChequeAmount AS ChequeRecieved ,
	    0 AS CardReceived ,
	    0 AS BonReceived ,
	    0 AS TipAmount ,
	    0 AS ManualRecieved ,
	    0 AS TablePreReceived ,
	    0 AS OrderPrice ,
	    0 AS OrderReceived
    FROM    tblAcc_Recieved_Cheque
--===============================================





GO






