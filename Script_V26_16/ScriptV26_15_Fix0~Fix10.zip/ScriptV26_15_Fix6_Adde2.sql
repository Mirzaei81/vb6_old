
--ScriptV26_15_Fix6_Adde2

--  15 ���� ��� ������� ���� � ������ ������� ��� � ���� ��  �ю�
-- ���� ���� ����� RepSaleSummaryInfo.rpt 
--�� ���� ������ ���� ���

--��� ��� ��� ���� � ����� �� ������ ���� �� ��� � ������� ���� �� ������
--������� ����� ���� ��� ��� � ������ ���� �� ���� ���� �� ���� 
--- ��� ��� �ю� ��� �������� ������ ����
--

ALTER  Proc Get_No_KeyBoard_Defined_Good (@StationId int)

as
DECLARE @Branch INT 
SET @Branch = (SELECT TOP 1 Branch FROM dbo.tStations WHERE StationID = @StationId )

select * from vw_Good_Levels 

--  Inner Join tInventory_Level1 On tInventory_Level1.Level1 = vw_Good_Levels.Level1 
--  Inner Join tInventory On tInventory_Level1.Branch = tInventory.Branch And  tInventory_Level1.InventoryNo = tInventory.InventoryNo
--  Inner Join tStation_Inventory_Good On tStation_Inventory_Good.InventoryNo = tInventory.InventoryNo 
--	And tStation_Inventory_Good.StationId = @StationId And tStation_Inventory_Good.Branch = @Branch
--	And tStation_Inventory_Good.GoodCode = vw_Good_Levels.Code
--	And tStation_Inventory_Good.AccountYear = dbo.Get_AccountYear()

  
   where vw_Good_Levels.Code not in (select distinct goodcode from tGood_KB where StationId = @StationId and Branch =  @Branch)
	AND vw_Good_Levels.GoodType <> 4





GO



ALTER   PROCEDURE [DBO].[Get_Good_Level](@FactorType int , @StationId int , @intLanguage int , @NotSuportedGoodType int  ) AS


DECLARE @Branch INT 
SET @Branch = (SELECT TOP 1 Branch FROM dbo.tStations WHERE StationID = @StationId )

SELECT     vw_Good_Levels.Code, vw_Good_Levels.Level1, vw_Good_Levels.Level2 , GoodType,  
		case @intLanguage when 0 then Name
			when 1 then LatinName
			end as Name ,
		case @intLanguage when 0 then DesLevel1
			when 1 then LatinDesLevel1
			end as DesLevel1 ,
		case @intLanguage when 0 then DesLevel2
			when 1 then LatinDesLevel2
			end as DesLevel2 

FROM         dbo.vw_Good_Levels 
--   Inner Join tInventory_Level1 On tInventory_Level1.Level1 = vw_Good_Levels.Level1 
--   Inner Join tInventory On tInventory_Level1.Branch = tInventory.Branch And  tInventory_Level1.InventoryNo = tInventory.InventoryNo
--   Inner Join tStation_Inventory_Good On tStation_Inventory_Good.InventoryNo = tInventory.InventoryNo 
--	And tStation_Inventory_Good.StationId = @StationId 
--	And tStation_Inventory_Good.Branch = @Branch
--	And tStation_Inventory_Good.AccountYear = dbo.Get_AccountYear()
--	And tStation_Inventory_Good.GoodCode = vw_Good_Levels.Code


where GoodType <> @NotSuportedGoodType   
and vw_Good_Levels.Code not in (select distinct Goodcode from tGood_Menu where FactorType = @FactorType And StationId = @StationId  And Branch =  @Branch )
AND vw_Good_Levels.GoodType <> 4





GO



ALTER   PROCEDURE [dbo].[GetAllCustomerBuy]
    (
      @SystemDate NVARCHAR(50),
      @SystemDay NVARCHAR(50),
      @SystemTime NVARCHAR(50),
      @Date1 NVARCHAR(10),
      @Date2 NVARCHAR(10),
      @User1 INT,
      @User2 INT,
      @Station1 INT,
      @Station2 INT ,
      @Time1 NVARCHAR(5),
      @Time2 NVARCHAR(5),
      @Branch1 INT ,
      @Branch2 INT   
    )
AS 
    DECLARE @tmp1 INT  
    DECLARE @tmp2 NVARCHAR(50)  
    DECLARE @Time3 NVARCHAR(50)  
    DECLARE @Time4 NVARCHAR(50)  
    SET @Time3 = @Time1  
    SET @Time4 = @time2  
  
    IF @User2 < @User1 
        BEGIN   
            SET @tmp1 = @User2  
            SET @User2 = @User1  
            SET @User1 = @tmp1   
        END   
  
    IF @Time2 < @Time1 
        BEGIN  
  /*SET @tmp2 = @Time2  
  SET @Time2 = @Time1  
  SET @Time1 = @tmp2*/  
            SET @Time3 = '00:00'  
            SET @Time4 = '24:00'  
        END  

    DECLARE @TimeTitle NVARCHAR(10)
        SET @TimeTitle = N' ���� : '

DECLARE @BranchName1 NVARCHAR(20)
DECLARE @BranchName2 NVARCHAR(20)
SELECT @BranchName1 = nvcBranchName FROM dbo.tBranch WHERE dbo.tBranch.Branch = @Branch1
SELECT @BranchName2 = nvcBranchName FROM dbo.tBranch WHERE dbo.tBranch.Branch = @Branch2

SELECT 
	  @SystemDay + ' ' + @SystemDate + @TimeTitle + @SystemTime AS Sysdate ,
	  T1.Customer , SUM(T1.Foroosh) AS Foroosh , 
		SUM(T1.Daryaft) AS Daryaft , (dbo.tCust.[Name] + N' '+ dbo.tCust.Family + dbo.tCust.WorkName) AS CustName
		, dbo.tBranch.nvcBranchName, dbo.tCust.MembershipID , @BranchName1 AS BranchName1 , @BranchName2 AS BranchName2 , T1.Branch
 FROM 
 (
     SELECT Customer , SUM(SumPrice) AS Foroosh , 0 AS Daryaft , tfacm.Branch
          FROM      tfacm
          WHERE     [date ] >= @Date1
                AND [date] <= @Date2
                AND Status = 2
                AND ( ( [Time] >= @Time1
                        AND [Time] <= @Time4
                      )
                      OR ( [Time] <= @Time2
                           AND [Time] >= @Time3
                         )
                    )
                AND StationID >= @station1
                AND StationID <= @station2
                AND Recursive = 0
                AND Branch >= @Branch1
                AND Branch <= @Branch2
                AND [User] >= @User1 AND [User] <= @User2
                --AND Customer > 0 --AND Balance =0 AND FacPayment = 1
                GROUP BY tfacm.Customer , tfacm.Branch

UNION ALL  

SELECT Customer , 0 AS Foroosh , ISNULL(SUM(tFacCash.intAmount), 0) + ISNULL(SUM(tblAcc_Recieved.Bestankar), 0)   AS Daryaft  , tfacm.Branch
	FROM  dbo.tFacM
	LEFT OUTER JOIN dbo.tFacCash ON dbo.tFacCash.Branch = dbo.tFacM.Branch AND dbo.tFacCash.intSerialNo = dbo.tFacM.intSerialNo
	LEFT OUTER JOIN dbo.tblAcc_Recieved ON dbo.tblAcc_Recieved.Branch = dbo.tFacM.Branch AND dbo.tblAcc_Recieved.intSerialNo = dbo.tFacM.intSerialNo
          WHERE     tfacm.[date ] >= @Date1
                AND tfacm.[date] <= @Date2
                AND Status = 2
                AND ( ( [Time] >= @Time1
                        AND [Time] <= @Time4
                      )
                      OR ( [Time] <= @Time2
                           AND [Time] >= @Time3
                         )
                    )
                AND StationID >= @station1
                AND StationID <= @station2
                AND Recursive = 0
                AND tfacm.Branch >= @Branch1
                AND tfacm.Branch <= @Branch2
                AND [User] >= @User1 AND [User] <= @User2
                --AND Customer > 0 --AND Balance =0 AND FacPayment = 1
 GROUP BY Customer , tfacm.Branch

UNION ALL  

SELECT   Code_Bes AS Customer , 0 AS Foroosh , ISNULL(SUM(tblAcc_Recieved.Bestankar) , 0) AS Daryaft , tblAcc_Recieved.Branch
	FROM  dbo.tblAcc_Recieved
          WHERE     tblAcc_Recieved.[date ] >= @Date1
                AND tblAcc_Recieved.[date] <= @Date2
                AND tblAcc_Recieved.Branch >= @Branch1
                AND tblAcc_Recieved.Branch <= @Branch2
                AND tblAcc_Recieved.AddUser >= @User1 AND tblAcc_Recieved.AddUser <= @User2
                --AND tblAcc_Recieved.Code_Bes > 0 
                 AND tblAcc_Recieved.intSerialNo IS NULL 
GROUP BY Code_Bes , tblAcc_Recieved.Branch

)T1	
    INNER JOIN dbo.tCust ON T1.Customer = dbo.tCust.Code --AND  T1.Branch = tcust.Branch
    INNER JOIN dbo.tBranch ON dbo.tBranch.Branch = T1.Branch
	GROUP BY T1.Customer ,T1.Branch , dbo.tCust.[Name] , dbo.tCust.Family , dbo.tCust.WorkName , dbo.tBranch.nvcBranchName , dbo.tCust.MembershipId


GO


ALTER  PROCEDURE [dbo].[GetSaleSummaryInfo]
    (
      @SystemDate NVARCHAR(50) ,
      @SystemDay NVARCHAR(50) ,
      @SystemTime NVARCHAR(50) ,
      @Date1 VARCHAR(10) ,
      @Date2 VARCHAR(10) ,
      @User1 INT ,
      @User2 INT ,
      @station1 INT ,
      @station2 INT ,
      @Time1 NVARCHAR(5) ,
      @Time2 NVARCHAR(5) ,
      @Branch1 INT ,
      @Branch2 INT     

    )
AS 

    DECLARE @tmp1 INT
    DECLARE @tmp2 NVARCHAR(50)
    DECLARE @Time3 NVARCHAR(50)
    DECLARE @Time4 NVARCHAR(50)
    SET @Time3 = @Time1
    SET @Time4 = @tmp2

    DECLARE @ServiceTotal INT
    DECLARE @DiscountTotal INT
    DECLARE @CarryFeeTotal INT
    DECLARE @PackingTotal INT
    DECLARE @TaxTotal INT
    DECLARE @DutyTotal INT
    DECLARE @SumUnbalanceFich INT
    DECLARE @SumPayment INT
    DECLARE @SumManualReceived INT
    DECLARE @SumCashReceived INT
    DECLARE @SumCardReceived INT
    DECLARE @SumBonReceived INT
    DECLARE @SumChequeReceived INT
    DECLARE @SumCustomerDebit INT
    DECLARE @SumGarsonDebit INT
    DECLARE @SumRoundDiscount INT
    DECLARE @SumOrderPrice INT
    DECLARE @SumOrderReceived INT
    DECLARE @SumTotalSale INT 
	DECLARE @SumPaykDebit INT 
	DECLARE @SumAutoReceived INT 
	
DECLARE @BranchName1 NVARCHAR(20)
DECLARE @BranchName2 NVARCHAR(20)
SELECT @BranchName1 = nvcBranchName FROM dbo.tBranch WHERE dbo.tBranch.Branch = @Branch1
SELECT @BranchName2 = nvcBranchName FROM dbo.tBranch WHERE dbo.tBranch.Branch = @Branch2

    IF @User2 < @User1 
        BEGIN 
            SET @tmp1 = @User2
            SET @User2 = @User1
            SET @User1 = @tmp1	
        END	

    IF @Time2 < @Time1 
        BEGIN
		/*SET @tmp2 = @Time2
		SET @Time2 = @Time1
		SET @Time1 = @tmp2*/
            SET @Time3 = '00:00'
            SET @Time4 = '24:00'
        END
	
    SET @ServiceTotal = ( SELECT    SUM(ServiceTotal)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @DiscountTotal = ( SELECT   SUM(DiscountTotal)
                           FROM     tfacm
                           WHERE    [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                         ) 
    SET @CarryFeeTotal = ( SELECT   SUM(CarryFeeTotal)
                           FROM     tfacm
                           WHERE    [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                         ) 
    SET @PackingTotal = ( SELECT    SUM(PackingTotal)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @TaxTotal = ( SELECT    SUM(TaxTotal)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @DutyTotal = ( SELECT    SUM(DutyTotal)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 

   SET @SumUnbalanceFich = ( SELECT    SUM(SumPrice)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                                    AND Balance = 0 AND FacPayment = 0 AND InCharge IS NULL 
                        ) 
    SET @SumPayment = ( SELECT    SUM(Bestankar)
                          FROM      dbo.tblAcc_Cash
                          WHERE     [date] >= @Date1
                                    AND [date] <= @Date2
                                    --AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND UID >= @User1 AND UID <= @User2
                        ) 
    SET @SumManualReceived = ( SELECT    SUM(Bestankar)
                          FROM      dbo.tblAcc_Recieved
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND UID >= @User1 AND UID <= @User2
                                    AND intSerialNo IS NULL 
                        ) 
    SET @SumAutoReceived = ( SELECT    SUM(Bestankar)
                          FROM      dbo.tblAcc_Recieved
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND UID >= @User1 AND UID <= @User2
                                    AND intSerialNo IS NOT NULL 
                        ) 
    SET @SumCashReceived = ( SELECT    SUM(intAmount)
                          FROM      tfacm
                          INNER JOIN tfaccash ON dbo.tFacM.Branch = dbo.tFacCash.Branch AND dbo.tFacM.intSerialNo = dbo.tFacCash.intSerialNo
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND tfacm.Branch >= @Branch1
                                    AND tfacm.Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @SumCardReceived = ( SELECT    SUM(intAmount)
                          FROM      tfacm
                          INNER JOIN dbo.tFacCard ON dbo.tFacM.Branch = dbo.tFacCard.Branch AND dbo.tFacM.intSerialNo = dbo.tFacCard.intSerialNo
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND tfacm.Branch >= @Branch1
                                    AND tfacm.Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @SumBonReceived = ( SELECT    SUM(intAmount)
                          FROM      tfacm
                          INNER JOIN dbo.tFacCredit ON dbo.tFacM.Branch = dbo.tFacCredit.Branch AND dbo.tFacM.intSerialNo = dbo.tFacCredit.intSerialNo
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND tfacm.Branch >= @Branch1
                                    AND tfacm.Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @SumChequeReceived = ( SELECT    SUM(intChequeAmount)
                          FROM      tfacm
                          INNER JOIN dbo.tFacCheque ON dbo.tFacM.Branch = dbo.tFacCheque.Branch AND dbo.tFacM.intSerialNo = dbo.tFacCheque.intSerialNo
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND tfacm.Branch >= @Branch1
                                    AND tfacm.Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @SumCustomerDebit = ( SELECT    SUM(SumPrice)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                                    AND Customer > 0 AND Balance =0 AND FacPayment = 1
                        ) 
   SET @SumGarsonDebit = ( SELECT    SUM(SumPrice)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                                    AND incharge IS NOT NULL  AND Balance =0 AND FacPayment = 0 AND tfacm.TableNo IS NOT NULL 
                        ) 

   SET @SumPaykDebit = ( SELECT    SUM(SumPrice)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                                    AND incharge IS NOT NULL  AND Balance =0 AND FacPayment = 0 AND tfacm.TableNo IS NULL 
                        ) 

    SET @SumRoundDiscount = ( SELECT    SUM(RoundDiscount)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @SumOrderPrice = ( SELECT    SUM(SumPrice)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 10
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @SumOrderReceived = ( SELECT    SUM(Bestankar)
                          FROM      tblAcc_Recieved

			  			  INNER JOIN dbo.tFacm ON dbo.tblAcc_Recieved.Branch = dbo.tFacM.Branch AND dbo.tblAcc_Recieved.intSerialNo = dbo.tFacM.intSerialNo
                          WHERE     tfacm.[date ] >= @Date1
                                    AND tfacm.[date] <= @Date2
                                    AND Status = 10
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND tfacm.Branch >= @Branch1
                                    AND tfacm.Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                                    AND dbo.tblAcc_Recieved.intSerialNo IS NOT NULL 
                        ) 


   SET @SumTotalSale = ( SELECT    SUM(SumPrice)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 

    DECLARE @TimeTitle NVARCHAR(10)
        SET @TimeTitle = N' ���� : '

SELECT 
	@Date1 AS DateBefore ,
	@Date2 AS DateAfter ,
	@User1 AS FromUser ,
	@User2 AS ToUser ,
	@Time1 AS FromTime ,
	@Time2 AS ToTime ,
	@SystemDay + ' ' + @SystemDate + @TimeTitle + @SystemTime AS Sysdate ,
	@ServiceTotal AS ServiceTotal ,
	@DiscountTotal AS DiscountTotal ,
	@CarryFeeTotal AS CarryFeeTotal ,
	@PackingTotal AS PackingTotal ,
	@taxTotal AS TaxTotal , 
	@DutyTotal AS DutyTotal ,
	ISNULL(@SumUnbalanceFich , 0) AS SumUnbalanceFich,
	ISNULL(@SumPayment, 0)  AS SumPayment,
	ISNULL(@SumManualReceived, 0)  AS SumManualReceived,
	ISNULL(@SumCashReceived, 0)  AS SumCashReceived,
	ISNULL(@SumCardReceived, 0)  AS SumCardReceived,
	ISNULL(@SumBonReceived, 0)  AS SumBonReceived ,
	ISNULL(@SumChequeReceived , 0) AS SumChequeReceived,
	ISNULL(@SumCustomerDebit, 0)  AS SumCustomerDebit,
	ISNULL(@SumGarsonDebit , 0) AS SumGarsonDebit,
	ISNULL(@SumRoundDiscount, 0)  AS SumRoundDiscount,
	ISNULL(@SumOrderPrice , 0) AS SumOrderPrice,
	ISNULL(@SumOrderReceived, 0)  AS SumOrderReceived ,
	ISNULL(@SumTotalSale, 0)  AS SumTotalSale ,
	@BranchName1 AS BranchName1 , @BranchName2 AS Branchname2 ,
	ISNULL(@SumPaykDebit, 0)  AS SumPaykDebit ,
	ISNULL(@SumAutoReceived, 0)  AS SumAutoReceived
     


GO


ALTER   PROCEDURE [dbo].[Get_CustomerBuy]
    (
      @SystemDate NVARCHAR(50),
      @SystemDay NVARCHAR(50),
      @SystemTime NVARCHAR(50),
      @Date1 NVARCHAR(10),
      @Date2 NVARCHAR(10),
      @Cust1 INT,
      @Cust2 INT,
      @Branch1 INT ,
      @Branch2 INT   
    )
AS 

DECLARE @TimeTitle NVARCHAR(10)
    SET @TimeTitle = N' ���� : '
DECLARE @BranchName1 NVARCHAR(20)
DECLARE @BranchName2 NVARCHAR(20)
SELECT @BranchName1 = nvcBranchName FROM dbo.tBranch WHERE dbo.tBranch.Branch = @Branch1
SELECT @BranchName2 = nvcBranchName FROM dbo.tBranch WHERE dbo.tBranch.Branch = @Branch2

SELECT 
	    @SystemDay + ' ' + @SystemDate + @TimeTitle + @SystemTime AS Sysdate ,
	    T1.Date , T1.Customer , 
	    --CASE WHEN SUM(T1.ForooshGhabl) - SUM(T1.DaryaftGhabl) > 0 THEN SUM(T1.ForooshGhabl) - SUM(T1.DaryaftGhabl) 
	    CASE WHEN SUM(T1.ForooshGhabl) > 0 THEN SUM(T1.ForooshGhabl)  
	    ELSE SUM(T1.Foroosh) END  AS Foroosh , 
		--CASE WHEN SUM(T1.ForooshGhabl) - SUM(T1.DaryaftGhabl) < 0 THEN ABS(SUM(T1.ForooshGhabl) - SUM(T1.DaryaftGhabl))
		CASE WHEN SUM(T1.DaryaftGhabl) > 0 THEN  SUM(T1.DaryaftGhabl)
		ELSE SUM(T1.Daryaft) END  AS Daryaft , (dbo.tCust.[Name] + N' '+ dbo.tCust.Family + dbo.tCust.WorkName) AS CustName
		, dbo.tBranch.nvcBranchName,T1.FichNo , SUM(T1.ForooshGhabl) AS ForooshGhabl  , SUM(T1.DaryaftGhabl) AS DaryaftGhabl
		, (SUM(T1.ForooshGhabl) - SUM(T1.DaryaftGhabl)) AS MandeGhabl
		--, (SUM(T1.ForooshGhabl) - SUM(T1.DaryaftGhabl)) + 
		,@BranchName1 AS BranchName1 , @BranchName2 AS Branchname2 , T1.Branch
     FROM 
 (
     SELECT tfacm.[Date] , Customer , SUM(SumPrice) AS Foroosh , 0 AS Daryaft , tfacm.Branch,No as FichNo ,0 AS ForooshGhabl , 0 AS DaryaftGhabl
          FROM      tfacm
          WHERE     [date ] >= @Date1
                AND [date] <= @Date2
                AND Status = 2
                AND Recursive = 0
                AND Branch >= @Branch1
                AND Branch <= @Branch2
                AND Customer >= @Cust1 AND Customer <= @Cust2 
                GROUP BY tfacm.[Date] , tfacm.Customer , tfacm.Branch,No 

UNION ALL  

SELECT tfacm.[Date] , Customer , 0 AS Foroosh , ISNULL(SUM(tFacCash.intAmount), 0) + ISNULL(SUM(tblAcc_Recieved.Bestankar), 0)   AS Daryaft  , tfacm.Branch,tfacm.No as FichNo ,0 AS ForooshGhabl , 0 AS DaryaftGhabl
	FROM  dbo.tFacM
	LEFT OUTER JOIN dbo.tFacCash ON dbo.tFacCash.Branch = dbo.tFacM.Branch AND dbo.tFacCash.intSerialNo = dbo.tFacM.intSerialNo
	LEFT OUTER JOIN dbo.tblAcc_Recieved ON dbo.tblAcc_Recieved.Branch = dbo.tFacM.Branch AND dbo.tblAcc_Recieved.intSerialNo = dbo.tFacM.intSerialNo
          WHERE     tfacm.[date ] >= @Date1
                AND tfacm.[date] <= @Date2
                AND Status = 2
                AND Recursive = 0
                AND tfacm.Branch >= @Branch1
                AND tfacm.Branch <= @Branch2
                AND Customer >= @Cust1 AND Customer <= @Cust2 
 GROUP BY tfacm.[Date] , Customer , tfacm.Branch,tfacm.No

UNION ALL  

SELECT   tblAcc_Recieved.[date]  ,Code_Bes AS Customer , 0 AS Foroosh , ISNULL(SUM(tblAcc_Recieved.Bestankar) , 0) AS Daryaft , tblAcc_Recieved.Branch,tblAcc_Recieved.[No] as FichNo ,0 AS ForooshGhabl , 0 AS DaryaftGhabl
	FROM  dbo.tblAcc_Recieved
          WHERE     tblAcc_Recieved.[date] >= @Date1
                AND tblAcc_Recieved.[date] <= @Date2
                AND tblAcc_Recieved.Branch >= @Branch1
                AND tblAcc_Recieved.Branch <= @Branch2
                AND Code_Bes >= @Cust1 
                AND Code_Bes <= @Cust2 
                AND tblAcc_Recieved.intSerialNo IS NULL 
 GROUP BY tblAcc_Recieved.[date] ,Code_Bes , tblAcc_Recieved.Branch ,tblAcc_Recieved.[No]

UNION ALL

	SELECT N'-' AS date , Customer , 0 AS Foroosh ,0 AS Daryaft , branch , 0 AS fichNo , SUM(Vw_CustomerRemain.Foroosh) AS ForooshGhabl , SUM(Vw_CustomerRemain.Daryaft) AS DaryaftGhabl
	FROM Vw_CustomerRemain
	WHERE 
			Vw_CustomerRemain.Date >= N'70/01/01'
		AND Vw_CustomerRemain.Date < @Date1
		AND Vw_CustomerRemain.Customer >= @Cust1 
		AND Vw_CustomerRemain.Customer <= @Cust2 
		AND Vw_CustomerRemain.Branch >= @Branch1 
		AND Vw_CustomerRemain.Branch <= @Branch2 
	GROUP BY Customer , branch

)T1	
    INNER JOIN dbo.tCust ON T1.Customer = dbo.tCust.Code --AND  T1.Branch = tcust.Branch
    INNER JOIN dbo.tBranch ON dbo.tBranch.Branch = T1.Branch
	GROUP BY T1.Date , T1.Customer ,T1.Branch , dbo.tCust.[Name] , dbo.tCust.Family , dbo.tCust.WorkName , dbo.tBranch.nvcBranchName,T1.FichNo
	ORDER BY T1.Customer

GO

