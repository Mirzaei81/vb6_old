

--Script_V26_15_Fix4

--����� ���� �ѐ�� �� ���� ��� 
--����� ����� ���� ����� ������ � ������ ������ �� ������� ����� �� ����  �� �� ��� ��� ��
-- ����� ��� ���� ���� �� ���� �����
--����� ���� ���� �������� �� ������� ������ ��� ���� ���� �� � ������ ������� ��� ��� � �� ������� ����� ���� ����� ����
--����� ���� ��� ����� ���  ���� ������ ���� �� ���
--91/11/09

INSERT  INTO dbo.tblPub_Script2
        ( Version ,
          Script ,
          LastScriptNo ,
          [Date] ,
          FixNumber
        )
VALUES  ( 26 ,
          15 ,
          0 ,
          dbo.shamsi(GETDATE()) ,
          4
        )
GO



ALTER    Proc Get_vw_NotPaidFactors_By_Job (@Job int , @AccountYear Smallint)  
as  
 Select vw_NotPaidFactors.intSerialNo,vw_NotPaidFactors.No,vw_NotPaidFactors.Status,  
        vw_NotPaidFactors.Owner,vw_NotPaidFactors.Customer,vw_NotPaidFactors.DiscountTotal,  
        vw_NotPaidFactors.SumPrice,vw_NotPaidFactors.CarryFeeTotal,vw_NotPaidFactors.Recursive,  
        vw_NotPaidFactors.FacPayment,vw_NotPaidFactors.InCharge,vw_NotPaidFactors.OrderType,  
        vw_NotPaidFactors.ServePlace,vw_NotPaidFactors.StationID,vw_NotPaidFactors.ServiceTotal,  
        vw_NotPaidFactors.PackingTotal,vw_NotPaidFactors.BascoleNo,vw_NotPaidFactors.ShiftNo,  
        vw_NotPaidFactors.TableNo,t.Date,t.TIME,vw_NotPaidFactors.RegDate,vw_NotPaidFactors.[USER],  
           vw_NotPaidFactors.Branch,vw_NotPaidFactors.Balance,vw_NotPaidFactors.ServePlaceName,  
        vw_NotPaidFactors.AccountYear,vw_NotPaidFactors.NvcDescription,vw_NotPaidFactors.RefFacM,  
        vw_NotPaidFactors.[Full NAME],vw_NotPaidFactors.nvcFirstName,vw_NotPaidFactors.nvcSurName,  
        vw_NotPaidFactors.Job,vw_NotPaidFactors.Code,vw_NotPaidFactors.Address,vw_NotPaidFactors.Credit,  
        vw_NotPaidFactors.distance,vw_NotPaidFactors.intWarn,vw_NotPaidFactors.RemainMinute,  
        vw_NotPaidFactors.TempAddress,vw_NotPaidFactors.mobile ,  
        vw_NotPaidFactors.GuestNo , vw_NotPaidFactors.TempNo , vw_NotPaidFactors.ShiftDescription
  from vw_NotPaidFactors  
  INNER  JOIN (SELECT MAX(RegDate) AS Date,MAX(RegTime) AS Time,intserialno FROM thistory   
        WHERE ActionCode=4 GROUP BY intserialno) AS t   
		ON [vw_NotPaidFactors].[intSerialNo] = t.[intSerialNo]   
   Where  Balance = 0 And FacPayment = 0 And AccountYear = @AccountYear
			AND vw_NotPaidFactors.InCharge > 0  --Job = @Job And 




GO


--exec Get_vw_NotPaidFactors_By_Job 3, 1391
--GO 
--


-------------------------------------------- 'Recipt ����� ���� ������� ��������'----------------------------------------------------

ALTER   PROCEDURE [dbo].[GetSellKindInfo]
    (
      --@intLanguage INT = 0 ,
      @SystemDate NVARCHAR(50) ,
      @SystemDay NVARCHAR(50) ,
      @SystemTime NVARCHAR(50) ,
      @Date1 VARCHAR(50) ,
      @Date2 VARCHAR(50) ,
      @User1 INT ,
      @User2 INT ,
      @station1 INT ,
      @station2 INT ,
      @Time1 NVARCHAR(50) ,
      @Time2 NVARCHAR(50) ,
      @level11 INT ,
      @level12 INT ,
      @level21 INT ,
      @level22 INT ,
      @Branch1 INT ,
      @Branch2 INT ,     
      @Status1 INT 

    )
AS 

	DECLARE @intLanguage INT
		SET @intLanguage = 0   
    DECLARE @tmp1 INT
    DECLARE @tmp2 NVARCHAR(50)
    DECLARE @ServiceTotal INT
    DECLARE @DiscountTotal INT
    DECLARE @CarryFeeTotal INT
    DECLARE @PackingTotal INT
    DECLARE @TaxTotal INT
    DECLARE @DutyTotal INT
    DECLARE @Time3 NVARCHAR(50)
    DECLARE @Time4 NVARCHAR(50)
    SET @Time3 = @Time1
    SET @Time4 = @tmp2

    DECLARE @SumUnbalanceFich INT
    DECLARE @SumPayment INT
    DECLARE @SumManualReceived INT
    DECLARE @SumCashReceived INT
    DECLARE @SumCardReceived INT
    DECLARE @SumBonReceived INT
    DECLARE @SumChequeReceived INT
    DECLARE @SumCustomerDebit INT
    DECLARE @SumGarsonDebit INT
    DECLARE @SumRoundDiscount INT
    DECLARE @SumOrderPrice INT
    DECLARE @SumOrderReceived INT
	
    IF @User2 < @User1 
        BEGIN 
            SET @tmp1 = @User2
            SET @User2 = @User1
            SET @User1 = @tmp1	
        END	

    IF @Time2 < @Time1 
        BEGIN
		/*SET @tmp2 = @Time2
		SET @Time2 = @Time1
		SET @Time1 = @tmp2*/
            SET @Time3 = '00:00'
            SET @Time4 = '24:00'
        END
	
    SET @ServiceTotal = ( SELECT    SUM(ServiceTotal)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = @status1
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @DiscountTotal = ( SELECT   SUM(DiscountTotal)
                           FROM     tfacm
                           WHERE    [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = @status1
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                         ) 
    SET @CarryFeeTotal = ( SELECT   SUM(CarryFeeTotal)
                           FROM     tfacm
                           WHERE    [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = @status1
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                         ) 
    SET @PackingTotal = ( SELECT    SUM(PackingTotal)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = @Status1
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @TaxTotal = ( SELECT    SUM(TaxTotal)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = @Status1
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @DutyTotal = ( SELECT    SUM(DutyTotal)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = @Status1
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 

   SET @SumUnbalanceFich = ( SELECT    SUM(SumPrice)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                                    AND Balance = 0 AND FacPayment = 0 AND InCharge IS NULL 
                        ) 
    SET @SumPayment = ( SELECT    SUM(Bestankar)
                          FROM      dbo.tblAcc_Cash
                          WHERE     [date] >= @Date1
                                    AND [date] <= @Date2
                                    --AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND UID >= @User1 AND UID <= @User2
                        ) 
    SET @SumManualReceived = ( SELECT    SUM(Bestankar)
                          FROM      dbo.tblAcc_Recieved
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND UID >= @User1 AND UID <= @User2
                                    AND intSerialNo IS NULL 
                        ) 
    SET @SumCashReceived = ( SELECT    SUM(intAmount)
                          FROM      tfacm
                          INNER JOIN tfaccash ON dbo.tFacM.Branch = dbo.tFacCash.Branch AND dbo.tFacM.intSerialNo = dbo.tFacCash.intSerialNo
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND tfacm.Branch >= @Branch1
                                    AND tfacm.Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @SumCardReceived = ( SELECT    SUM(intAmount)
                          FROM      tfacm
                          INNER JOIN dbo.tFacCard ON dbo.tFacM.Branch = dbo.tFacCard.Branch AND dbo.tFacM.intSerialNo = dbo.tFacCard.intSerialNo
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND tfacm.Branch >= @Branch1
                                    AND tfacm.Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @SumBonReceived = ( SELECT    SUM(intAmount)
                          FROM      tfacm
                          INNER JOIN dbo.tFacCredit ON dbo.tFacM.Branch = dbo.tFacCredit.Branch AND dbo.tFacM.intSerialNo = dbo.tFacCredit.intSerialNo
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND tfacm.Branch >= @Branch1
                                    AND tfacm.Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @SumChequeReceived = ( SELECT    SUM(intChequeAmount)
                          FROM      tfacm
                          INNER JOIN dbo.tFacCheque ON dbo.tFacM.Branch = dbo.tFacCheque.Branch AND dbo.tFacM.intSerialNo = dbo.tFacCheque.intSerialNo
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND tfacm.Branch >= @Branch1
                                    AND tfacm.Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @SumCustomerDebit = ( SELECT    SUM(SumPrice)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                                    AND Customer > 0 AND Balance =0 AND FacPayment = 1
                        ) 
   SET @SumGarsonDebit = ( SELECT    SUM(SumPrice)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                                    AND incharge IS NOT NULL  AND Balance =0 AND FacPayment = 0
                        ) 
    SET @SumRoundDiscount = ( SELECT    SUM(RoundDiscount)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 2
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @SumOrderPrice = ( SELECT    SUM(SumPrice)
                          FROM      tfacm
                          WHERE     [date ] >= @Date1
                                    AND [date] <= @Date2
                                    AND Status = 10
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND Branch >= @Branch1
                                    AND Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                        ) 
    SET @SumOrderReceived = ( SELECT    SUM(DutyTotal)
                          FROM      tfacm
			  			  INNER JOIN dbo.tblAcc_Recieved ON dbo.tblAcc_Recieved.Branch = dbo.tFacM.Branch AND dbo.tblAcc_Recieved.intSerialNo = dbo.tFacM.intSerialNo
                          WHERE     tfacm.[date ] >= @Date1
                                    AND tfacm.[date] <= @Date2
                                    AND Status = 10
                                    AND ( ( [Time] >= @Time1
                                            AND [Time] <= @Time4
                                          )
                                          OR ( [Time] <= @Time2
                                               AND [Time] >= @Time3
                                             )
                                        )
                                    AND StationID >= @station1
                                    AND StationID <= @station2
                                    AND Recursive = 0
                                    AND tfacm.Branch >= @Branch1
                                    AND tfacm.Branch <= @Branch2
                                    AND [User] >= @User1 AND [User] <= @User2
                                    AND dbo.tblAcc_Recieved.intSerialNo IS NOT NULL 
                        ) 

    DECLARE @TimeTitle NVARCHAR(10)
    IF @intLanguage = 0 
        SET @TimeTitle = N' ���� : '
    ELSE 
        SET @TimeTitle = N'Time: '

DECLARE @BranchName1 NVARCHAR(20)
DECLARE @BranchName2 NVARCHAR(20)
SELECT @BranchName1 = nvcBranchName FROM dbo.tBranch WHERE dbo.tBranch.Branch = @Branch1
SELECT @BranchName2 = nvcBranchName FROM dbo.tBranch WHERE dbo.tBranch.Branch = @Branch2
    SELECT  SUM(dbo.ViewRepSellKind.Amount) AS SumAmount ,
            dbo.ViewRepSellKind.FeeUnit ,
            dbo.ViewRepSellKind.FeeUnit * SUM(dbo.ViewRepSellKind.Amount) AS PriceTotal ,
            dbo.ViewRepSellKind.Level1Code ,
            dbo.ViewRepSellKind.Level2Code ,
            dbo.ViewRepSellKind.UnitGoodDescription ,
            @Date1 AS DateBefore ,
            @Date2 AS DateAfter ,
            dbo.ViewRepSellKind.GoodCode ,
            dbo.ViewRepSellKind.Barcode ,
            @User1 AS FromUser ,
            @User2 AS ToUser ,
            @Time1 AS FromTime ,
            @Time2 AS ToTime ,
            @SystemDay + ' ' + @SystemDate + @TimeTitle + @SystemTime AS Sysdate ,
            @level11 AS FromGoodCodeLvele1 ,
            @level21 AS FromGoodCodeLvele2 ,
            @level12 AS ToGoodCodeLevel1 ,
            @level22 AS ToGoodCodeLevel2 ,
            CASE @intLanguage
              WHEN 0 THEN dbo.ViewRepSellKind.NamePrn
              WHEN 1 THEN dbo.ViewRepSellKind.LatinNamePrn
            END AS GoodName ,
            CASE @intLanguage
              WHEN 0 THEN dbo.ViewRepSellKind.Level1Desc
              WHEN 1 THEN dbo.ViewRepSellKind.Level1LatinDesc
            END AS Level1Description ,
            CASE @intLanguage
              WHEN 0 THEN dbo.ViewRepSellKind.Level2Desc
              WHEN 1 THEN dbo.ViewRepSellKind.Level2LatinDesc
            END AS Level2Description ,
            dbo.ViewRepSellKind.DiscountRate ,
            SUM(dbo.ViewRepSellKind.Discount) AS SumDiscount ,
            dbo.ViewRepSellKind.Rate ,
            dbo.ViewRepSellKind.nvcBranchName ,
            @ServiceTotal AS ServiceTotal ,
            @DiscountTotal AS DiscountTotal ,
            @CarryFeeTotal AS CarryFeeTotal ,
            @PackingTotal AS PackingTotal ,
            @Status1 AS Status ,
            ViewRepSellKind.AccountYear ,
            ViewRepSellKind.Branch 
          --,dbo.ViewRepSellKind.ServePlace
	    , @taxTotal AS TaxTotal , @DutyTotal AS DutyTotal ,'' AS [serveplacedesc]
    -- @SumUnbalanceFich AS SumUnbalanceFich,
--      @SumPayment AS SumPayment,
--      @SumManualReceived AS SumManualReceived,
--      @SumCashReceived AS SumCashReceived,
--      @SumCardReceived AS SumCardReceived,
--      @SumBonReceived AS SumBonReceived ,
--      @SumChequeReceived AS SumChequeReceived,
--      @SumCustomerDebit AS SumCustomerDebit,
--      @SumGarsonDebit AS SumGarsonDebit,
--      @SumRoundDiscount AS SumRoundDiscount,
--      @SumOrderPrice AS SumOrderPrice,
--      @SumOrderReceived AS SumOrderReceived
		, @BranchName1 AS BranchName1 , @BranchName2 AS BranchName2 , Branch 
     FROM    dbo.ViewRepSellKind
    WHERE   dbo.ViewRepSellKind.[date] >= @Date1
            AND dbo.ViewRepSellKind.[date] <= @Date2
	--AND dbo.ViewRepSellKind.[Supplier] IN (SELECT code FROM tSupplier WHERE code  >= @Sup1 AND code < =@Sup2)
            AND dbo.ViewRepSellKind.[User] >= @User1
                  AND dbo.ViewRepSellKind.[User] <= @User2

            AND ( ( dbo.ViewRepSellKind.[Time] >= @Time1
                    AND dbo.ViewRepSellKind.[Time] <= @Time4
                  )
                  OR ( dbo.ViewRepSellKind.[Time] <= @Time2
                       AND dbo.ViewRepSellKind.[Time] >= @Time3
                     )
                )
            AND dbo.ViewRepSellKind.Status = @Status1
            AND dbo.ViewRepSellKind.StationID >= @station1
            AND dbo.ViewRepSellKind.StationID <= @station2
            AND dbo.ViewRepSellKind.Level1Code >= @level11
            AND dbo.ViewRepSellKind.Level1Code <= @level12
            AND dbo.ViewRepSellKind.Level2Code >= @level21
            AND dbo.ViewRepSellKind.Level2Code <= @level22
            AND dbo.ViewRepSellKind.Branch >= @Branch1
            AND dbo.ViewRepSellKind.Branch <= @Branch2
		--	AND dbo.ViewRepSellKind.Balance = 1
    GROUP BY --dbo.ViewRepSellKind.ServePlace ,
            dbo.ViewRepSellKind.GoodCode ,
            dbo.ViewRepSellKind.UnitGoodDescription ,
            dbo.ViewRepSellKind.FeeUnit ,
            dbo.ViewRepSellKind.Level2LatinDesc ,
            dbo.ViewRepSellKind.Level2Desc ,
            dbo.ViewRepSellKind.Level1LatinDesc ,
            dbo.ViewRepSellKind.Level1Desc ,
            dbo.ViewRepSellKind.NamePrn ,
            dbo.ViewRepSellKind.LatinNamePrn ,
            dbo.ViewRepSellKind.Level1Code ,
            dbo.ViewRepSellKind.Level2Code ,
            dbo.ViewRepSellKind.Barcode ,
            dbo.ViewRepSellKind.DiscountRate ,
            dbo.ViewRepSellKind.Rate ,
            ViewRepSellKind.AccountYear ,
            ViewRepSellKind.Branch ,
            ViewRepSellKind.nvcBranchName
	        --,ViewRepSellKind.[serveplacedesc]
    ORDER BY dbo.ViewRepSellKind.GoodCode





GO


DELETE FROM dbo.tblTotal_ItemReports_Details WHERE intReportId = 17 AND Row = 2
GO 

INSERT INTO dbo.tblTotal_ItemReports_Details (
	intReportId,
	Row,
	FromText,
	toText,
	ParameterName,
	ParameterType,
	parameterLengh,
	ObjectType,
	Quantity,
	MinValue,
	MaxValue,
	ComboQuery,
	ComboFieldCode,
	ComboFieldDescr,
	RighttoLeft
) 
SELECT 
	17,
	Row,
	FromText,
	toText,
	ParameterName,
	ParameterType,
	parameterLengh,
	ObjectType,
	Quantity,
	MinValue,
	MaxValue,
	ComboQuery,
	ComboFieldCode,
	ComboFieldDescr,
	RighttoLeft
	FROM dbo.tblTotal_ItemReports_Details WHERE intReportId = 2 AND Row = 2

GO 



