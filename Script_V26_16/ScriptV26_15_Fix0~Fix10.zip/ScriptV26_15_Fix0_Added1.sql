
--V26_15_Fix0_Added1
--91/03/21

-- ����� ���� ����Ԑ� ����� ������ ����� � �����


INSERT INTO dbo.tDevice (
	DeviceCode,
	DeviceName,
	DeviceLatinName,
	Active,
	DeviceTypeCode,
	BufferSize,
	RThreshold
) VALUES ( 
	/* DeviceCode - int */ 43,
	/* DeviceName - nvarchar(50) */ N'����Ԑ� ������',
	/* DeviceLatinName - nvarchar(50) */ N'Hisense Display',
	/* Active - bit */ 1,
	/* DeviceTypeCode - int */ 5,
	/* BufferSize - int */ 20,
	/* RThreshold - int */ 20 ) 
	
GO 


INSERT INTO dbo.tDevice (
	DeviceCode,
	DeviceName,
	DeviceLatinName,
	Active,
	DeviceTypeCode,
	BufferSize,
	RThreshold
) VALUES ( 
	/* DeviceCode - int */ 44,
	/* DeviceName - nvarchar(50) */ N'����Ԑ� ������ �����',
	/* DeviceLatinName - nvarchar(50) */ N'Hisense Persian Display',
	/* Active - bit */ 1,
	/* DeviceTypeCode - int */ 5,
	/* BufferSize - int */ 20,
	/* RThreshold - int */ 20 ) 


GO 

 
 DECLARE @Table NVARCHAR(4000),  
        @Col NVARCHAR(4000)  
   
 DECLARE Table_Cursor CURSOR   
 FOR  
    --���� ���� ���� ������� ���� ���� ����� ������� ����  
    SELECT a.name, --table  
           b.name --col  
    FROM   sysobjects a,  
           syscolumns b  
    WHERE  a.id = b.id  
           AND a.xtype = 'u' --User table  
           AND (  
                   b.xtype = 99 --ntext  
                   OR b.xtype = 35 -- text  
                   OR b.xtype = 231 --nvarchar  
                   OR b.xtype = 167 --varchar  
                   OR b.xtype = 175 --char  
                   OR b.xtype = 239 --nchar  
               )  
   
 OPEN Table_Cursor FETCH NEXT FROM  Table_Cursor INTO @Table,@Col  
 WHILE (@@FETCH_STATUS = 0)  
 BEGIN  
    EXEC (  
             'update [' + @Table + '] set [' + @Col +  
             ']= REPLACE(REPLACE(CAST([' + @Col +  
             '] as nvarchar(4000)) , NCHAR(1610), NCHAR(1740)),NCHAR(1603),NCHAR(1705)) '  
         )  
     
    FETCH NEXT FROM Table_Cursor INTO @Table,@Col  
 END CLOSE Table_Cursor DEALLOCATE Table_Cursor  
 
 GO 


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Get_ArabicToFarsiString]') and xtype in (N'FN', N'IF', N'TF'))
drop function [dbo].[Get_ArabicToFarsiString]
GO
 
 CREATE  Function Get_ArabicToFarsiString

(
    @nvcMainString NVARCHAR(4000)
)
RETURNS  NVARCHAR(4000)

AS
Begin 
Declare @Result NVARCHAR(4000)
Set @Result = REPLACE(REPLACE( @nvcMainString , NCHAR(1610), NCHAR(1740)),NCHAR(1603),NCHAR(1705))

REturn (@Result)
End

GO 


-----------------------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Get_ArabicToFarsiStringSp]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
drop procedure [dbo].[Get_ArabicToFarsiStringSp]
GO


CREATE  PROC Get_ArabicToFarsiStringSp

(
    @nvcMainString NVARCHAR(4000)
)
as
Begin 
Declare @Result NVARCHAR(4000)
Set @Result = REPLACE(REPLACE( @nvcMainString , NCHAR(1610), NCHAR(1740)),NCHAR(1603),NCHAR(1705))

SELECT @Result AS Result
End

GO 


ALTER   PROCEDURE dbo.InserttGood
(
	@intLanguage	INT,
	@Code		INT,
	@GoodName	NVARCHAR(50),
	@GoodNamePrn	NVARCHAR(50),
	@SellPrice	FLOAT,
	@BuyPrice	FLOAT,
	@Barcode	NVARCHAR(50),
	@Level1		INT,
	@Level2		INT,
	@Model		INT,
	@Supplier	INT,
	@Unit		INT,
	@GoodType	INT,
	@Weight	Float,
	@NumberOfUnit 	INT,
	@SellPrice2 Float,
	@SellPrice3 Float ,
	@MainType Bit ,
	@SellPrice4 Float,
	@SellPrice5 Float,
	@SellPrice6 FLOAT ,
	@CategoryShow INT ,
	@PicturePath NVARCHAR(100) ,
	@nvcDescription NVARCHAR(100) ,
	@Result INT OUT 
	


)

AS
Begin tran

	IF @intLanguage = 0 

		INSERT INTO dbo.tGood (Code,Name,NamePrn,SellPrice,BuyPrice,Barcode,Level1,Level2,Model,ProductCompany,Unit,GoodType,Weight,NumberOfUnit,SellPrice2 ,SellPrice3 , MainType , SellPrice4 ,SellPrice5 ,SellPrice6 , CategoryShow , PicturePath , nvcDescription)
		VALUES (@Code,dbo.Get_ArabicToFarsiString(@GoodName),dbo.Get_ArabicToFarsiString(@GoodNamePrn),@SellPrice,@BuyPrice,@Barcode,@Level1,@Level2,@Model,@Supplier,@Unit,@GoodType,@Weight,@NumberOfUnit, @SellPrice2 , @SellPrice3 , @MainType , @SellPrice4, @SellPrice5, @SellPrice6 , @CategoryShow , @PicturePath , @nvcDescription)

	ELSE IF @intLanguage = 1 

		INSERT INTO dbo.tGood (Code,LatinName,LatinNamePrn,SellPrice,BuyPrice,Barcode,Level1,Level2,Model,ProductCompany,Unit,GoodType,Weight,NumberOfUnit, SellPrice2, SellPrice3 , MainType , SellPrice4 ,SellPrice5 ,SellPrice6 , CategoryShow ,PicturePath ,nvcDescription)
		VALUES (@Code,@GoodName,@GoodNamePrn,@SellPrice,@BuyPrice,@Barcode,@Level1,@Level2,@Model,@Supplier,@Unit,@GoodType,@Weight,@NumberOfUnit , @SellPrice2 , @SellPrice3 , @MainType , @SellPrice4, @SellPrice5, @SellPrice6 ,@CategoryShow ,@PicturePath ,@nvcDescription)

     IF @@ERROR <>0
        GoTo EventHandler

 --         if  @GoodType = 3 
   --          Begin
     --               INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
	--	VALUES (@Code,@Code,1,1)
               --     INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
		--VALUES (@Code,@Code,2,1)
                  --  INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
--	--	VALUES (@Code,@Code,4,1)
              --      INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
	--	VALUES (@Code,@Code,8,1)
             --      INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
	--	VALUES (@Code,@Code,16,1)
         --   End

 update  [dbo].[tGood]  set [name] = latinname where ([Name] is null or [Name] = '' ) And Code = @Code

 update  [dbo].[tGood] set latinname = [name] where ([latinName] is null or latinname = '') And Code = @Code

 update  [dbo].[tGood] set [nameprn]=[latinnameprn] where ([Nameprn] is null or [Nameprn] = '' ) And Code = @Code

 update  [dbo].[tGood] set [latinnameprn] = [nameprn] where ([latinNameprn] is null or latinnameprn = '') And Code = @Code

insert into .dbo.[tInventory_Good](GoodCode,InventoryNo,Branch , AccountYear )
  select @Code,tInventory.InventoryNo,tInventory.Branch , dbo.Get_AccountYear()  from dbo.tInventory 
		inner join tInventory_Level1 On tInventory_Level1.Branch = tInventory.Branch  and tInventory_Level1.InventoryNo  = tInventory.InventoryNo 
	        Where tInventory_Level1.Level1 = @Level1 

     IF @@ERROR <>0
        GoTo EventHandler

Insert into dbo.tStation_Inventory_Good ( branch ,InventoryNo, StationID,  AccountYear , GoodCode , Active)
select tInventory.Branch , tInventory.InventoryNo,  t.stationid , dbo.Get_AccountYear() , @Code, 1 as active  from dbo.tInventory -- t.stationid
		inner join tInventory_Level1 On tInventory_Level1.Branch = tInventory.Branch  and tInventory_Level1.InventoryNo  = tInventory.InventoryNo 
         	Inner join (select  Distinct(StationId), InventoryNo , Branch , AccountYear from tStation_Inventory_Good )t On  t.InventoryNo = tInventory_Level1.InventoryNo AND t.Branch =  tInventory_Level1.Branch and t.AccountYear = dbo.Get_AccountYear()

	        Where tInventory_Level1.Level1 = @Level1 

     IF @@ERROR <>0
        GoTo EventHandler
	UPDATE dbo.tGood SET nvcDate = dbo.shamsi(GETDATE()) WHERE Code = @Code
	Update tGood SET btnAscDefault = ASCII(left(ltrim([Name] COLLATE Arabic_CI_AI),1)) where code =  @Code


Commit Tran

SET @Result = 1 
RETURN @Result

EventHandler:
	RollBack Tran
SET @Result = -1 
RETURN @Result




GO


ALTER   PROCEDURE dbo.UpdatetGood
(
	@intLanguage	INT,
	@Goodname	NVARCHAR(50),
	@GoodNamePrn	NVARCHAR(50),
	@SellPrice	FLOAT,
	@BuyPrice	FLOAT,
	@Unit		INT,
	@GoodType	INT,
	@Barcode	NVARCHAR(50),
	@Code		INT,
	@Weight	Float,
	@NumberOfUnit 	INT,
	@SellPrice2 Float,
	@SellPrice3 Float ,
	@MainType Bit ,
	@Supplier Int ,
	@Level1 Int ,
	@Level2 Int ,
	@SellPrice4 Float,
	@SellPrice5 Float,
	@SellPrice6 Float,
	@CategoryShow INT ,
	@PicturePath NVARCHAR(100) ,
	@nvcDescription NVARCHAR(100) ,
	@Result Int Out
)

AS
Declare  @NewCode INT
Set @NewCode = @Code
Declare @Level2Code	INT
Set @Level2Code = (Select Level2 From tGood Where Code = @Code)

Begin Tran

If @Level2 <>  @Level2Code
Begin
--	Set @NewCode =  (SELECT  ISNULL(MAX(RIGHT(RTRIM(LTRIM(STR(code))),LEN(RTRIM(LTRIM(STR(Code))))-4)),0) +1   
	Set @NewCode =  (SELECT  ISNULL(MAX(code),0) + 1   
	FROM dbo.tgood 
	WHERE Level2 = @Level2 )
	If Len(@NewCode) = 1 

	Set @NewCode = (@Level2 * 10000) + @NewCode 

End


IF @intLanguage = 0 
Begin		
		UPDATE dbo.tGood

		SET [Name]    = dbo.Get_ArabicToFarsiString(@GoodName) ,
		    NamePrn   = dbo.Get_ArabicToFarsiString(@GoodNamePrn) ,
		    SellPrice = @SellPrice ,
		    BuyPrice  = @BuyPrice ,
		    Unit      = @Unit ,
		    GoodType  = @GoodType ,
		    Barcode = @Barcode,
	                 Weight = @Weight,
		    NumberOfUnit=@NumberOfUnit,
		    SellPrice2 = @SellPrice2,
		    SellPrice3 = @SellPrice3 ,	    	
		    SellPrice4 = @SellPrice4 ,	    	
		    SellPrice5 = @SellPrice5 ,	    	
		    SellPrice6 = @SellPrice6 ,	    	
		    MainType = @MainType  ,
		    ProductCompany = @Supplier ,
		   Level1 = @Level1 ,
		   Level2 = @Level2 ,
		 Code = @NewCode ,
		 CategoryShow = @CategoryShow ,
		 PicturePath = @PicturePath ,
		 nvcDescription = @nvcDescription 
	WHERE Code = @Code		
        IF @@ERROR <>0
	        GoTo EventHandler
End
ELSE IF @intLanguage = 1 
Begin
		UPDATE dbo.tGood

		SET LatinName     = @GoodName ,
		    LatinNamePrn  = @GoodNamePrn ,
		    SellPrice     = @SellPrice ,
		    BuyPrice      = @BuyPrice ,
		    Unit          = @Unit ,
		    GoodType      = @GoodType,
		    Barcode = @Barcode,
		    Weight = @Weight,
		    NumberOfUnit=@NumberOfUnit,
		    SellPrice2 = @SellPrice2,
		    SellPrice3 = @SellPrice3 ,
		    SellPrice4 = @SellPrice4 ,	    	
		    SellPrice5 = @SellPrice5 ,	    	
		    SellPrice6 = @SellPrice6 ,	    	
		    MainType = @MainType ,
	 	    ProductCompany = @Supplier ,
		   Level1 = @Level1 ,
		   Level2 = @Level2 ,
		 Code = @NewCode ,
		 CategoryShow = @CategoryShow ,
		 PicturePath = @PicturePath ,
		 nvcDescription = @nvcDescription 
		WHERE Code = @Code

        IF @@ERROR <>0
	        GoTo EventHandler
End
Set @Result = 1
 update  [dbo].[tGood]  set [name] = latinname where ([Name] is null or [Name] = ''  ) And Code = @NewCode

 update  [dbo].[tGood] set latinname = [name] where ([latinName] is null or latinname = '') And Code = @NewCode

 update  [dbo].[tGood] set [nameprn]=[latinnameprn] where ([Nameprn] is null or [Nameprn] = '') And Code = @NewCode 

 update  [dbo].[tGood] set [latinnameprn] = [nameprn] where ([latinNameprn] is null or latinnameprn = '') And Code = @NewCode

COMMIT TRANSACTION


Return @Result


EventHandler:
    ROLLBACK TRAN
    Set @Result = 0
    RETURN @Result





GO