
--Script_V26_15_Fix8
--����� ���� ����� ������ �� ���� ������� ���� ������� �� ����������
--Picture �� ��� tGood , tblTotal_GoodPic ���� ���� ��
-- 92/05/25

INSERT  INTO dbo.tblPub_Script2
        ( Version ,
          Script ,
          LastScriptNo ,
          [Date] ,
          FixNumber
        )
VALUES  ( 26 ,
          15 ,
          0 ,
          dbo.shamsi(GETDATE()) ,
          8
        )
GO



ALTER TABLE dbo.tGood
ADD Picture IMAGE NULL 
GO

ALTER TABLE dbo.tblTotal_GoodPic
ADD Picture IMAGE NULL 
GO


ALTER  PROCEDURE Update_tblTotal_GoodPic
 ( @PicturePath NVARCHAR(300),  
  @GoodCode int, 
  @Picture IMAGE , 
  @Updated INT OUT   
  
)  
  
AS   
  
Begin Tran  

DELETE FROM  tblTotal_GoodPic WHERE [GoodCode]=@GoodCode

IF LEN(@PicturePath) <> 0 
INSERT INTO  [tblTotal_GoodPic] ([GoodCode],[PicturePath] , picture) 
			VALUES ( @GoodCode,@PicturePath , @Picture)

  
  if @@Error <> 0   
   goto ErrHandler  
    
  Set @Updated = 1  
    
   
Commit Tran   
  
return @Updated  
  
ErrHandler:  
RollBack Tran  
Set @Updated = -1  
return @Updated  
  
  
  
  
GO


ALTER    PROCEDURE dbo.InserttGood
(
	@intLanguage	INT,
	@Code		INT,
	@GoodName	NVARCHAR(50),
	@GoodNamePrn	NVARCHAR(50),
	@SellPrice	FLOAT,
	@BuyPrice	FLOAT,
	@Barcode	NVARCHAR(50),
	@Level1		INT,
	@Level2		INT,
	@Model		INT,
	@Supplier	INT,
	@Unit		INT,
	@GoodType	INT,
	@Weight	Float,
	@NumberOfUnit 	INT,
	@SellPrice2 Float,
	@SellPrice3 Float ,
	@MainType Bit ,
	@SellPrice4 Float,
	@SellPrice5 Float,
	@SellPrice6 FLOAT ,
	@CategoryShow INT ,
	@PicturePath NVARCHAR(100) ,
	@nvcDescription NVARCHAR(100) ,
	@Picture IMAGE ,
	@Result INT OUT 
	


)

AS
Begin tran

	IF @intLanguage = 0 

		INSERT INTO dbo.tGood (Code,Name,NamePrn,SellPrice,BuyPrice,Barcode,Level1,Level2,Model,ProductCompany,Unit,GoodType,Weight,NumberOfUnit,SellPrice2 ,SellPrice3 , MainType , SellPrice4 ,SellPrice5 ,SellPrice6 , CategoryShow , PicturePath , nvcDescription )
		VALUES (@Code,dbo.Get_ArabicToFarsiString(@GoodName),dbo.Get_ArabicToFarsiString(@GoodNamePrn),@SellPrice,@BuyPrice,@Barcode,@Level1,@Level2,@Model,@Supplier,@Unit,@GoodType,@Weight,@NumberOfUnit, @SellPrice2 , @SellPrice3 , @MainType , @SellPrice4, @SellPrice5, @SellPrice6 , @CategoryShow , @PicturePath , @nvcDescription  )

	ELSE IF @intLanguage = 1 

		INSERT INTO dbo.tGood (Code,LatinName,LatinNamePrn,SellPrice,BuyPrice,Barcode,Level1,Level2,Model,ProductCompany,Unit,GoodType,Weight,NumberOfUnit, SellPrice2, SellPrice3 , MainType , SellPrice4 ,SellPrice5 ,SellPrice6 , CategoryShow ,PicturePath ,nvcDescription )
		VALUES (@Code,@GoodName,@GoodNamePrn,@SellPrice,@BuyPrice,@Barcode,@Level1,@Level2,@Model,@Supplier,@Unit,@GoodType,@Weight,@NumberOfUnit , @SellPrice2 , @SellPrice3 , @MainType , @SellPrice4, @SellPrice5, @SellPrice6 ,@CategoryShow ,@PicturePath ,@nvcDescription   )

     IF @@ERROR <>0
        GoTo EventHandler

 --         if  @GoodType = 3 
   --          Begin
     --               INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
	--	VALUES (@Code,@Code,1,1)
               --     INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
		--VALUES (@Code,@Code,2,1)
                  --  INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
--	--	VALUES (@Code,@Code,4,1)
              --      INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
	--	VALUES (@Code,@Code,8,1)
             --      INSERT INTO dbo.tUsePercent (GoodCode,GoodFirstCode,intServePlace,fltUsedValue)
	--	VALUES (@Code,@Code,16,1)
         --   End

	update  [dbo].[tGood]  set [name] = latinname where ([Name] is null or [Name] = '' ) And Code = @Code

	update  [dbo].[tGood] set latinname = [name] where ([latinName] is null or latinname = '') And Code = @Code

	update  [dbo].[tGood] set [nameprn]=[latinnameprn] where ([Nameprn] is null or [Nameprn] = '' ) And Code = @Code

	update  [dbo].[tGood] set [latinnameprn] = [nameprn] where ([latinNameprn] is null or latinnameprn = '') And Code = @Code

	UPDATE dbo.tGood SET Picture = @Picture WHERE Code = @Code
	
insert into .dbo.[tInventory_Good](GoodCode,InventoryNo,Branch , AccountYear )
  select @Code,tInventory.InventoryNo,tInventory.Branch , dbo.Get_AccountYear()  from dbo.tInventory 
		inner join tInventory_Level1 On tInventory_Level1.Branch = tInventory.Branch  and tInventory_Level1.InventoryNo  = tInventory.InventoryNo 
	        Where tInventory_Level1.Level1 = @Level1 

     IF @@ERROR <>0
        GoTo EventHandler

Insert into dbo.tStation_Inventory_Good ( branch ,InventoryNo, StationID,  AccountYear , GoodCode , Active)
select tInventory.Branch , tInventory.InventoryNo,  t.stationid , dbo.Get_AccountYear() , @Code, 1 as active  from dbo.tInventory -- t.stationid
		inner join tInventory_Level1 On tInventory_Level1.Branch = tInventory.Branch  and tInventory_Level1.InventoryNo  = tInventory.InventoryNo 
         	Inner join (select  Distinct(StationId), InventoryNo , Branch , AccountYear from tStation_Inventory_Good )t On  t.InventoryNo = tInventory_Level1.InventoryNo AND t.Branch =  tInventory_Level1.Branch and t.AccountYear = dbo.Get_AccountYear()

	        Where tInventory_Level1.Level1 = @Level1 

     IF @@ERROR <>0
        GoTo EventHandler
	UPDATE dbo.tGood SET nvcDate = dbo.shamsi(GETDATE()) WHERE Code = @Code
	Update tGood SET btnAscDefault = ASCII(left(ltrim([Name] COLLATE Arabic_CI_AI),1)) where code =  @Code


Commit Tran

SET @Result = 1 
RETURN @Result

EventHandler:
	RollBack Tran
SET @Result = -1 
RETURN @Result





GO


ALTER  PROCEDURE dbo.UpdatetGood
(
	@intLanguage	INT,
	@Goodname	NVARCHAR(50),
	@GoodNamePrn	NVARCHAR(50),
	@SellPrice	FLOAT,
	@BuyPrice	FLOAT,
	@Unit		INT,
	@GoodType	INT,
	@Barcode	NVARCHAR(50),
	@Code		INT,
	@Weight	Float,
	@NumberOfUnit 	INT,
	@SellPrice2 Float,
	@SellPrice3 Float ,
	@MainType Bit ,
	@Supplier Int ,
	@Level1 Int ,
	@Level2 Int ,
	@SellPrice4 Float,
	@SellPrice5 Float,
	@SellPrice6 Float,
	@CategoryShow INT ,
	@PicturePath NVARCHAR(100) ,
	@nvcDescription NVARCHAR(100) ,
	@Picture IMAGE ,
	@Result Int Out
)

AS
Declare  @NewCode INT
Set @NewCode = @Code
Declare @Level2Code	INT
Set @Level2Code = (Select Level2 From tGood Where Code = @Code)

Begin Tran

If @Level2 <>  @Level2Code
Begin
--	Set @NewCode =  (SELECT  ISNULL(MAX(RIGHT(RTRIM(LTRIM(STR(code))),LEN(RTRIM(LTRIM(STR(Code))))-4)),0) +1   
	Set @NewCode =  (SELECT  ISNULL(MAX(code),0) + 1   
	FROM dbo.tgood 
	WHERE Level2 = @Level2 )
	If Len(@NewCode) = 1 

	Set @NewCode = (@Level2 * 10000) + @NewCode 

End


IF @intLanguage = 0 
Begin		
		UPDATE dbo.tGood

		SET [Name]    = dbo.Get_ArabicToFarsiString(@GoodName) ,
		    NamePrn   = dbo.Get_ArabicToFarsiString(@GoodNamePrn) ,
		    SellPrice = @SellPrice ,
		    BuyPrice  = @BuyPrice ,
		    Unit      = @Unit ,
		    GoodType  = @GoodType ,
		    Barcode = @Barcode,
	                 Weight = @Weight,
		    NumberOfUnit=@NumberOfUnit,
		    SellPrice2 = @SellPrice2,
		    SellPrice3 = @SellPrice3 ,	    	
		    SellPrice4 = @SellPrice4 ,	    	
		    SellPrice5 = @SellPrice5 ,	    	
		    SellPrice6 = @SellPrice6 ,	    	
		    MainType = @MainType  ,
		    ProductCompany = @Supplier ,
		   Level1 = @Level1 ,
		   Level2 = @Level2 ,
		 Code = @NewCode ,
		 CategoryShow = @CategoryShow ,
		 PicturePath = @PicturePath ,
		 nvcDescription = @nvcDescription
	WHERE Code = @Code		
        IF @@ERROR <>0
	        GoTo EventHandler

End
ELSE IF @intLanguage = 1 
Begin
		UPDATE dbo.tGood

		SET LatinName     = @GoodName ,
		    LatinNamePrn  = @GoodNamePrn ,
		    SellPrice     = @SellPrice ,
		    BuyPrice      = @BuyPrice ,
		    Unit          = @Unit ,
		    GoodType      = @GoodType,
		    Barcode = @Barcode,
		    Weight = @Weight,
		    NumberOfUnit=@NumberOfUnit,
		    SellPrice2 = @SellPrice2,
		    SellPrice3 = @SellPrice3 ,
		    SellPrice4 = @SellPrice4 ,	    	
		    SellPrice5 = @SellPrice5 ,	    	
		    SellPrice6 = @SellPrice6 ,	    	
		    MainType = @MainType ,
	 	    ProductCompany = @Supplier ,
		   Level1 = @Level1 ,
		   Level2 = @Level2 ,
		 Code = @NewCode ,
		 CategoryShow = @CategoryShow ,
		 PicturePath = @PicturePath ,
		 nvcDescription = @nvcDescription 
		WHERE Code = @Code

        IF @@ERROR <>0
	        GoTo EventHandler

End
Set @Result = 1
	update  [dbo].[tGood]  set [name] = latinname where ([Name] is null or [Name] = ''  ) And Code = @NewCode

	update  [dbo].[tGood] set latinname = [name] where ([latinName] is null or latinname = '') And Code = @NewCode

	update  [dbo].[tGood] set [nameprn]=[latinnameprn] where ([Nameprn] is null or [Nameprn] = '') And Code = @NewCode 

	update  [dbo].[tGood] set [latinnameprn] = [nameprn] where ([latinNameprn] is null or latinnameprn = '') And Code = @NewCode

	UPDATE dbo.tGood SET Picture = @Picture WHERE Code = @Code

COMMIT TRANSACTION


Return @Result


EventHandler:
    ROLLBACK TRAN
    Set @Result = 0
    RETURN @Result



GO


ALTER    PROCEDURE Get_tGoods_By_StationID_For_PPC

@intStationID int

AS

select    dbo.tPocketPC_Good.PocketPCGroupCode, dbo.tPocketPC_Good.GoodCode, dbo.tPocketPC_Good.BtnNum, 
                      dbo.tpocketPC_Good.[NameDisplay] as FarsiName, dbo.tGood.LatinName, dbo.tGood.SellPrice,NameDisplay,dbo.tGood.discount
		, dbo.tGood.SellPrice2, dbo.tGood.SellPrice3, dbo.tGood.SellPrice4, dbo.tGood.SellPrice5, dbo.tGood.SellPrice6 , dbo.tGood.TaxSale , dbo.tGood.DutySale
		, tgood.Picture
from tgood inner join  tpocketPC_Good on tgood.Code=tpocketPC_Good.GoodCode where pocketPCGroupCode in
	(select pocketPCGroupCode from   tpocketPC_StationGroups where stationID=@intStationID AND tpocketPC_StationGroups.Branch =  dbo.Get_Current_Branch())
 AND tpocketPC_Good.Branch =  dbo.Get_Current_Branch()

ORDER BY  dbo.tPocketPC_Good.PocketPCGroupCode

GO





ALTER PROCEDURE [dbo].[GetGoodList] (@BtnNum int, @StationId int , @intLanguage int , @FactorType int )
AS


DECLARE @Branch INT 
SET @Branch = (SELECT TOP 1 Branch FROM dbo.tStations WHERE StationID = @StationId )

SELECT     dbo.tGood_Menu.BtnNum, dbo.tGood_Menu.StationId, dbo.tGood_Menu.GoodCode,
        case @intLanguage
            when 0 then dbo.tGood.Name
            when 1 then dbo.tGood.LatinName
        end As NAME , dbo.tGood.PicturePath , dbo.tGood.nvcDescription , tgood.CategoryShow , dbo.tGood.SellPrice , dbo.tGood.BuyPrice
        , tgood.Picture
FROM         dbo.tGood_Menu INNER JOIN
                      dbo.tGood ON dbo.tGood_Menu.GoodCode = dbo.tGood.Code
Where
	dbo.tGood_Menu.StationId=@StationId
	AND
	dbo.tGood_Menu.BtnNum = @BtnNum
	AND
	dbo.tGood_Menu.FactorType = @FactorType
	AND
	dbo.tGood_Menu.Branch =  @Branch 

Order By Name




GO





ALTER  Proc dbo.Get_Stations  (@MaxStationNo int ,
				@MaxPocketPcNo int ,
				@MaxTz1No int)
as 
--Declare @S nvarchar(4000)
--set @S = '(select Top ' + cast (@MaxStationNo as nvarchar(50)) + 
--	' * from dbo.tStations  Where 
--	 ((StationType & 1) = 1 or  (StationType & 2 = 2))  And IsActive = 1 )
--	Union
--	(select Top ' + cast (@MaxPocketPcNo as nvarchar(50)) + 
--	' * from dbo.tStations  Where 
--	 (StationType & 8) = 8  And IsActive = 1)
--	Union
--	(select Top ' + cast (@MaxTz1No as nvarchar(50)) + 
--	' * from dbo.tStations  Where 
--	 (StationType & 4) = 4 And IsActive = 1)'
--Exec ( @S)

SELECT * FROM dbo.tStations WHERE (((StationType & 1) = 1 or  (StationType & 2 = 2))  And IsActive = 1 )
 UNION
SELECT * FROM dbo.tStations WHERE ((StationType & 8) = 8  And IsActive = 1)
 UNION 
SELECT * FROM dbo.tStations WHERE ((StationType & 4) = 4  And IsActive = 1)
 UNION 
SELECT * FROM dbo.tStations WHERE ((StationType & 16) = 16  And IsActive = 1)


GO