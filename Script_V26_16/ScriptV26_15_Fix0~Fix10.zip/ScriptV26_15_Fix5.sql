
--Script_V26_15_Fix5


--  ����� ����� ������� �����
--����� ���� ���� ���� �� ��� ����
-- ����� ����� ����� ����� � ������ ������ �� ��� ��� ���� ���� ���
-- ����� ��� ����� ������
-- ����� ��� ��������� �� ��� ����� ���ϐ��
--����� �ѐ�� ��� �� �� ��� ������� �������
--  ����� ������� ������ �� ��� ������� ������� �� ������ ��� ������� ������ �� ���� �� ���
--����� ���� ��� ����� �� ��� ������� ������ � ������� ���� ��� ������� ������ �� ������ �����
--���� ���� ������ ����� � ��� ���� �� �������  ���� ������ ���� ���� �� ������ ������ ����
-- ��� ����� ��� ���� ���� ���� ���� �� ����� ��� �� ��� �����
-- �� ����� ���� ������ ����� ������ ��� ���� ��� ��� �� ����� ��� �������� ���� �� ���� � �� ����  ���� ������� ����� ��� ����
-- ����� ������� ���� ����� �� ���  ����� ��� �� ǐ� ������� ���� �� ���� ����� ����� ���
-- ���� ���� ����� �� ���� ���� ��� ���� ����� ����
--91/11/10

INSERT  INTO dbo.tblPub_Script2
        ( Version ,
          Script ,
          LastScriptNo ,
          [Date] ,
          FixNumber
        )
VALUES  ( 26 ,
          15 ,
          0 ,
          dbo.shamsi(GETDATE()) ,
          5
        )
GO


ALTER TABLE dbo.tFacMTemp
ADD TempAddress NVARCHAR(255) NULL 
GO 


UPDATE dbo.tObjects 
SET ObjectName = N'�������� ������� ������'
WHERE ObjectId = 'frmCreditCustomer'

GO 


--������ ���� �� ��� �� ���� ������� ��� ��� ���

ALTER   VIEW [dbo].[VwStationSaleSummery]
AS 
    SELECT  dbo.tFacM.[No] ,
            dbo.tFacM.[Date] ,
            dbo.tFacM.[Time] ,
            dbo.tFacM.[User] ,
            SumPrice ,
            CarryFeeTotal ,
            DiscountTotal ,
            StationID ,
            ServiceTotal ,
            PackingTotal ,
            TaxTotal ,
            DutyTotal ,
	        dbo.tfacm.[RoundDiscount],
            FacPayment ,
            Balance ,
            dbo.tfacm.Customer ,
            CASE dbo.tCust.[Name] + SPACE(3) + dbo.tCust.family
              WHEN NULL THEN dbo.tCust.WorkName
              WHEN '' THEN dbo.tCust.WorkName
              ELSE dbo.tCust.[Name] + '  ' + dbo.tCust.family
            END AS CustomerName ,
            dbo.tCust.tafsili AS CustomerTafsili ,
            dbo.tPer.nvcFirstName + ' ' + dbo.tPer.nvcSurName AS UserFullName ,
            dbo.tPer.tafsili AS PersonTafsili ,
            CASE dbo.tPer.Gender
              WHEN 1 THEN N'����'
              WHEN 0 THEN N'����'
            END AS UserGender ,
            CASE ISNULL(Incharge, 0)
              WHEN 0 THEN 0
              ELSE CASE ISNULL(TableNo, 0)
                     WHEN 0 THEN SumPrice
                     ELSE 0
                   END
            END AS CarrierSumPrice ,
            CASE ISNULL(Incharge, 0)
              WHEN 0 THEN 0
              ELSE CASE ISNULL(TableNo, 0)
                     WHEN 0 THEN 0
                     ELSE SumPrice
                   END
            END AS GarsonSumPrice ,
            CASE FacPayment
              WHEN 0 THEN CASE Balance
                            WHEN 0 THEN CASE ISNULL(Incharge, 0)
                                          WHEN 0 THEN 0
                                          ELSE CASE ISNULL(TableNo, 0)
                                                 WHEN 0 THEN SumPrice
                                                 ELSE 0
                                               END
                                        END
                            ELSE 0
                          END
              ELSE 0
            END AS CarrierDebit ,
            CASE FacPayment
              WHEN 0 THEN CASE ISNULL(Incharge, 0)
                            WHEN 0 THEN 0
                            ELSE CASE ISNULL(TableNo, 0)
                                   WHEN 0 THEN 0
                                   ELSE SumPrice
                                 END
                          END
              ELSE 0
            END AS GarsonDebit ,
--            CASE Balance
--              WHEN 0 THEN CASE FacPayment
--                            WHEN 0 THEN 0
--                            ELSE SumPrice
--                          END
--              ELSE 0
--            END AS CustomerDebit ,
			CASE WHEN (Facpayment = 1 or (Incharge is NULL AND serveplace <> 2)) THEN 
				SumPrice - (ISNULL(Resived.Received , 0) +ISNULL(ChequeReceived.ChequeReceived , 0)+ISNULL(CardReceived.CardReceived , 0)+ISNULL(BonReceived.BonReceived , 0)+ISNULL(PreReceived2.PreReceived2 , 0))
				ELSE 0
			END AS CustomerDebit ,
            CASE Balance
              WHEN 0 THEN CASE FacPayment
                            WHEN 0 THEN CASE ISNULL(Incharge, 0)
                                          WHEN 0 THEN SumPrice
                                          ELSE 0
                                        END
                            ELSE 0
                          END
              ELSE 0
            END AS UnBalanceFich ,
            dbo.tFacM.Branch ,
            0 AS Payment ,
            ISNULL(Resived.Received , 0) AS Recieved ,
            tper.ppno ,
            tfacm.status ,
            ISNULL(tblAcc_Recieved.bestankar , 0) AS preRecieved ,
            ISNULL(ChequeReceived.ChequeReceived ,0) AS ChequeRecieved ,
            ISNULL(CardReceived.CardReceived , 0) AS CardReceived ,
            ISNULL(BonReceived.BonReceived , 0) AS BonReceived ,
            ISnull(tFactorAdditionalServices.amount , 0)  AS TipAmount ,
			0 AS ManualRecieved ,
			ISNULL(PreReceived.PreReceived , 0) AS TablePreReceived
			, 0 AS OrderPrice 
			, 0 AS OrderReceived 
    FROM    dbo.tFacM
            INNER JOIN dbo.tUser ON dbo.tFacM.[User] = dbo.tUser.UID
            INNER JOIN dbo.tPer ON tUser.ppno = tPer.ppno
            INNER JOIN tCUst ON tfacM.Customer = tcust.code
            LEFT OUTER JOIN [tblAcc_Recieved] ON tfacm.[OrderRefrence] = [tblAcc_Recieved].[intSerialNo] 
            LEFT OUTER JOIN [tFactorAdditionalServices] ON [tFactorAdditionalServices].[Branch] = [tFacM].[Branch] AND [tFactorAdditionalServices].[intSerialNo] = [tFacM].[intSerialNo]
		AND tFactorAdditionalServices.intServiceNo = 3
	    LEFT outer JOIN (SELECT ISNULL(SUM(intAmount),0) AS Received,intSerialNo , Branch FROM  [dbo].[tFacCash] 
			GROUP BY intSerialNo , Branch) AS Resived ON Resived.Branch = tfacm.Branch AND  Resived.intSerialNo = dbo.tFacM.intSerialNo
	    LEFT outer JOIN (SELECT ISNULL(SUM(intAmount),0) AS CardReceived,intSerialNo , Branch FROM  [dbo].[tFacCard] 
			GROUP BY intSerialNo , Branch) AS CardReceived ON CardReceived.Branch = tfacm.Branch AND  CardReceived.intSerialNo = dbo.tFacM.intSerialNo
	    LEFT outer JOIN (SELECT ISNULL(SUM(intAmount),0) AS BonReceived,intSerialNo , Branch FROM  [dbo].[tFacCredit] 
			GROUP BY intSerialNo , Branch) AS BonReceived ON BonReceived.Branch = tfacm.Branch AND  BonReceived.intSerialNo = dbo.tFacM.intSerialNo
	    LEFT outer JOIN (SELECT ISNULL(SUM(intChequeAmount),0) AS ChequeReceived,intSerialNo , Branch FROM  [dbo].[tFacCheque] 
			GROUP BY intSerialNo , Branch) AS ChequeReceived ON ChequeReceived.Branch = tfacm.Branch AND  ChequeReceived.intSerialNo = dbo.tFacM.intSerialNo
	    LEFT outer JOIN (SELECT ISNULL(SUM(Bestankar),0) AS PreReceived ,intSerialNo , Branch FROM  [dbo].[tblAcc_Recieved] 
			GROUP BY intSerialNo , Branch) AS PreReceived ON PreReceived.Branch = tfacm.Branch AND  PreReceived.intSerialNo = dbo.tFacM.intSerialNo AND dbo.tFacM.ServePlace = 16
	    LEFT outer JOIN (SELECT ISNULL(SUM(Bestankar),0) AS PreReceived2 ,intSerialNo , Branch FROM  [dbo].[tblAcc_Recieved] 
			GROUP BY intSerialNo , Branch) AS PreReceived2 ON PreReceived2.Branch = tfacm.Branch AND  PreReceived2.intSerialNo = dbo.tFacM.intSerialNo

    WHERE   ( Recursive = 0  AND Status = 2 )

    UNION
    SELECT  dbo.tFacM.[No] ,
            dbo.tFacM.[Date] ,
            dbo.tFacM.[Time] ,
            dbo.tFacM.[User] ,
            0 AS SumPrice ,
            0 AS CarryFeeTotal ,
            0 AS DiscountTotal ,
            StationID ,
            0 AS ServiceTotal ,
            0 AS PackingTotal ,
            0 AS TaxTotal ,
            0 AS DutyTotal ,
	        0 AS [RoundDiscount],
            0 AS FacPayment ,
            0 AS Balance ,
            NULL AS Customer ,
            NULL AS CustomerName ,
            NULL AS CustomerTafsili ,
            dbo.tPer.nvcFirstName + ' ' + dbo.tPer.nvcSurName AS UserFullName ,
            dbo.tPer.tafsili AS PersonTafsili ,
            CASE dbo.tPer.Gender
              WHEN 1 THEN N'����'
              WHEN 0 THEN N'����'
            END AS UserGender ,
            0 AS CarrierSumPrice ,
            0 AS GarsonSumPrice ,
            0 AS CarrierDebit ,
            0 AS GarsonDebit ,
            0 AS CustomerDebit ,
            0 AS UnbalaceFich ,
            tFacM.Branch AS Branch ,
            0 AS Payment ,
            0 AS Recieved ,
            NULL AS ppno ,
            2 AS status ,
            0 AS preRecieved ,
            0 AS ChequeRecieved ,
	    0 AS CardReceived ,
	    0 AS BonReceived ,
	    0 AS TipAmount ,
	    0 AS ManualRecieved ,
	    0 AS TablePreReceived ,
	    SumPrice AS OrderPrice ,
	    0 AS OrderReceived
    FROM    dbo.tFacM 
            INNER JOIN dbo.tUser ON dbo.tFacM.[User] = dbo.tUser.UID
            INNER JOIN dbo.tPer ON tUser.ppno = tPer.ppno
            INNER JOIN tCust ON tfacM.Customer = tcust.code
    WHERE Recursive = 0 AND Status = 10
    UNION
    SELECT  list AS [No] ,
            tblAcc_Cash.[Date] AS [Date] ,
            RegTime AS [Time] ,
            tblAcc_Cash.UID AS [User] ,
            0 AS SumPrice ,
            0 AS CarryFeeTotal ,
            0 AS DiscountTotal ,
            0 AS StationID ,
            0 AS ServiceTotal ,
            0 AS PackingTotal ,
            0 AS TaxTotal ,
            0 AS DutyTotal ,
            0 AS RoundDiscount ,
            0 AS FacPayment ,
            0 AS Balance ,
            NULL AS Customer ,
            NULL AS CustomerName ,
            NULL AS CustomerTafsili ,
            dbo.tPer.nvcFirstName + ' ' + dbo.tPer.nvcSurName AS UserFullName ,
            dbo.tPer.tafsili AS PersonTafsili ,
            CASE dbo.tPer.Gender
              WHEN 1 THEN N'����'
              WHEN 0 THEN N'����'
            END AS UserGender ,
            0 AS CarrierSumPrice ,
            0 AS GarsonSumPrice ,
            0 AS CarrierDebit ,
            0 AS GarsonDebit ,
            0 AS CustomerDebit ,
            0 AS UnbalaceFich ,
            tblAcc_Cash.Branch AS Branch ,
            Bestankar AS Payment ,
            0 AS Recieved ,
            NULL AS ppno ,
            2 AS status ,
            0 AS preRecieved ,
            0 AS ChequeRecieved ,
	    0 AS CardReceived ,
	    0 AS BonReceived ,
	    0 AS TipAmount ,
	    0 AS ManualRecieved ,
	    0 AS TablePreReceived ,
	    0 AS OrderPrice ,
	    0 AS OrderReceived
    FROM    tblAcc_Cash
            INNER JOIN dbo.tUser ON dbo.tblAcc_Cash.[UID] = dbo.tUser.UID
            INNER JOIN dbo.tPer ON tUser.ppno = tPer.ppno
    UNION
    SELECT  list AS [No] ,
            tblAcc_Recieved.[Date] AS [Date] ,
            RegTime AS [Time] ,
            tblAcc_Recieved.UID AS [User] ,
            0 AS SumPrice ,
            0 AS CarryFeeTotal ,
            0 AS DiscountTotal ,
            0 AS StationID ,
            0 AS ServiceTotal ,
            0 AS PackingTotal ,
            0 AS TaxTotal ,
            0 AS DutyTotal ,
            0 AS RoundDiscount ,
            0 AS FacPayment ,
            0 AS Balance ,
            NULL AS Customer ,
            NULL AS CustomerName ,
            NULL AS CustomerTafsili ,
            dbo.tPer.nvcFirstName + ' ' + dbo.tPer.nvcSurName AS UserFullName ,
            dbo.tPer.tafsili AS PersonTafsili ,
            CASE dbo.tPer.Gender
              WHEN 1 THEN N'����'
              WHEN 0 THEN N'����'
            END AS UserGender ,
            0 AS CarrierSumPrice ,
            0 AS GarsonSumPrice ,
            0 AS CarrierDebit ,
            0 AS GarsonDebit ,
            0 AS CustomerDebit ,
            0 AS UnbalaceFich ,
            tblAcc_Recieved.Branch AS Branch ,
            0 AS Payment ,
            Bestankar AS Recieved ,
            NULL AS ppno ,
            2 AS status ,
            0 AS preRecieved ,
            0 AS ChequeRecieved ,
	    0 AS CardReceived ,
	    0 AS BonReceived ,
	    0 AS TipAmount ,
	    0 AS ManualRecieved ,
	    0 AS TablePreReceived ,
	    0 AS OrderPrice ,
  	    0 AS OrderReceived

    FROM    tblAcc_Recieved 
		INNER JOIN dbo.tFacM ON dbo.tblAcc_Recieved.Branch = dbo.tFacM.Branch AND dbo.tblAcc_Recieved.intSerialNo = dbo.tFacM.intSerialNo
		INNER JOIN dbo.tUser ON dbo.tblAcc_Recieved.[UID] = dbo.tUser.UID
		INNER JOIN dbo.tPer ON tUser.ppno = tPer.ppno
	WHERE tblAcc_Recieved.intSerialNo IS NOT NULL AND Status = 2
    UNION
    SELECT  list AS [No] ,
            tblAcc_Recieved.[Date] AS [Date] ,
            RegTime AS [Time] ,
            tblAcc_Recieved.UID AS [User] ,
            0 AS SumPrice ,
            0 AS CarryFeeTotal ,
            0 AS DiscountTotal ,
            0 AS StationID ,
            0 AS ServiceTotal ,
            0 AS PackingTotal ,
            0 AS TaxTotal ,
            0 AS DutyTotal ,
            0 AS RoundDiscount ,
            0 AS FacPayment ,
            0 AS Balance ,
            NULL AS Customer ,
            NULL AS CustomerName ,
            NULL AS CustomerTafsili ,
            dbo.tPer.nvcFirstName + ' ' + dbo.tPer.nvcSurName AS UserFullName ,
            dbo.tPer.tafsili AS PersonTafsili ,
            CASE dbo.tPer.Gender
              WHEN 1 THEN N'����'
              WHEN 0 THEN N'����'
            END AS UserGender ,
            0 AS CarrierSumPrice ,
            0 AS GarsonSumPrice ,
            0 AS CarrierDebit ,
            0 AS GarsonDebit ,
            0 AS CustomerDebit ,
            0 AS UnbalaceFich ,
            tblAcc_Recieved.Branch AS Branch ,
            0 AS Payment ,
            0 AS Recieved ,
            NULL AS ppno ,
            2 AS status ,
            0 AS preRecieved ,
            0 AS ChequeRecieved ,
	    0 AS BonReceived ,
	    0 AS CardReceived ,
	    0 AS TipAmount ,
	    0 AS ManualRecieved ,
	    0 AS TablePreReceived ,
	    0 AS OrderPrice ,
  	    Bestankar AS OrderReceived

    FROM    tblAcc_Recieved 
	    INNER JOIN dbo.tFacM ON dbo.tblAcc_Recieved.Branch = dbo.tFacM.Branch AND dbo.tblAcc_Recieved.intSerialNo = dbo.tFacM.intSerialNo
        INNER JOIN dbo.tUser ON dbo.tblAcc_Recieved.[UID] = dbo.tUser.UID
        INNER JOIN dbo.tPer ON tUser.ppno = tPer.ppno
    WHERE tblAcc_Recieved.intSerialNo IS NOT NULL AND Status = 10
    UNION
    SELECT  list AS [No] ,
            tblAcc_Recieved.[Date] AS [Date] ,
            RegTime AS [Time] ,
            tblAcc_Recieved.UID AS [User] ,
            0 AS SumPrice ,
            0 AS CarryFeeTotal ,
            0 AS DiscountTotal ,
            0 AS StationID ,
            0 AS ServiceTotal ,
            0 AS PackingTotal ,
            0 AS TaxTotal ,
            0 AS DutyTotal ,
            0 AS RoundDiscount ,
            0 AS FacPayment ,
            0 AS Balance ,
            NULL AS Customer ,
            NULL AS CustomerName ,
            NULL AS CustomerTafsili ,
            dbo.tPer.nvcFirstName + ' ' + dbo.tPer.nvcSurName AS UserFullName ,
            dbo.tPer.tafsili AS PersonTafsili ,
            CASE dbo.tPer.Gender
              WHEN 1 THEN N'����'
              WHEN 0 THEN N'����'
            END AS UserGender ,
            0 AS CarrierSumPrice ,
            0 AS GarsonSumPrice ,
            0 AS CarrierDebit ,
            0 AS GarsonDebit ,
            0 AS CustomerDebit ,
            0 AS UnbalaceFich ,
            tblAcc_Recieved.Branch AS Branch ,
            0 AS Payment ,
            0 AS Recieved ,
            NULL AS ppno ,
            2 AS status ,
            0 AS preRecieved ,
            0 AS ChequeRecieved ,
	    0 AS CardReceived ,
	    0 AS BonReceived ,
	    0 AS TipAmount ,
	    Bestankar AS ManualRecieved ,
	    0 AS TablePreReceived ,
	    0 AS OrderPrice ,
	    0 AS OrderReceived
    FROM    tblAcc_Recieved 
        INNER JOIN dbo.tUser ON dbo.tblAcc_Recieved.[UID] = dbo.tUser.UID
        INNER JOIN dbo.tPer ON tUser.ppno = tPer.ppno
    WHERE intSerialNo IS NULL 
    UNION
    SELECT  [No] ,
            tblAcc_Recieved_Cheque.[RegDate] AS [Date] ,
            RegTime AS [Time] ,
            tblAcc_Recieved_Cheque.UID AS [User] ,
            0 AS SumPrice ,
            0 AS CarryFeeTotal ,
            0 AS DiscountTotal ,
            0 AS StationID ,
            0 AS ServiceTotal ,
            0 AS PackingTotal ,
            0 AS TaxTotal ,
            0 AS DutyTotal ,
            0 AS RoundDiscount ,
            0 AS FacPayment ,
            0 AS Balance ,
            NULL AS Customer ,
            NULL AS CustomerName ,
            NULL AS CustomerTafsili ,
            dbo.tPer.nvcFirstName + ' ' + dbo.tPer.nvcSurName AS UserFullName ,
            NULL AS PersonTafsili ,
            NULL AS UserGender ,
            0 AS CarrierSumPrice ,
            0 AS GarsonSumPrice ,
            0 AS CarrierDebit ,
            0 AS GarsonDebit ,
            0 AS CustomerDebit ,
            0 AS UnbalaceFich ,
            tblAcc_Recieved_Cheque.Branch AS Branch ,
            0 AS Payment ,
            0 AS Recieved ,
            NULL AS ppno ,
            2 AS status ,
            0 AS preRecieved ,
            intChequeAmount AS ChequeRecieved ,
	    0 AS CardReceived ,
	    0 AS BonReceived ,
	    0 AS TipAmount ,
	    0 AS ManualRecieved ,
	    0 AS TablePreReceived ,
	    0 AS OrderPrice ,
	    0 AS OrderReceived
    FROM    tblAcc_Recieved_Cheque
        INNER JOIN dbo.tUser ON dbo.tblAcc_Recieved_Cheque.[UID] = dbo.tUser.UID
        INNER JOIN dbo.tPer ON tUser.ppno = tPer.ppno
--===============================================







GO




ALTER   PROCEDURE [dbo].[Get_MemberSupplier]  ( @MasterCode INT   ) --, @Branch INT

AS
	Select * from tSupplier where MasterCode = @MasterCode and Code >0 --and Branch =  @Branch 



GO



ALTER   PROCEDURE [dbo].[Get_MemberCustomers]  ( @MasterCode INT   )  --, @Branch INT

AS
	Select * from tCust where MasterCode = @MasterCode and Code >0 --and Branch =  @Branch 



GO


ALTER     Procedure dbo.Insert_Cust  
( 
	@MembershipId nVarChar(50) ,   
	@MasterCode int, 
	@Owner int ,   
	@Name nVarChar(50),   
	@Family nVarChar(50),   
	@Sex int,   
	@WorkName nVarChar(50),   
	@InternalNo nVarChar(50),   
	@Unit nVarChar(50),   
	@City int,   
	@ActKind int,   
	@ActDeAct int,  
	@Prefix int,   
	@Assansor int,   
	@Address nVarChar(255),   
	@PostalCode nVarChar(50),   
	@Tel1 nVarChar(50),   
	@Tel2 nVarChar(50),   
	@Tel3 nVarChar(50),   
	@Tel4 nVarChar(50),   
	@Mobile nVarChar(50),   
	@Fax nVarChar(50),   
	@Email nVarChar(50),   
	@Flour nVarChar(50),   
	@CarryFee Float,   
	@PaykFee Float,   
	@Distance int,   
	@Credit Float,   
	@Discount Float,   
	@BuyState int,   
	@Description nVarChar(255),   
	@User int ,   
	@FamilyNo int ,  
	@Member Bit ,  
	@State int ,  
	@Central Bit ,  
	@Sellprice smallint,  
	@EconomicCode NVARCHAR(20) ,
	@nvcRFID NVARCHAR(20)=N''  ,
	@nvcBirthDate NVARCHAR(10)=N''  ,
--	@Branch INT = NULL ,
	@Code Bigint out 

)  

as  

Begin Tran  

--IF  @Branch IS NULL Set @Branch = dbo.Get_Current_Branch()  
if @MasterCode = 0   
  Set @MasterCode = Null  
if @MasterCode is not Null  
 begin  
   Set @MembershipId = (Select top 1 MembershipId from  dbo.tCust where  Code = @MasterCode  )  --AND (Branch = @Branch )
   Set @BuyState = (Select top 1 BuyState from  dbo.tCust where  Code = @MasterCode   )--AND (Branch = @Branch )
 end   
else   

 if (Select top 1 isnull(Code , 0) from tCust where MembershipId = @MembershipId ) <> 0 --AND Branch = @Branch)   
  Goto ErrHandler   

--Set @Code = (Select  isnull(Max(Code),0) + 1 from tCust where code > 0)  

Declare @Time nVarchar(50)  
Set @Time = (select dbo.setTimeFormat(GETDATE()))  

Declare @Date nVarchar(50)  
Set @Date =(Select dbo.Shamsi(GETDATE()))  

if @nvcRFID = N''  
  SET @nvcRFID=N'-999'  

insert Into dbo.tCust  
(   
	--Code,   
	MembershipId,   
	MasterCode,   
	Owner,   
	Name,   
	Family,   
	Sex,   
	WorkName,   
	InternalNo,   
	Unit,   
	City,   
	ActKind,   
	ActDeAct,  
	Prefix,   
	Assansor,   
	Address,   
	PostalCode,   
	Tel1,   
	Tel2,   
	Tel3,   
	Tel4,   
	Mobile,   
	Fax,   
	Email,   
	Flour,   
	CarryFee,   
	PaykFee,   
	Distance,   
	Credit,   
	Discount,   
	BuyState,   
	[Description],   
	[Date],   
	[Time],   
	[User],  
	FamilyNo ,  
	Member ,  
	State ,  
	Central ,  
	Branch,  
	nvcRFID,  
	sellprice ,
	EconomicCode ,
	nvcBirthDate
	
)  
values  
(   
	--@Code ,  
	@MembershipId,   
	@MasterCode,   
	@Owner,   
	@Name,   
	@Family,   
	@Sex,   
	@WorkName,   
	@InternalNo,   
	@Unit,   
	@City,   
	@ActKind,   
	@ActDeAct,  
	@Prefix,   
	@Assansor,   
	@Address,   
	@PostalCode,   
	@Tel1,   
	@Tel2,   
	@Tel3,   
	@Tel4,   
	@Mobile,   
	@Fax,   
	@Email,   
	@Flour,   
	@CarryFee,   
	@PaykFee,   
	@Distance,   
	@Credit,   
	@Discount,   
	@BuyState,   
	@Description,   
	@Date,   
	@Time,   
	@User ,  
	@FamilyNo ,  
	@Member ,  
	@State ,  
	@Central ,  
	NULL , --@Branch,  
	@nvcRFID,  
	@sellprice   ,
	@EconomicCode ,
	@nvcBirthDate
	
)  
if @@Error <> 0   
 goto ErrHandler  

Set @Code = @@Identity  
 UPDATE dbo.tCust  
 SET Address = tmpCust.Address  
 FROM dbo.tCust  , dbo.tCust tmpCust  
 WHERE dbo.tCust.MasterCode = tmpCust.Code  
  --and (dbo.tCust.[Branch] = tmpCust.[Branch] )  
update tcust set address=dbo.addressedit(address)  
 , nvcRFID=CAST(Branch AS NVARCHAR(1))+CAST(Code AS NVARCHAR(8))  
  where code=@code  --AND Branch = @Branch 



Commit Tran   
return @Code  

ErrHandler:  
RollBack Tran  
Set @Code = -1  
return @Code




GO




ALTER  Procedure dbo.Insert_Supplier  
( 
	@MembershipId nVarChar(50) ,   
	@MasterCode int,  
	@Owner int ,   
	@Name nVarChar(50),   
	@Family nVarChar(50),   
	@Sex int,   
	@WorkName nVarChar(50),   
	@InternalNo nVarChar(50),   
	@Unit nVarChar(50),   
	@State int ,  
	@City int,   
	@ActKind int,   
	@ActDeAct int,  
	@Prefix int,   
	@Address nVarChar(255),   
	@PostalCode nVarChar(50),   
	@Tel1 nVarChar(50),   
	@Tel2 nVarChar(50),   
	@Tel3 nVarChar(50),   
	@Tel4 nVarChar(50),   
	@Mobile nVarChar(50),   
	@Fax nVarChar(50),   
	@Email nVarChar(50),   
	@Flour nVarChar(50),   
	@Discount Float,   
	@Description nVarChar(255),   
	@User int ,
--	@Branch INT ,   
	@Code Bigint out  
)  

as  

Begin Tran  

--IF  @Branch IS NULL Set @Branch = dbo.Get_Current_Branch()  
if @MasterCode = 0   
  Set @MasterCode = Null  
if @MasterCode is not Null  
 begin  
   Set @MembershipId = (Select top 1 MembershipId from  dbo.tSupplier where  Code = @MasterCode ) --AND (Branch = @Branch ) )  
    end   
else   

 if (Select top 1 isnull(Code , 0) from tSupplier where MembershipId = @MembershipId) <> 0 -- AND Branch = @Branch ) <> 0   
  Goto ErrHandler   

--Set @Code = (Select  isnull(Max(Code),0) + 1 from tSupplier where code > 0)  

Declare @Time nVarchar(50)  
Set @Time = (select dbo.setTimeFormat(GETDATE()))  

Declare @Date nVarchar(50)  
Set @Date =(Select dbo.Shamsi(GETDATE()))  

insert Into dbo.tSupplier  
(   
	--Code,   
	MembershipId,   
	MasterCode,   
	Owner,   
	Name,   
	Family,   
	Sex,   
	WorkName,   
	InternalNo,   
	Unit,   
	State ,  
	City,   
	ActKind,   
	ActDeAct,  
	Prefix,   
	Address,   
	PostalCode,   
	Tel1,   
	Tel2,   
	Tel3,   
	Tel4,   
	Mobile,   
	Fax,   
	Email,   
	Flour,   
	Discount,   
	[Description],   
	[Date],   
	[Time],   
	[User],  
	Branch  
)  
values  
(   
	--@Code ,  
	@MembershipId,   
	@MasterCode,   
	@Owner,   
	@Name,   
	@Family,   
	@Sex,   
	@WorkName,   
	@InternalNo,   
	@Unit,   
	@State,   
	@City,   
	@ActKind,   
	@ActDeAct,  
	@Prefix,   
	@Address,   
	@PostalCode,   
	@Tel1,   
	@Tel2,   
	@Tel3,   
	@Tel4,   
	@Mobile,   
	@Fax,   
	@Email,   
	@Flour,   
	@Discount,   
	@Description,   
	@Date,   
	@Time,   
	@User ,  
	NULL --@Branch  
)  
if @@Error <> 0   
 goto ErrHandler  

Set @Code = @@Identity  
 UPDATE dbo.tSupplier  
 SET Address = tmpCust.Address  
 FROM dbo.tSupplier  , dbo.tSupplier tmpCust  
 WHERE dbo.tSupplier.MasterCode = tmpCust.Code  
  --and (dbo.tSupplier.[Branch] = tmpCust.[Branch] )   

update tSupplier set address=dbo.addressedit(address) where code=@code  -- AND Branch = @Branch
   

Commit Tran
return @Code  

ErrHandler:  
RollBack Tran  
Set @Code = -1  
return @Code  
--Select @Code





GO


ALTER  Procedure dbo.Update_Supplier  
( 
	@MembershipId nVarChar(50) ,   
	@MasterCode int,  
	@Owner int ,   
	@Name nVarChar(50),   
	@Family nVarChar(50),   
	@Sex int,   
	@WorkName nVarChar(50),   
	@InternalNo nVarChar(50),   
	@Unit nVarChar(50),   
	@State int ,   
	@City int,   
	@ActKind int,   
	@ActDeAct int,  
	@Prefix int,   
	@Address nVarChar(255),   
	@PostalCode nVarChar(50),   
	@Tel1 nVarChar(50),   
	@Tel2 nVarChar(50),   
	@Tel3 nVarChar(50),   
	@Tel4 nVarChar(50),   
	@Mobile nVarChar(50),   
	@Fax nVarChar(50),   
	@Email nVarChar(50),   
	@Flour nVarChar(50),   
	@Discount Float,   
	@Description nVarChar(255),   
	@User int ,   
	@Code Bigint , 
--	@Branch INT , 
	@Updated Bigint out  

)  

as  

Begin Tran  
--IF @Branch IS NULL Set @Branch = dbo.Get_Current_Branch()  

if @MasterCode = 0   
 Set @MasterCode = Null  
if @MasterCode is not Null    
 begin  
   Set @MembershipId = (Select top 1 MembershipId from  dbo.tSupplier where  Code = @MasterCode )--  AND (Branch = @Branch ) )  
    end  
else   

 if (Select top 1 isnull(Code , 0) from tSupplier where MembershipId = @MembershipId and Code <> @Code and MasterCode <> @Code ) <> 0 --  AND (Branch = @Branch ) ) <> 0    
  Goto ErrHandler   
 else  

  Update dbo.tSupplier     
   Set MembershipId = @MembershipId   

  Where MasterCode = @Code   --AND (Branch = @Branch )  



Declare @Time nVarchar(50)  
Set @Time = (select dbo.setTimeFormat(GETDATE()))  

Declare @Date nVarchar(50)  
Set @Date =(Select dbo.Shamsi(GETDATE()))  

Update dbo.tSupplier  

 Set MembershipId = @MembershipId ,  
 MasterCode  = @MasterCode ,    
 Owner = @Owner ,  
 Name = @Name ,  
 Family = @Family ,  
 Sex = @Sex ,  
 WorkName = @WorkName ,   
 InternalNo = @InternalNo ,  
 Unit = @Unit ,  
 State = @State ,  
 City = @City ,  
 ActKind = @ActKind ,  
 ActDeAct = @ActDeAct ,  
 Prefix = @Prefix ,  
 Address = @Address ,  
 PostalCode = @PostalCode ,  
 Tel1 = @Tel1 ,  
 Tel2 = @Tel2 ,  
 Tel3 = @Tel3 ,  
 Tel4 = @Tel4 ,  
 Mobile = @Mobile ,  
 Fax = @Fax ,  
 Email = @Email ,  
 Flour = @Flour ,  
 Discount = @Discount ,  
 [Description] = @Description ,  
 [Date] = @Date ,  
 [Time] = @Time ,  
 [User] = @User  
Where Code = @Code  -- AND (Branch = @Branch )  


if @@Error <> 0   
 goto ErrHandler  

 UPDATE dbo.tSupplier  
 SET Address = tmpCust.Address  
 FROM dbo.tSupplier  , dbo.tSupplier tmpCust  
 WHERE dbo.tSupplier.MasterCode = tmpCust.Code  
  --and (dbo.tSupplier.[Branch] = tmpCust.[Branch] or dbo.tSupplier.[Branch] is Null)  

update tSupplier set address=dbo.addressedit(address) where code=@code  --AND (Branch = @Branch )


Commit Tran   
Set @Updated = @Code  
return @Updated  

ErrHandler:  
RollBack Tran  
Set @Updated = 0  
return @Updated



GO



ALTER  Procedure dbo.Update_Cust  
( 
	@MembershipId nVarChar(50) ,   
	@MasterCode int,  
	@Owner int ,   
	@Name nVarChar(50),   
	@Family nVarChar(50),   
	@Sex int,   
	@WorkName nVarChar(50),   
	@InternalNo nVarChar(50),   
	@Unit nVarChar(50),   
	@City int,   
	@ActKind int,   
	@ActDeAct int,  
	@Prefix int,   
	@Assansor int,   
	@Address nVarChar(255),   
	@PostalCode nVarChar(50),   
	@Tel1 nVarChar(50),   
	@Tel2 nVarChar(50),   
	@Tel3 nVarChar(50),   
	@Tel4 nVarChar(50),   
	@Mobile nVarChar(50),   
	@Fax nVarChar(50),   
	@Email nVarChar(50),   
	@Flour nVarChar(50),   
	@CarryFee Float,   
	@PaykFee Float,   
	@Distance int,   
	@Credit Float,   
	@Discount Float,   
	@BuyState int,   
	@Description nVarChar(255),   
	@User int ,   
	@Code Bigint ,  
	@FamilyNo int ,  
	@Member Bit ,  
	@State int ,  
	@Central Bit ,  
	@Sellprice smallint,  
	@EconomicCode NVARCHAR(20) ,
	@nvcRFID NVARCHAR(20)=N''  ,
	@nvcBirthDate NVARCHAR(10)=N''  ,
--	@Branch INT = NULL ,
	@Updated Bigint out  

)  

as  

Begin Tran  
--IF  @Branch IS NULL Set @Branch = dbo.Get_Current_Branch()  

if @MasterCode = 0   
 Set @MasterCode = Null  
if @MasterCode is not Null    
 begin  
   Set @MembershipId = (Select top 1 MembershipId from  dbo.tCust where  Code = @MasterCode  ) --AND (Branch = @Branch ) )  
   Set @BuyState = (Select top 1 BuyState from  dbo.tCust where  Code = @MasterCode )   --AND (Branch = @Branch ) )  
 end  
else   

 if (Select top 1 isnull(Code , 0) from tCust where MembershipId = @MembershipId and Code <> @Code and MasterCode <> @Code  ) <> 0  -- AND (Branch = @Branch )    
  Goto ErrHandler   
 else  

  Update dbo.tCust     
   Set MembershipId = @MembershipId   

   Where MasterCode = @Code   --AND (Branch = @Branch )  



Declare @Time nVarchar(50)  
Set @Time = (select dbo.setTimeFormat(GETDATE()))  

Declare @Date nVarchar(50)  
Set @Date =(Select dbo.Shamsi(GETDATE()))  

Update dbo.tCust  

 Set MembershipId = @MembershipId ,  
	MasterCode  = @MasterCode ,    
	Owner = @Owner ,  
	Name = @Name ,  
	Family = @Family ,  
	Sex = @Sex ,  
	WorkName = @WorkName ,   
	InternalNo = @InternalNo ,  
	Unit = @Unit ,  
	City = @City ,  
	ActKind = @ActKind ,  
	ActDeAct = @ActDeAct ,  
	Prefix = @Prefix ,  
	Assansor = @Assansor ,  
	Address = @Address ,  
	PostalCode = @PostalCode ,  
	Tel1 = @Tel1 ,  
	Tel2 = @Tel2 ,  
	Tel3 = @Tel3 ,  
	Tel4 = @Tel4 ,  
	Mobile = @Mobile ,  
	Fax = @Fax ,  
	Email = @Email ,  
	Flour = @Flour ,  
	CarryFee = @CarryFee ,  
	PaykFee = @PaykFee ,  
	Distance = @Distance ,  
	Credit = @Credit ,  
	Discount = @Discount ,  
	BuyState = @BuyState ,  
	[Description] = @Description ,  
	[Date] = @Date ,  
	[Time] = @Time ,  
	[User] = @User ,  
	FamilyNo = @FamilyNo ,  
	Member = @Member ,  
	State = @State ,  
	Central = @Central,  
	Sellprice=@Sellprice  ,
	EconomicCode = @EconomicCode ,
	nvcRFID = @nvcRFID ,
	nvcBirthDate = @nvcBirthDate
	
Where Code = @Code   --AND (Branch = @Branch )   

if @@Error <> 0   
 goto ErrHandler  


Set @Updated = @Code   
 UPDATE dbo.tCust  
 SET Address = tmpCust.Address  
 FROM dbo.tCust  , dbo.tCust tmpCust  
 WHERE dbo.tCust.MasterCode = tmpCust.Code  
 -- and (dbo.tCust.[Branch] = tmpCust.[Branch] )  
update tcust set address=dbo.addressedit(address) where code=@code  --AND Branch = @Branch 
 


Commit Tran  
return @Updated  

ErrHandler:  
RollBack Tran  
return -1



GO


ALTER  PROCEDURE [dbo].[InsertFactorMasterDetailsTemp]  (
                    @Status INT ,
                    @Owner INT ,
                    @Customer INT ,
                    @DiscountTotal FLOAT ,
                    @CarryFeeTotal FLOAT ,
                    @SumPrice FLOAT ,
                    @Recursive INT ,
                    @InCharge INT ,
                    @FacPayment BIT ,
                    @OrderType INT ,
                    @StationId INT ,
                    @ServiceTotal FLOAT ,
                    @PackingTotal FLOAT ,
                    @TableNo INT ,
                    @User INT ,
                    @Date NVARCHAR(50) ,
                    @DetailsString nText,
					@NvcDescription Nvarchar(150) ,
					@GuestNo INT = NULL  ,
					@Branch INT ,
					@TempAddress Nvarchar(255) = '', 
                    @lastFacMNo BIGINT OUT
                     )

AS

DECLARE @No  INT
DECLARE @intSerialNo INT 
DECLARE @proper_time nvarchar(5)

IF  @Owner = 0
    SET @Owner = NULL

IF  @TableNo < 1
    SET @TableNo = NULL

IF  @Incharge < 1
    SET @Incharge = NULL

IF  @Customer=0
    SET @Customer = NULL


BEGIN TRAN

    DECLARE @MasterServePlace INT
    declare @newtime nvarchar(5)
    select @newtime=dbo.setTimeFormat(getdate())
    SELECT @MasterServePlace = SUM(tmpTable.SServePlace)
    FROM (  SELECT DISTINCT ServePlace As SServePlace
         FROM Split(@DetailsString)
           ) tmpTable
    

     SET @NO = (SELECT ISNULL(MAX([NO]),0)+1 FROM tFacMTemp WHERE Status=@Status AND Branch =  @Branch )


     INSERT INTO tFacMTemp (
                [No] ,
                [Date] ,
                RegDate ,
                Status ,
                Customer ,
                SumPrice ,
                OrderType ,
                ServePlace ,
                StationId ,
                ServiceTotal ,
                Recursive ,
                CarryFeeTotal ,
                PackingTotal ,
                DiscountTotal ,
                [Time] ,
                [User] ,
                TableNo ,
                shiftNo ,
                incharge,
                owner ,
                FacPayment ,
                Balance ,
				NvcDescription  ,
				GuestNo ,
				Branch ,
				TempAddress
				
 )
     Values
(
                @NO ,
                @Date ,
                dbo.Shamsi(GETDATE()) ,
                @Status,
                @Customer ,
                @SumPrice ,
                @OrderType ,
                @MasterServePlace ,
                @StationId ,
                @ServiceTotal ,
                @Recursive ,
                @CarryFeeTotal ,
                @PackingTotal ,
                @DiscountTotal ,
                @newtime,
                @User ,
                @TableNo,
                dbo.Get_Shift(GETDATE()) ,
                @Incharge ,
                @owner ,
                @FacPayment ,
                @FacPayment ,
				@NvcDescription  ,
				@GuestNo ,
				@Branch ,
				@TempAddress
 )

    SET @intSerialNo=@@IDENTITY
     IF @@ERROR <>0
        GoTo EventHandler
    
     INSERT INTO tFacDTemp
(
    
	intRow,
	Amount ,
	GoodCode  ,
	FeeUnit ,
	Discount ,
	ChairName ,
	ExpireDate ,
	intInventoryNo ,
	ServePlace ,
	DifferencesCodes , 
	DifferencesDescription ,
	intSerialNo ,
	Branch 	
)
     SELECT
	
	tmpTable.Row ,
	tmpTable.Amount ,
	tmpTable.GoodCode ,
	tmpTable.FeeUnit ,
	tmpTable.Discount ,
	tmpTable.ChairName ,
	tmpTable.ExpireDate ,
	tmpTable.intInventoryNo ,
	tmpTable.ServePlace ,
	tmpTable.DifferencesCode ,
	tmpTable.DifferencesDescription ,
	@intSerialNo , 
	@Branch 

     FROM (SELECT * FROM Split(@DetailsString)) tmpTable INNER JOIN tGood ON tGood.code = tmpTable.GoodCode


     IF @@ERROR <>0
        GoTo EventHandler

set @lastFacMNo = @NO

COMMIT TRAN

Return @lastFacMNo

EventHandler:

    ROLLBACK TRAN
    SET @LastFacMNo = -1
    SELECT  -1 AS FACNO

    RETURN -1



GO


ALTER PROCEDURE [dbo].[EditFactorMasterDetailsTemp]  (
                    @No  BIGINT,
                    @Status INT ,
                    @Owner INT ,
                    @Customer INT ,
                    @DiscountTotal FLOAT ,
                    @CarryFeeTotal FLOAT ,
                    @SumPrice FLOAT ,
                    @Recursive INT ,
                    @InCharge INT ,
                    @FacPayment BIT ,
                    @OrderType INT ,
                    @StationId INT ,
                    @ServiceTotal FLOAT ,
                    @PackingTotal FLOAT ,
                    @TableNo INT ,
                    @Date Nvarchar(50) ,
                    @DetailsString nText,
					@NvcDescription Nvarchar(150) ,
					@GuestNo INT = NULL ,
					@Branch INT ,
					@TempAddress Nvarchar(255) = '', 
                    @LastFacMNo BIGINT OUT
                     )

AS

DECLARE @intSerialNo BIGINT
DECLARE  @FactorSerial BIGINT

SET @intSerialNo = (SELECT tFacMTemp.intSerialNo FROM tFacMTemp WHERE [No] = @No AND Status = @Status and Branch = @Branch )

IF  @Owner = 0
    SET @Owner = NULL

IF  @TableNo < 1
    SET @TableNo = NULL

IF  @Incharge < 1
    SET @Incharge = NULL

IF  @Customer=0
    SET @Customer = NULL

BEGIN TRANSACTION

     DECLARE @MasterServePlace INT

     SELECT @MasterServePlace = SUM(tmpTable.SServePlace)
     FROM (  SELECT DISTINCT ServePlace As SServePlace
         FROM Split(@DetailsString)
           ) tmpTable



    DELETE FROM tFacDTemp
    WHERE tFacDTemp.intSerialNo = @intSerialNo and Branch = @Branch
 
 
     IF @@ERROR <>0
         GoTo EventHandler

    Update tFacMTemp
        SET Owner      	= @Owner,
        Customer       	= @Customer,
        DiscountTotal  	= @DiscountTotal,
        CarryFeeTotal  	= @CarryFeeTotal,
        SumPrice       	= @SumPrice,
        Recursive      	= @Recursive,
        InCharge       	= @InCharge,
        FacPayment     	= @FacPayment,    
        Balance      	= @FacPayment,
        OrderType      	= @OrderType,
        ServePlace     	= @MasterServePlace,
        StationId      	= @StationId,
        ServiceTotal   	= @ServiceTotal,
        PackingTotal   	= @PackingTotal,
        ShiftNo        	= dbo.Get_Shift(GETDATE()),
		NvcDescription  = @NvcDescription ,
        TableNo        	= @TableNo ,
        GuestNo			= @GuestNo ,
        TempAddress     = @TempAddress
        --[Date]         	= @Date,
        --[Time]         	=dbo.SetTimeFormat(GETDATE()),
        --[User]         	= @User,
        --RegDate		= dbo.Shamsi(GETDATE())
    WHERE tFacMTemp.intSerialNo = @intSerialNo and Branch = @Branch 

    IF @@ERROR <>0
        GoTo EventHandler


    INSERT INTO tFacDTemp
              (
	intRow,
	Amount ,
	GoodCode  ,
	FeeUnit ,
	Discount ,
	ChairName ,
	ExpireDate ,
	intInventoryNo  ,
	ServePlace ,
	DifferencesCodes ,
	DifferencesDescription ,
	intSerialNo ,
	Branch 
              )
    SELECT
    
	tmpTable.Row ,
	tmpTable.Amount ,
	tmpTable.GoodCode ,
	tmpTable.FeeUnit ,
	tmpTable.Discount ,
	tmpTable.ChairName ,
	tmpTable.ExpireDate ,
	tmpTable.intInventoryNo ,
	tmpTable.ServePlace ,
	tmpTable.DifferencesCode ,
	tmpTable.DifferencesDescription ,
	@intSerialNo , 
	@Branch
    FROM (SELECT * FROM Split(@DetailsString)) tmpTable INNER JOIN tGood ON tGood.code = tmpTable.GoodCode

    IF @@ERROR <>0
        GoTo EventHandler


	
Set @LastFacMNo = @No

COMMIT TRANSACTION

Return @LastFacMNo

EventHandler:

    ROLLBACK TRAN
    SET @LastFacMNo = -1
    RETURN @LastFacMNo



GO



ALTER   VIEW dbo.vw_FacMD_Good_Temp

AS
SELECT     dbo.tFacDTemp.intRow, dbo.tFacDTemp.Amount, dbo.tFacDTemp.GoodCode, dbo.tFacDTemp.FeeUnit, dbo.tFacDTemp.intSerialNo, 
           dbo.tFacDTemp.ServePlace, dbo.tFacDTemp.DifferencesCodes, dbo.tFacDTemp.DifferencesDescription, dbo.tFacDTemp.Branch, 
           dbo.tFacDTemp.Discount, dbo.tGood.Code, dbo.tGood.Level1, dbo.tGood.Level2, dbo.tGood.Name, dbo.tGood.LatinName, 
                      dbo.tGood.NamePrn, dbo.tGood.LatinNamePrn, dbo.tGood.BarCode, dbo.tGood.Unit, dbo.tGood.Model, dbo.tGood.Weight, 
                      dbo.tGood.NumberOfUnit, dbo.tGood.ProductCompany, dbo.tGood.SellPrice, dbo.tGood.BuyPrice, 
                      dbo.tGood.BtnAscDefault, dbo.tGood.GoodType, dbo.tGood.BtnTz1No, 
                      dbo.tGood.TechnicalNo, dbo.tGood.SellPrice2 , dbo.tGood.SellPrice3 ,
                      dbo.tFacMTemp.[No], dbo.tFacMTemp.Status, dbo.tFacMTemp.Owner, dbo.tFacMTemp.Customer,  dbo.tFacMTemp.DiscountTotal,
                      dbo.tFacMTemp.CarryFeeTotal, dbo.tFacMTemp.SumPrice, dbo.tFacMTemp.Recursive, isnull(dbo.tFacMTemp.InCharge , 0) as InCharge, dbo.tFacMTemp.FacPayment, dbo.tFacMTemp.OrderType,
                      dbo.tFacMTemp.StationId, dbo.tFacMTemp.ServiceTotal, dbo.tFacMTemp.PackingTotal, dbo.tFacMTemp.ShiftNo, isnull(dbo.tFacMTemp.TableNo , 0 ) as TableNo ,
                      dbo.tFacDTemp.intInventoryNo , dbo.tFacMTemp.[Date], dbo.tFacMTemp.[Time], dbo.tFacMTemp.[User], dbo.tFacMTemp.RegDate , dbo.tFacdTemp.Rate , dbo.tFacdTemp.ChairName
			,  dbo.tFacDTemp.[ExpireDate] , dbo.tFacDTemp.DestInventoryNo , dbo.tFacMTemp.NvcDescription , tGood.maintype
			, TaxBuy , TaxSale , DutyBuy , DutySale , ISNULL(GuestNo , '') AS GuestNo , dbo.tFacMTemp.TempAddress
FROM         dbo.tFacMTemp INNER JOIN
                      dbo.tFacDTemp ON dbo.tFacMTemp.intSerialNo = dbo.tFacDTemp.intSerialNo  and dbo.tFacMTemp.Branch = dbo.tFacDTemp.Branch INNER JOIN
                      dbo.tGood ON dbo.tFacDTemp.GoodCode = dbo.tGood.Code
--Where	dbo.tFacMTemp.Branch = dbo.Get_Current_Branch()


GO




ALTER View [dbo].[vw_OwedCreditCustomer]   AS
SELECT DISTINCT dbo.tCust.Code, CASE  dbo.tCust.[Name] + ' ' + dbo.tCust.Family  WHEN ' '  THEN tCust.WorkName
			ELSE dbo.tCust.[Name] + ' ' + dbo.tCust.Family 
			END AS [Full Name], dbo.tCust.Credit , tfacm.AccountYear , tfacm.Branch
			, tfacm.Customer
FROM         dbo.tFacM INNER JOIN
                dbo.tCust ON dbo.tFacM.Customer = dbo.tCust.Code --and  (dbo.tFacM.Branch = dbo.tCust.Branch OR dbo.tCust.Branch IS NULL)
WHERE      (dbo.tfacm.Balance = 0)  
            And (dbo.tfacm.Facpayment = 1 OR  (dbo.tfacm.Facpayment = 0 AND InCharge IS NULL AND tfacm.ServePlace <> 2 ))
			AND Customer > 0
			 --and dbo.tFacM.Branch = dbo.Get_Current_Branch()
			--and (dbo.tCust.Credit > 0)  



GO




ALTER PROCEDURE [dbo].[Get_OwedCreditCustomer]  
	@AccountYear SMALLINT , @Branch INT , @DateBefore NVARCHAR(10) , @DateAfter NVARCHAR(10)
 AS

SELECT DISTINCT  code , [Full Name] from dbo.vw_OwedCreditCustomer 
		INNER JOIN dbo.tFacM ON dbo.vw_OwedCreditCustomer.Customer = dbo.tFacM.Customer
		WHERE vw_OwedCreditCustomer.AccountYear = @AccountYear --AND Branch = @Branch
		AND tFacM.Date >= @DateBefore AND tFacM.Date <= @DateAfter



GO


ALTER  Procedure [dbo].[Get_CreditFactor] ( @Customer Bigint , @AccountYear SMALLINT , @Branch INT 
	, @DateBefore NVARCHAR(10) , @DateAfter NVARCHAR(10)) 

 AS

select dbo.vw_CreditFactor.* 
	from dbo.vw_CreditFactor 
	where dbo.vw_CreditFactor.Customer = @Customer  -- And (dbo.vw_CreditFactor.Incharge  Is  Not Null  Or dbo.vw_CreditFactor.OrderType = 2) 
		AND vw_CreditFactor.Balance = 0
         And (dbo.vw_CreditFactor.Facpayment = 1 OR  (dbo.vw_CreditFactor.Facpayment = 0 AND InCharge IS NULL AND ServePlace <> 2 ))
         AND AccountYear = @AccountYear 
         AND (Branch = @Branch OR @Branch = 0)
		AND Date >= @DateBefore AND Date <= @DateAfter



GO


ALTER  PROCEDURE [dbo].[insert_tblSamar_TableUsage]
    (
      @Details NVARCHAR(4000),
      @bitIsValid BIT = 1	 
    )
AS 
    BEGIN TRAN

    INSERT  INTO dbo.tblSamar_TableUsage
            (
              intBranch,
              intReseveDetailNo,
              nvcAssignTime,
		  	  nvcStartTime ,
              intTableNo,
              bitIsValid,
              nvcUsedDate
            )
            SELECT  dbo.Get_Current_Branch(),
                    intReseveDetailNo,
                    dbo.SetTimeFormat(GETDATE()),
                    dbo.SetTimeFormat(GETDATE()),
                    intTableNo,
                    @bitIsValid,
                    dbo.shamsi(GETDATE())
            FROM    dbo.Split_tblSamar_TableUsage(@Details)

    IF @@error > 0 
        GOTO ErrorHandler

    COMMIT TRAN
    RETURN 

    ErrorHandler:
    ROLLBACK TRAN

GO
 
