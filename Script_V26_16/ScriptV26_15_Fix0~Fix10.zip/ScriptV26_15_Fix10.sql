

--Script_V26_15_Fix10
-- ����� ���� ��� �� ���� ����� �����
-- 92/07/23

INSERT  INTO dbo.tblPub_Script2
        ( Version ,
          Script ,
          LastScriptNo ,
          [Date] ,
          FixNumber
        )
VALUES  ( 26 ,
          15 ,
          0 ,
          dbo.shamsi(GETDATE()) ,
          10
        )
GO

ALTER   PROCEDURE [dbo].[RetriveTable_Branch]
    (
      @Branch INT ,
      @TableControl BIT
    )
AS 
    IF @TableControl = 0 
        SELECT  [No] ,
                [Name] AS TableDescription , Empty , NumberOfChair , dbo.tPartitions.*
        FROM    tTable  INNER JOIN tPartitions ON tPartitions.PartitionID = tTable.PartitionID AND  tPartitions.Branch = tTable.Branch
	  WHERE tPartitions.Branch = @Branch
        ORDER BY dbo.tTable.[No]

    IF @TableControl = 1 
        SELECT  [No] ,
                [Name] AS TableDescription , Empty ,NumberOfChair, dbo.tPartitions.*
        FROM    tTable INNER JOIN tPartitions ON tPartitions.PartitionID = tTable.PartitionID AND  tPartitions.Branch = tTable.Branch
	   WHERE tTable.Empty = 1 AND  tPartitions.Branch = @Branch
        ORDER BY dbo.tTable.[No]
--===============================================


GO

ALTER  PROCEDURE Update_tTable_By_Empty

@intTableNo  int

AS
begin tran
 UPDATE tTable

     SET Empty=1 
        WHERE dbo.tTable.[No]=@intTableNo   AND Branch = dbo.Get_Current_Branch()
if dbo.Get_TableMonitoring()=1
	Begin
	
		UPDATE tblSamar_TableUsage SET tblSamar_TableUsage.nvcEndTime=  dbo.SetTimeFormat(getdate())      
		WHERE  dbo.tblSamar_TableUsage.intBranch = dbo.Get_Current_Branch()               
				AND tblSamar_TableUsage.nvcEndTime IS NULL 
	end
if @@Error <> 0 
	Goto ErrHandler

Commit Tran
Return

ErrHandler:
RollBack Tran
Return




GO

